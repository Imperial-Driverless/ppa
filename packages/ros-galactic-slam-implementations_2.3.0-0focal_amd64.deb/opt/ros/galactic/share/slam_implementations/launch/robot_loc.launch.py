from launch_ros.actions import Node

from launch import LaunchDescription


def generate_launch_description():
    return LaunchDescription(
        [
            Node(
                package="robot_localization",
                executable="ekf_node",
                name="ekf_node",
                output="screen",
                parameters=[
                    {
                        "two_d_mode": True,
                        "use_sim_time": True,
                        "smooth_lagged_data": True,
                        "history_length": 1.0,
                        "reset_on_time_jump": True,
                        "publish_tf": True,
                        "odom0": "/odom_noisy",
                        "odom0_relative": True,
                        "odom0_config": [
                            True,
                            True,
                            True,
                            False,
                            False,
                            True,
                            True,
                            True,
                            True,
                            False,
                            False,
                            True,
                            False,
                            False,
                            False,
                        ],
                    }
                ],
                remappings=[("odometry/filtered", "/odom")],
            ),
            Node(
                package="imperial_driverless_utils",
                executable="odometry_noisifier",
                name="odometry_noisifier",
                output="screen",
                parameters=[
                    {
                        "use_sim_time": True,
                        "drift_magnitude": 0.1,
                    }
                ],
                remappings=[("/odom", "/odom_noisy")],
            ),
        ]
    )
