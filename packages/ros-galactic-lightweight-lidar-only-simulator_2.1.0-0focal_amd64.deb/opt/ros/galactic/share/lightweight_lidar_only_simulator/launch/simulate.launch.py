"""
This will launch the simulator and the Nav2 map server. 
This will NOT launch: the GUI, the vehicle model nor any teleoperation script.
Please use the custom.launch.py launchfile from imperial_driverless_utils to
launch everything at once.

Choose the map by setting the 'map' launch argument.
"""

from datetime import timedelta

import lifecycle_msgs.msg
from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import LifecycleNode, Node
from launch_ros.event_handlers import OnStateTransition
from launch_ros.events.lifecycle import ChangeState

import launch
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, EmitEvent, ExecuteProcess,
                            RegisterEventHandler, OpaqueFunction)
from launch.substitutions import LaunchConfiguration

import yaml

def delayed(e: EmitEvent, by: timedelta) -> ExecuteProcess:
    return ExecuteProcess(
        cmd=['sleep', str(by.total_seconds())],
        on_exit=[
            e
        ]
    )

def run_simulator(context, *args, **kwargs):
    package_dir = get_package_share_directory(
        'lightweight_lidar_only_simulator')
        
    vehicle_config_file = LaunchConfiguration('vehicle_config_file').perform(context)

    vehicle_config = yaml.safe_load(open(vehicle_config_file, 'r'))

    return [
        Node(
            package='lightweight_lidar_only_simulator',
            executable='simulate',
            name='lightweight_lidar_only_simulator',
            output='screen',
            parameters=[
                f'{package_dir}/config/params.yaml',
                {'wheelbase': vehicle_config['wheelbase']},
            ]
        )
    ]


def generate_launch_description():
    package_dir = get_package_share_directory(
        'lightweight_lidar_only_simulator')

    # ================
    # == MAP SERVER ==
    # ================
    map_server_node = LifecycleNode(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        namespace='',
        parameters=[
            {'yaml_filename': LaunchConfiguration('map')}
        ])

    map_server_emit_activation_event = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=launch.events.matches_action(
                map_server_node),
            transition_id=lifecycle_msgs.msg.Transition.TRANSITION_ACTIVATE,
        ))

    map_server_emit_configure_event = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=launch.events.matches_action(
                map_server_node),
            transition_id=lifecycle_msgs.msg.Transition.TRANSITION_CONFIGURE,
        ))

    map_server_inactive_state_handler = RegisterEventHandler(
        OnStateTransition(
            target_lifecycle_node=map_server_node,
            goal_state='inactive',
            entities=[map_server_emit_activation_event],
        ))

    map_launch_arg = DeclareLaunchArgument(
        name='map',
        default_value=f'{package_dir}/maps/racetrack.yaml')


    # =================
    # ==  SIMULATOR  ==
    # =================
    simulator_node = OpaqueFunction(function=run_simulator)

    return LaunchDescription([
        map_launch_arg,

        map_server_node,
        map_server_inactive_state_handler,
        delayed(map_server_emit_configure_event, timedelta(seconds=2.)),

        simulator_node,
    ])


if __name__ == '__main__':
    generate_launch_description()
