// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from imperial_driverless_interfaces:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__STRUCT_H_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/VCUDriveCommand in the package imperial_driverless_interfaces.
typedef struct imperial_driverless_interfaces__msg__VCUDriveCommand
{
  double motor_torque_nm;
  double steering_angle_rad;
  double brake_pct;
  uint32_t max_rpm;
} imperial_driverless_interfaces__msg__VCUDriveCommand;

// Struct for a sequence of imperial_driverless_interfaces__msg__VCUDriveCommand.
typedef struct imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence
{
  imperial_driverless_interfaces__msg__VCUDriveCommand * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__STRUCT_H_
