// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__STRUCT_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveFeedback __attribute__((deprecated))
#else
# define DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveFeedback __declspec(deprecated)
#endif

namespace imperial_driverless_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct VCUDriveFeedback_
{
  using Type = VCUDriveFeedback_<ContainerAllocator>;

  explicit VCUDriveFeedback_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->steering_angle_rad = 0.0;
      this->fl_wheel_speed_rpm = 0.0;
      this->fr_wheel_speed_rpm = 0.0;
      this->rl_wheel_speed_rpm = 0.0;
      this->rr_wheel_speed_rpm = 0.0;
    }
  }

  explicit VCUDriveFeedback_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->steering_angle_rad = 0.0;
      this->fl_wheel_speed_rpm = 0.0;
      this->fr_wheel_speed_rpm = 0.0;
      this->rl_wheel_speed_rpm = 0.0;
      this->rr_wheel_speed_rpm = 0.0;
    }
  }

  // field types and members
  using _steering_angle_rad_type =
    double;
  _steering_angle_rad_type steering_angle_rad;
  using _fl_wheel_speed_rpm_type =
    double;
  _fl_wheel_speed_rpm_type fl_wheel_speed_rpm;
  using _fr_wheel_speed_rpm_type =
    double;
  _fr_wheel_speed_rpm_type fr_wheel_speed_rpm;
  using _rl_wheel_speed_rpm_type =
    double;
  _rl_wheel_speed_rpm_type rl_wheel_speed_rpm;
  using _rr_wheel_speed_rpm_type =
    double;
  _rr_wheel_speed_rpm_type rr_wheel_speed_rpm;

  // setters for named parameter idiom
  Type & set__steering_angle_rad(
    const double & _arg)
  {
    this->steering_angle_rad = _arg;
    return *this;
  }
  Type & set__fl_wheel_speed_rpm(
    const double & _arg)
  {
    this->fl_wheel_speed_rpm = _arg;
    return *this;
  }
  Type & set__fr_wheel_speed_rpm(
    const double & _arg)
  {
    this->fr_wheel_speed_rpm = _arg;
    return *this;
  }
  Type & set__rl_wheel_speed_rpm(
    const double & _arg)
  {
    this->rl_wheel_speed_rpm = _arg;
    return *this;
  }
  Type & set__rr_wheel_speed_rpm(
    const double & _arg)
  {
    this->rr_wheel_speed_rpm = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> *;
  using ConstRawPtr =
    const imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveFeedback
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveFeedback
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VCUDriveFeedback_ & other) const
  {
    if (this->steering_angle_rad != other.steering_angle_rad) {
      return false;
    }
    if (this->fl_wheel_speed_rpm != other.fl_wheel_speed_rpm) {
      return false;
    }
    if (this->fr_wheel_speed_rpm != other.fr_wheel_speed_rpm) {
      return false;
    }
    if (this->rl_wheel_speed_rpm != other.rl_wheel_speed_rpm) {
      return false;
    }
    if (this->rr_wheel_speed_rpm != other.rr_wheel_speed_rpm) {
      return false;
    }
    return true;
  }
  bool operator!=(const VCUDriveFeedback_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VCUDriveFeedback_

// alias to use template instance with default allocator
using VCUDriveFeedback =
  imperial_driverless_interfaces::msg::VCUDriveFeedback_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__STRUCT_HPP_
