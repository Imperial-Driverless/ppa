from pathlib import Path
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch_ros.substitutions import FindPackageShare
from launch.launch_description_sources import PythonLaunchDescriptionSource
import xacro

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node

from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    
    pkg_share = Path(get_package_share_directory('vehicle_descriptions'))

    rviz_config_file = pkg_share / 'rviz' / 'urdf.rviz'

    return LaunchDescription([
        Node(
            name='rviz',
            package='rviz2',
            executable='rviz2',
            arguments=['-d', str(rviz_config_file)],
            use_sim_time=True,
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                PathJoinSubstitution([
                    str(pkg_share),
                    'launch',
                    'simple.launch.py'
                ])
            )
        )
    ])
