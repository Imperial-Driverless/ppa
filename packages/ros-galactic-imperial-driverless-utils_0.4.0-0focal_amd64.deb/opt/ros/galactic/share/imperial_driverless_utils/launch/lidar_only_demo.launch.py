from tempfile import mkdtemp
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.launch_description_sources.python_launch_description_source import PythonLaunchDescriptionSource
from launch_ros.substitutions.find_package import FindPackageShare

from launch_ros.actions import Node

import launch
from launch import LaunchDescription
from launch.event_handlers import OnProcessExit
from launch.substitutions import PathJoinSubstitution

import imperial_driverless_utils

def generate_launch_description():


    tmp_dir = mkdtemp()
    rviz_config_file_name = tmp_dir + '/rviz_config.rviz'
    with open(rviz_config_file_name, 'w+') as f:
        f.write(imperial_driverless_utils.rviz_config)

    simulator = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('lightweight_lidar_only_simulator'),
                'launch/simulate_no_gui.launch.py'
            ])
        )
    )

    teleop = Node(
        package='ackermann_drive_teleop',
        executable='keyop',
        name='ackermann_drive_teleop',
    )

    cone_detector = Node(
        package='lidar_only_cone_detector',
        executable='naive_detector',
        name='cone_detector'
    )

    mapper = Node(
        package='slam_implementations',
        executable='mean_position_slam',
        name='mean_position_slam',
    )

    # ============
    # ==  RVIZ  ==
    # ============
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_file_name])

    shutdown_on_rviz_exit = launch.actions.RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=rviz_node,
            on_exit=[
                launch.actions.EmitEvent(event=launch.events.Shutdown()),
            ],
        ))

    # using the version of topic_tools from https://github.com/mateusz-lichota/topic_tools
    display_conemap = Node(
        package='topic_tools',
        executable='transform',
        namespace='/ground_truth',
        name='transform',
        output='screen',
        emulate_tty=True,
        parameters=[
            {'input': '/ground_truth/cone_map'},
            {'output-topic': '/ground_truth/cone_map_rviz'},
            {'output-type': 'visualization_msgs/MarkerArray'},
            {'expression': 'idi_msgs_to_rviz_markers.conemap_to_markerarray(m)'},
            {'import': ['idi_msgs_to_rviz_markers']},
            {'wait-for-start': True},
        ])

    return LaunchDescription([
        simulator,
        teleop,
        cone_detector,
        mapper,
        rviz_node,
        shutdown_on_rviz_exit,
        display_conemap,
    ])


if __name__ == '__main__':
    generate_launch_description()


