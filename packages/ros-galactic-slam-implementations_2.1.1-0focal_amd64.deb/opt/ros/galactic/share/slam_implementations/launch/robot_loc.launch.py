from launch_ros.actions import Node

from launch import LaunchDescription


def generate_launch_description():
    return LaunchDescription(
        [
            Node(
                package="robot_localization",
                executable="ekf_node",
                name="ekf_node",
                output="screen",
                parameters=[
                    {
                        "two_d_mode": True,
                        "publish_tf": True,
                        "odom0": "/odom",
                        "odom0_config": [
                            True,
                            True,
                            True,
                            True,
                            True,
                            True,
                            True,
                            False,
                            False,
                            False,
                            False,
                            True,
                            False,
                            False,
                            False,
                        ],
                    }
                ],
            )
        ]
    )
