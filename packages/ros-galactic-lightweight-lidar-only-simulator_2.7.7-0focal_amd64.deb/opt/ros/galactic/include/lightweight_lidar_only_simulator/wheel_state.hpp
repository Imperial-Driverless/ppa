namespace lightweight_lidar_only_simulator {

struct WheelJointState {
  double position = 0.0;
  double velocity = 0.0;
};

}
