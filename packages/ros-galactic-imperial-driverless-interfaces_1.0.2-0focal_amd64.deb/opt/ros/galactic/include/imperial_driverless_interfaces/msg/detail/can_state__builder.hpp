// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from imperial_driverless_interfaces:msg/CanState.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CAN_STATE__BUILDER_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CAN_STATE__BUILDER_HPP_

#include "imperial_driverless_interfaces/msg/detail/can_state__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace imperial_driverless_interfaces
{

namespace msg
{

namespace builder
{

class Init_CanState_ami_state
{
public:
  explicit Init_CanState_ami_state(::imperial_driverless_interfaces::msg::CanState & msg)
  : msg_(msg)
  {}
  ::imperial_driverless_interfaces::msg::CanState ami_state(::imperial_driverless_interfaces::msg::CanState::_ami_state_type arg)
  {
    msg_.ami_state = std::move(arg);
    return std::move(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::CanState msg_;
};

class Init_CanState_as_state
{
public:
  Init_CanState_as_state()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CanState_ami_state as_state(::imperial_driverless_interfaces::msg::CanState::_as_state_type arg)
  {
    msg_.as_state = std::move(arg);
    return Init_CanState_ami_state(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::CanState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::imperial_driverless_interfaces::msg::CanState>()
{
  return imperial_driverless_interfaces::msg::builder::Init_CanState_as_state();
}

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CAN_STATE__BUILDER_HPP_
