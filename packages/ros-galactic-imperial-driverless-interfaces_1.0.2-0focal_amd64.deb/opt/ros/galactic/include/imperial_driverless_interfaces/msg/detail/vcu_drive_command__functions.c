// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from imperial_driverless_interfaces:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice
#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
imperial_driverless_interfaces__msg__VCUDriveCommand__init(imperial_driverless_interfaces__msg__VCUDriveCommand * msg)
{
  if (!msg) {
    return false;
  }
  // front_axle_trq_request
  // front_motor_speed_max
  // rear_axle_trq_request
  // rear_motor_speed_max
  // steer_request_deg
  // hyd_press_f_req_pct
  // hyd_press_r_req_pct
  return true;
}

void
imperial_driverless_interfaces__msg__VCUDriveCommand__fini(imperial_driverless_interfaces__msg__VCUDriveCommand * msg)
{
  if (!msg) {
    return;
  }
  // front_axle_trq_request
  // front_motor_speed_max
  // rear_axle_trq_request
  // rear_motor_speed_max
  // steer_request_deg
  // hyd_press_f_req_pct
  // hyd_press_r_req_pct
}

bool
imperial_driverless_interfaces__msg__VCUDriveCommand__are_equal(const imperial_driverless_interfaces__msg__VCUDriveCommand * lhs, const imperial_driverless_interfaces__msg__VCUDriveCommand * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // front_axle_trq_request
  if (lhs->front_axle_trq_request != rhs->front_axle_trq_request) {
    return false;
  }
  // front_motor_speed_max
  if (lhs->front_motor_speed_max != rhs->front_motor_speed_max) {
    return false;
  }
  // rear_axle_trq_request
  if (lhs->rear_axle_trq_request != rhs->rear_axle_trq_request) {
    return false;
  }
  // rear_motor_speed_max
  if (lhs->rear_motor_speed_max != rhs->rear_motor_speed_max) {
    return false;
  }
  // steer_request_deg
  if (lhs->steer_request_deg != rhs->steer_request_deg) {
    return false;
  }
  // hyd_press_f_req_pct
  if (lhs->hyd_press_f_req_pct != rhs->hyd_press_f_req_pct) {
    return false;
  }
  // hyd_press_r_req_pct
  if (lhs->hyd_press_r_req_pct != rhs->hyd_press_r_req_pct) {
    return false;
  }
  return true;
}

bool
imperial_driverless_interfaces__msg__VCUDriveCommand__copy(
  const imperial_driverless_interfaces__msg__VCUDriveCommand * input,
  imperial_driverless_interfaces__msg__VCUDriveCommand * output)
{
  if (!input || !output) {
    return false;
  }
  // front_axle_trq_request
  output->front_axle_trq_request = input->front_axle_trq_request;
  // front_motor_speed_max
  output->front_motor_speed_max = input->front_motor_speed_max;
  // rear_axle_trq_request
  output->rear_axle_trq_request = input->rear_axle_trq_request;
  // rear_motor_speed_max
  output->rear_motor_speed_max = input->rear_motor_speed_max;
  // steer_request_deg
  output->steer_request_deg = input->steer_request_deg;
  // hyd_press_f_req_pct
  output->hyd_press_f_req_pct = input->hyd_press_f_req_pct;
  // hyd_press_r_req_pct
  output->hyd_press_r_req_pct = input->hyd_press_r_req_pct;
  return true;
}

imperial_driverless_interfaces__msg__VCUDriveCommand *
imperial_driverless_interfaces__msg__VCUDriveCommand__create()
{
  imperial_driverless_interfaces__msg__VCUDriveCommand * msg = (imperial_driverless_interfaces__msg__VCUDriveCommand *)malloc(sizeof(imperial_driverless_interfaces__msg__VCUDriveCommand));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(imperial_driverless_interfaces__msg__VCUDriveCommand));
  bool success = imperial_driverless_interfaces__msg__VCUDriveCommand__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
imperial_driverless_interfaces__msg__VCUDriveCommand__destroy(imperial_driverless_interfaces__msg__VCUDriveCommand * msg)
{
  if (msg) {
    imperial_driverless_interfaces__msg__VCUDriveCommand__fini(msg);
  }
  free(msg);
}


bool
imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence__init(imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  imperial_driverless_interfaces__msg__VCUDriveCommand * data = NULL;
  if (size) {
    data = (imperial_driverless_interfaces__msg__VCUDriveCommand *)calloc(size, sizeof(imperial_driverless_interfaces__msg__VCUDriveCommand));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = imperial_driverless_interfaces__msg__VCUDriveCommand__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        imperial_driverless_interfaces__msg__VCUDriveCommand__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence__fini(imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      imperial_driverless_interfaces__msg__VCUDriveCommand__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence *
imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence__create(size_t size)
{
  imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence * array = (imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence *)malloc(sizeof(imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence__destroy(imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence * array)
{
  if (array) {
    imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence__fini(array);
  }
  free(array);
}

bool
imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence__are_equal(const imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence * lhs, const imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!imperial_driverless_interfaces__msg__VCUDriveCommand__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence__copy(
  const imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence * input,
  imperial_driverless_interfaces__msg__VCUDriveCommand__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(imperial_driverless_interfaces__msg__VCUDriveCommand);
    imperial_driverless_interfaces__msg__VCUDriveCommand * data =
      (imperial_driverless_interfaces__msg__VCUDriveCommand *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!imperial_driverless_interfaces__msg__VCUDriveCommand__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          imperial_driverless_interfaces__msg__VCUDriveCommand__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!imperial_driverless_interfaces__msg__VCUDriveCommand__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
