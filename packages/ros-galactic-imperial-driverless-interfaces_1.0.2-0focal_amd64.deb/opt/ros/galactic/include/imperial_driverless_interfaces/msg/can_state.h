// generated from rosidl_generator_c/resource/idl.h.em
// with input from imperial_driverless_interfaces:msg/CanState.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__CAN_STATE_H_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__CAN_STATE_H_

#include "imperial_driverless_interfaces/msg/detail/can_state__struct.h"
#include "imperial_driverless_interfaces/msg/detail/can_state__functions.h"
#include "imperial_driverless_interfaces/msg/detail/can_state__type_support.h"

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__CAN_STATE_H_
