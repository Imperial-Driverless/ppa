#pragma once

namespace lightweight_lidar_only_simulator {

struct Pose2D {
    double x;
    double y;
    double theta;
};

}
