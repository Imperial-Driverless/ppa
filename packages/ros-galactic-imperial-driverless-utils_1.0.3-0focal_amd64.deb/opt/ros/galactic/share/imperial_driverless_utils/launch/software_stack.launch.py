import enum
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, List, Tuple

import click
from ament_index_python.packages import (PackageNotFoundError,
                                         get_package_share_path)
from launch_ros.actions import Node
from ros2pkg.api import PackageNotFound, get_executable_paths

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.launch_description_entity import LaunchDescriptionEntity
from launch.launch_description_sources.python_launch_description_source import \
    PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


# click colours for terminal output
def red(x: str, /): return click.style(x, fg='red')
def blue(x: str, /): return click.style(x, fg='blue')
def green(x: str, /): return click.style(x, fg='green')
def cyan(x: str, /): return click.style(x, fg='cyan')
def yellow(x: str, /): return click.style(x, fg='yellow')


class PackageSource(enum.Enum):
    NOT_FOUND = 'package was not found',
    SYSTEM = 'package was installed globaly (probably via apt)'
    LOCAL = 'package was installed locally'


LaunchOption = Tuple[str, List[LaunchDescriptionEntity]]


@dataclass
class Package:
    '''
    This class represents a ROS2 package.
    '''
    name: str
    url: str

    # Custom options available when the package is installed
    custom_options: List[LaunchOption] = field(default_factory=list)

    # Custom options always available, even if the package is not installed
    fallback_options: List[LaunchOption] = field(default_factory=list)

    @property
    def executable_names(self) -> List[str]:
        return [os.path.basename(path) for path in get_executable_paths(package_name=self.name)]  # type: ignore

    @property
    def launch_files(self) -> Iterable[Path]:
        pkg_path = get_package_share_path(self.name)
        return (pkg_path / 'launch').glob('*.launch*')

    @property
    def source(self) -> PackageSource:
        try:
            if get_package_share_path(self.name).parts[1] == 'opt':
                return PackageSource.SYSTEM
            else:
                return PackageSource.LOCAL
        except PackageNotFoundError:
            return PackageSource.NOT_FOUND


collection_pkgs = [
    Package(
        'lidar_only_cone_detector',
        url='https://github.com/Imperial-Driverless/lidar_only_cone_detector',
    ),
    Package(
        'camera',
        url='https://github.com/Imperial-Driverless/camera',
    ),
    Package(
        'lidar_camera_fusion',
        url='https://github.com/Imperial-Driverless/lidar_camera_fusion',
    ),
    Package(
        'slam_implementations',
        url='https://github.com/Imperial-Driverless/slam_implementations'
    ),
    Package(
        'path_generators',
        url='https://github.com/Imperial-Driverless/path_generators',
    ),
    Package(
        'path_followers',
        url='https://github.com/Imperial-Driverless/path_followers',
        fallback_options=[
            (click.style('launch twist from car_keyop', fg='cyan'), [
                Node(
                    package='car_keyop',
                    executable='twist',
                    name='car_keyop',
                    arguments=['8.0', '1'],  # max linear and angular velocities
                    parameters=[{'use_sim_time': True}],
                )
            ])
        ]
    ),
    Package(
        'vehicle_controllers',
        url='https://github.com/Imperial-Driverless/vehicle_controllers',
    ),
]


def generate_launch_description():
    click.clear()
    try:
        package_nodes = package_nodes_ld()

        path_from_odom_history_publisher = Node(
            package='imperial_driverless_utils',
            executable='path_from_odom_history_publisher',
            name='path_from_odom_history_publisher',
            parameters=[{'use_sim_time': True},
                        {'history_length_seconds': 20}]
        )

        return LaunchDescription([
            DeclareLaunchArgument('vehicle_config_file'),
            path_from_odom_history_publisher,
            *rviz_ld(),
            *package_nodes,
        ])

    except click.Abort:
        click.echo()
        click.echo(yellow('Launch aborted by the user'))
        exit()


def rviz_ld() -> List[LaunchDescriptionEntity]:
    rviz_launch_file_path = str(get_package_share_path('imperial_driverless_utils') / 'launch' / 'rviz.launch.py')

    return [IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            launch_file_path=rviz_launch_file_path
        )
    )]


def package_nodes_ld() -> List[LaunchDescriptionEntity]:

    ld: List[LaunchDescriptionEntity] = []

    for pkg in collection_pkgs:
        ld.extend(get_launch_entities_for_package(pkg))

    return ld


def get_launch_entities_for_package(pkg: Package) -> List[LaunchDescriptionEntity]:
    pkg_found_common_options: List[LaunchOption] = [
        (yellow('do not launch any executable from this package'), [])
    ]

    pkg_not_found_common_options: List[LaunchOption] = [
        (yellow('ignore, I will start it myself'), []),
        # (click.style('Clone from GitHub, build and source', fg='yellow'), []),
    ]

    all_options = []
    launch_file_options = []
    executable_options = []

    try:
        executable_options: List[LaunchOption] = [(
            green(executable), [
                Node(
                    package=pkg.name,
                    executable=executable,
                    name=executable,
                    emulate_tty=True,
                    output='screen',
                    parameters=[{
                        'use_sim_time': True,
                        'vehicle_config_file': LaunchConfiguration('vehicle_config_file'),
                    }],
                )
            ]) for executable in pkg.executable_names]

        launch_file_options: List[LaunchOption] = [(
            cyan(launch_file.stem), [
                IncludeLaunchDescription(
                    PythonLaunchDescriptionSource(str(launch_file)),
                )
            ]) for launch_file in pkg.launch_files]

        all_options: List[LaunchOption] = [
            *pkg.fallback_options,
            *pkg_found_common_options,
            *executable_options,
            *launch_file_options,
            *pkg.custom_options,
        ]

        click.echo(f'Select an executable from {blue(pkg.name)} [{pkg.source.name}]')

    except PackageNotFound:
        click.echo(blue(pkg.name) + red(' not found. What to do?'))

        all_options = [
            *pkg.fallback_options,
            *pkg_not_found_common_options,
        ]

    for i, (text, _) in enumerate(all_options):
        click.echo(f'{i}. {text}')

    selection = click.prompt(
        'Please select:',
        type=click.Choice([str(i) for i, _ in enumerate(all_options)]),
        default='0',
        show_choices=False,
    )

    assert isinstance(selection, str)
    selected_option = all_options[int(selection)]
    _, entities = selected_option

    if selected_option in executable_options or selected_option in launch_file_options:
        click.echo('Launching ' + selected_option[0] +
                   f' from {blue(pkg.name)}.\n')
    else:
        click.echo()

    return entities
