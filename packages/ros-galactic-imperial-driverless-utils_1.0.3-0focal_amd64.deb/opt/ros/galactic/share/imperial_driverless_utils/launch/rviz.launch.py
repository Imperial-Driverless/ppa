from pathlib import Path
from tempfile import mkdtemp

from imperial_driverless_utils.rviz_config import (cone_map_display,
                                                   get_rviz_config,
                                                   marker_array_display,
                                                   path_display)
from launch_ros.actions import Node

from launch import LaunchDescription
from launch.actions import EmitEvent, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown

COLOR_GREEN = (0, 255, 0)
COLOR_YELLOW = (255, 255, 0)
COLOR_LIGHT_GREEN = (25, 255, 0)


def generate_launch_description():
    tmp_dir = Path(mkdtemp())

    displays = [
        path_display('/gt_odom_path', 'Ground truth odom frame path history', COLOR_GREEN),
        path_display('/loc_odom_path', 'Robot localization odom frame path history', COLOR_YELLOW),
        cone_map_display('/ground_truth/cone_map', 'Ground Truth Cone Map'),
        cone_map_display('/cone_map', 'SLAM Cone Map'),
        cone_map_display('/perceived_cones/fused', 'Fused Perceived Cones'),
        cone_map_display('/perceived_cones/camera', 'Camera Perceived Cones'),
        cone_map_display('/perceived_cones/lidar', 'Lidar Perceived Cones'),
        path_display('/path', 'Generated Path', COLOR_LIGHT_GREEN),
        marker_array_display('/visualization/path_generator', 'Path Generator Visualization'),
    ]

    rviz_config_file = tmp_dir / 'rviz_config.rviz'
    rviz_config_file.write_text(get_rviz_config(displays))
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='log',
        parameters=[{'use_sim_time': True}],
        arguments=[
            '-d', str(rviz_config_file),
            '--ros-args', '--log-level', 'error',
        ])

    shutdown_on_rviz_exit = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=rviz_node,
            on_exit=[
                EmitEvent(event=Shutdown()),
            ],
        ))

    # This is needed to prevent weird RVIZ issues, most
    # visible of which is the wheels staying behind the vehicle and then jumping back
    # to where they should be all the time. Look at RVIZ clock settings
    # - they should be set to 'experimental' and clock synchronization is 'exact'.
    # If someone fixed this RVIZ bug in a better way it's safe to delete this Node
    clock_sync_signal_emitter = Node(
        package='imperial_driverless_utils',
        executable='clock_sync_signal_emitter',
        name='clock_sync_signal_emitter',
        parameters=[{'use_sim_time': True}],
    )

    return LaunchDescription([
        rviz_node,
        shutdown_on_rviz_exit,
        clock_sync_signal_emitter,
    ])
