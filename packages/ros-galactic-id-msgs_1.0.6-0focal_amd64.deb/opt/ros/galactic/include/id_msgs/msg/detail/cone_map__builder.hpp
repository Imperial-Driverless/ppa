// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from id_msgs:msg/ConeMap.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__DETAIL__CONE_MAP__BUILDER_HPP_
#define ID_MSGS__MSG__DETAIL__CONE_MAP__BUILDER_HPP_

#include "id_msgs/msg/detail/cone_map__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace id_msgs
{

namespace msg
{

namespace builder
{

class Init_ConeMap_small_orange_cones
{
public:
  explicit Init_ConeMap_small_orange_cones(::id_msgs::msg::ConeMap & msg)
  : msg_(msg)
  {}
  ::id_msgs::msg::ConeMap small_orange_cones(::id_msgs::msg::ConeMap::_small_orange_cones_type arg)
  {
    msg_.small_orange_cones = std::move(arg);
    return std::move(msg_);
  }

private:
  ::id_msgs::msg::ConeMap msg_;
};

class Init_ConeMap_big_orange_cones
{
public:
  explicit Init_ConeMap_big_orange_cones(::id_msgs::msg::ConeMap & msg)
  : msg_(msg)
  {}
  Init_ConeMap_small_orange_cones big_orange_cones(::id_msgs::msg::ConeMap::_big_orange_cones_type arg)
  {
    msg_.big_orange_cones = std::move(arg);
    return Init_ConeMap_small_orange_cones(msg_);
  }

private:
  ::id_msgs::msg::ConeMap msg_;
};

class Init_ConeMap_right_cones
{
public:
  explicit Init_ConeMap_right_cones(::id_msgs::msg::ConeMap & msg)
  : msg_(msg)
  {}
  Init_ConeMap_big_orange_cones right_cones(::id_msgs::msg::ConeMap::_right_cones_type arg)
  {
    msg_.right_cones = std::move(arg);
    return Init_ConeMap_big_orange_cones(msg_);
  }

private:
  ::id_msgs::msg::ConeMap msg_;
};

class Init_ConeMap_left_cones
{
public:
  explicit Init_ConeMap_left_cones(::id_msgs::msg::ConeMap & msg)
  : msg_(msg)
  {}
  Init_ConeMap_right_cones left_cones(::id_msgs::msg::ConeMap::_left_cones_type arg)
  {
    msg_.left_cones = std::move(arg);
    return Init_ConeMap_right_cones(msg_);
  }

private:
  ::id_msgs::msg::ConeMap msg_;
};

class Init_ConeMap_header
{
public:
  Init_ConeMap_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ConeMap_left_cones header(::id_msgs::msg::ConeMap::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ConeMap_left_cones(msg_);
  }

private:
  ::id_msgs::msg::ConeMap msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::id_msgs::msg::ConeMap>()
{
  return id_msgs::msg::builder::Init_ConeMap_header();
}

}  // namespace id_msgs

#endif  // ID_MSGS__MSG__DETAIL__CONE_MAP__BUILDER_HPP_
