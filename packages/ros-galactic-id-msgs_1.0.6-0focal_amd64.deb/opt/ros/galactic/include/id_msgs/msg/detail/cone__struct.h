// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from id_msgs:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__DETAIL__CONE__STRUCT_H_
#define ID_MSGS__MSG__DETAIL__CONE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'position'
#include "geometry_msgs/msg/detail/point__struct.h"

// Struct defined in msg/Cone in the package id_msgs.
typedef struct id_msgs__msg__Cone
{
  geometry_msgs__msg__Point position;
} id_msgs__msg__Cone;

// Struct for a sequence of id_msgs__msg__Cone.
typedef struct id_msgs__msg__Cone__Sequence
{
  id_msgs__msg__Cone * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} id_msgs__msg__Cone__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ID_MSGS__MSG__DETAIL__CONE__STRUCT_H_
