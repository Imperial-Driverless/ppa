// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from id_msgs:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__DETAIL__VCU_DRIVE_FEEDBACK__TRAITS_HPP_
#define ID_MSGS__MSG__DETAIL__VCU_DRIVE_FEEDBACK__TRAITS_HPP_

#include "id_msgs/msg/detail/vcu_drive_feedback__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace rosidl_generator_traits
{

inline void to_yaml(
  const id_msgs::msg::VCUDriveFeedback & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: steering_angle_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_angle_rad: ";
    value_to_yaml(msg.steering_angle_rad, out);
    out << "\n";
  }

  // member: fl_wheel_speed_rpm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fl_wheel_speed_rpm: ";
    value_to_yaml(msg.fl_wheel_speed_rpm, out);
    out << "\n";
  }

  // member: fr_wheel_speed_rpm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fr_wheel_speed_rpm: ";
    value_to_yaml(msg.fr_wheel_speed_rpm, out);
    out << "\n";
  }

  // member: rl_wheel_speed_rpm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rl_wheel_speed_rpm: ";
    value_to_yaml(msg.rl_wheel_speed_rpm, out);
    out << "\n";
  }

  // member: rr_wheel_speed_rpm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rr_wheel_speed_rpm: ";
    value_to_yaml(msg.rr_wheel_speed_rpm, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const id_msgs::msg::VCUDriveFeedback & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<id_msgs::msg::VCUDriveFeedback>()
{
  return "id_msgs::msg::VCUDriveFeedback";
}

template<>
inline const char * name<id_msgs::msg::VCUDriveFeedback>()
{
  return "id_msgs/msg/VCUDriveFeedback";
}

template<>
struct has_fixed_size<id_msgs::msg::VCUDriveFeedback>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<id_msgs::msg::VCUDriveFeedback>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<id_msgs::msg::VCUDriveFeedback>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ID_MSGS__MSG__DETAIL__VCU_DRIVE_FEEDBACK__TRAITS_HPP_
