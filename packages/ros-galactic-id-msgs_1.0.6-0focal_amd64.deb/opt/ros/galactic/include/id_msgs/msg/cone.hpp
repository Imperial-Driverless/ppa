// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__CONE_HPP_
#define ID_MSGS__MSG__CONE_HPP_

#include "id_msgs/msg/detail/cone__struct.hpp"
#include "id_msgs/msg/detail/cone__builder.hpp"
#include "id_msgs/msg/detail/cone__traits.hpp"

#endif  // ID_MSGS__MSG__CONE_HPP_
