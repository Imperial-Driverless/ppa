// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__VCU_DRIVE_FEEDBACK_HPP_
#define ID_MSGS__MSG__VCU_DRIVE_FEEDBACK_HPP_

#include "id_msgs/msg/detail/vcu_drive_feedback__struct.hpp"
#include "id_msgs/msg/detail/vcu_drive_feedback__builder.hpp"
#include "id_msgs/msg/detail/vcu_drive_feedback__traits.hpp"

#endif  // ID_MSGS__MSG__VCU_DRIVE_FEEDBACK_HPP_
