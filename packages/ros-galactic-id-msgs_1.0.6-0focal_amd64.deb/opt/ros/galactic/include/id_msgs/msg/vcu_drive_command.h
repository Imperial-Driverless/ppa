// generated from rosidl_generator_c/resource/idl.h.em
// with input from id_msgs:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__VCU_DRIVE_COMMAND_H_
#define ID_MSGS__MSG__VCU_DRIVE_COMMAND_H_

#include "id_msgs/msg/detail/vcu_drive_command__struct.h"
#include "id_msgs/msg/detail/vcu_drive_command__functions.h"
#include "id_msgs/msg/detail/vcu_drive_command__type_support.h"

#endif  // ID_MSGS__MSG__VCU_DRIVE_COMMAND_H_
