// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__STRUCT_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveCommand __attribute__((deprecated))
#else
# define DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveCommand __declspec(deprecated)
#endif

namespace imperial_driverless_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct VCUDriveCommand_
{
  using Type = VCUDriveCommand_<ContainerAllocator>;

  explicit VCUDriveCommand_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_axle_trq_request = 0ul;
      this->front_motor_speed_max = 0ul;
      this->rear_axle_trq_request = 0ul;
      this->rear_motor_speed_max = 0ul;
      this->steer_request_deg = 0l;
      this->hyd_press_f_req_pct = 0ul;
      this->hyd_press_r_req_pct = 0ul;
    }
  }

  explicit VCUDriveCommand_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_axle_trq_request = 0ul;
      this->front_motor_speed_max = 0ul;
      this->rear_axle_trq_request = 0ul;
      this->rear_motor_speed_max = 0ul;
      this->steer_request_deg = 0l;
      this->hyd_press_f_req_pct = 0ul;
      this->hyd_press_r_req_pct = 0ul;
    }
  }

  // field types and members
  using _front_axle_trq_request_type =
    uint32_t;
  _front_axle_trq_request_type front_axle_trq_request;
  using _front_motor_speed_max_type =
    uint32_t;
  _front_motor_speed_max_type front_motor_speed_max;
  using _rear_axle_trq_request_type =
    uint32_t;
  _rear_axle_trq_request_type rear_axle_trq_request;
  using _rear_motor_speed_max_type =
    uint32_t;
  _rear_motor_speed_max_type rear_motor_speed_max;
  using _steer_request_deg_type =
    int32_t;
  _steer_request_deg_type steer_request_deg;
  using _hyd_press_f_req_pct_type =
    uint32_t;
  _hyd_press_f_req_pct_type hyd_press_f_req_pct;
  using _hyd_press_r_req_pct_type =
    uint32_t;
  _hyd_press_r_req_pct_type hyd_press_r_req_pct;

  // setters for named parameter idiom
  Type & set__front_axle_trq_request(
    const uint32_t & _arg)
  {
    this->front_axle_trq_request = _arg;
    return *this;
  }
  Type & set__front_motor_speed_max(
    const uint32_t & _arg)
  {
    this->front_motor_speed_max = _arg;
    return *this;
  }
  Type & set__rear_axle_trq_request(
    const uint32_t & _arg)
  {
    this->rear_axle_trq_request = _arg;
    return *this;
  }
  Type & set__rear_motor_speed_max(
    const uint32_t & _arg)
  {
    this->rear_motor_speed_max = _arg;
    return *this;
  }
  Type & set__steer_request_deg(
    const int32_t & _arg)
  {
    this->steer_request_deg = _arg;
    return *this;
  }
  Type & set__hyd_press_f_req_pct(
    const uint32_t & _arg)
  {
    this->hyd_press_f_req_pct = _arg;
    return *this;
  }
  Type & set__hyd_press_r_req_pct(
    const uint32_t & _arg)
  {
    this->hyd_press_r_req_pct = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> *;
  using ConstRawPtr =
    const imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveCommand
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveCommand
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VCUDriveCommand_ & other) const
  {
    if (this->front_axle_trq_request != other.front_axle_trq_request) {
      return false;
    }
    if (this->front_motor_speed_max != other.front_motor_speed_max) {
      return false;
    }
    if (this->rear_axle_trq_request != other.rear_axle_trq_request) {
      return false;
    }
    if (this->rear_motor_speed_max != other.rear_motor_speed_max) {
      return false;
    }
    if (this->steer_request_deg != other.steer_request_deg) {
      return false;
    }
    if (this->hyd_press_f_req_pct != other.hyd_press_f_req_pct) {
      return false;
    }
    if (this->hyd_press_r_req_pct != other.hyd_press_r_req_pct) {
      return false;
    }
    return true;
  }
  bool operator!=(const VCUDriveCommand_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VCUDriveCommand_

// alias to use template instance with default allocator
using VCUDriveCommand =
  imperial_driverless_interfaces::msg::VCUDriveCommand_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__STRUCT_HPP_
