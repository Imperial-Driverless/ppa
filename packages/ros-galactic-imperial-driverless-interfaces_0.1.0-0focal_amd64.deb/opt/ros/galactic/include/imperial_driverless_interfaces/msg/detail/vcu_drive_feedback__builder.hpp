// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__BUILDER_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__BUILDER_HPP_

#include "imperial_driverless_interfaces/msg/detail/vcu_drive_feedback__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace imperial_driverless_interfaces
{

namespace msg
{

namespace builder
{

class Init_VCUDriveFeedback_rr_wheel_speed
{
public:
  explicit Init_VCUDriveFeedback_rr_wheel_speed(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback rr_wheel_speed(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_rr_wheel_speed_type arg)
  {
    msg_.rr_wheel_speed = std::move(arg);
    return std::move(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_rl_wheel_speed
{
public:
  explicit Init_VCUDriveFeedback_rl_wheel_speed(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_rr_wheel_speed rl_wheel_speed(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_rl_wheel_speed_type arg)
  {
    msg_.rl_wheel_speed = std::move(arg);
    return Init_VCUDriveFeedback_rr_wheel_speed(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_fr_wheel_speed
{
public:
  explicit Init_VCUDriveFeedback_fr_wheel_speed(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_rl_wheel_speed fr_wheel_speed(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_fr_wheel_speed_type arg)
  {
    msg_.fr_wheel_speed = std::move(arg);
    return Init_VCUDriveFeedback_rl_wheel_speed(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_fl_wheel_speed
{
public:
  explicit Init_VCUDriveFeedback_fl_wheel_speed(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_fr_wheel_speed fl_wheel_speed(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_fl_wheel_speed_type arg)
  {
    msg_.fl_wheel_speed = std::move(arg);
    return Init_VCUDriveFeedback_fr_wheel_speed(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_hyd_press_r_pct
{
public:
  explicit Init_VCUDriveFeedback_hyd_press_r_pct(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_fl_wheel_speed hyd_press_r_pct(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_hyd_press_r_pct_type arg)
  {
    msg_.hyd_press_r_pct = std::move(arg);
    return Init_VCUDriveFeedback_fl_wheel_speed(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_hyd_press_f_pct
{
public:
  explicit Init_VCUDriveFeedback_hyd_press_f_pct(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_hyd_press_r_pct hyd_press_f_pct(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_hyd_press_f_pct_type arg)
  {
    msg_.hyd_press_f_pct = std::move(arg);
    return Init_VCUDriveFeedback_hyd_press_r_pct(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_angle
{
public:
  explicit Init_VCUDriveFeedback_angle(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_hyd_press_f_pct angle(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_angle_type arg)
  {
    msg_.angle = std::move(arg);
    return Init_VCUDriveFeedback_hyd_press_f_pct(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_rear_axle_trq
{
public:
  explicit Init_VCUDriveFeedback_rear_axle_trq(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_angle rear_axle_trq(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_rear_axle_trq_type arg)
  {
    msg_.rear_axle_trq = std::move(arg);
    return Init_VCUDriveFeedback_angle(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_front_axle_trq
{
public:
  Init_VCUDriveFeedback_front_axle_trq()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VCUDriveFeedback_rear_axle_trq front_axle_trq(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_front_axle_trq_type arg)
  {
    msg_.front_axle_trq = std::move(arg);
    return Init_VCUDriveFeedback_rear_axle_trq(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::imperial_driverless_interfaces::msg::VCUDriveFeedback>()
{
  return imperial_driverless_interfaces::msg::builder::Init_VCUDriveFeedback_front_axle_trq();
}

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__BUILDER_HPP_
