// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from imperial_driverless_interfaces:msg/ProbabilisticCone.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PROBABILISTIC_CONE__BUILDER_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PROBABILISTIC_CONE__BUILDER_HPP_

#include "imperial_driverless_interfaces/msg/detail/probabilistic_cone__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace imperial_driverless_interfaces
{

namespace msg
{

namespace builder
{

class Init_ProbabilisticCone_y_std_dev
{
public:
  explicit Init_ProbabilisticCone_y_std_dev(::imperial_driverless_interfaces::msg::ProbabilisticCone & msg)
  : msg_(msg)
  {}
  ::imperial_driverless_interfaces::msg::ProbabilisticCone y_std_dev(::imperial_driverless_interfaces::msg::ProbabilisticCone::_y_std_dev_type arg)
  {
    msg_.y_std_dev = std::move(arg);
    return std::move(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::ProbabilisticCone msg_;
};

class Init_ProbabilisticCone_x_std_dev
{
public:
  explicit Init_ProbabilisticCone_x_std_dev(::imperial_driverless_interfaces::msg::ProbabilisticCone & msg)
  : msg_(msg)
  {}
  Init_ProbabilisticCone_y_std_dev x_std_dev(::imperial_driverless_interfaces::msg::ProbabilisticCone::_x_std_dev_type arg)
  {
    msg_.x_std_dev = std::move(arg);
    return Init_ProbabilisticCone_y_std_dev(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::ProbabilisticCone msg_;
};

class Init_ProbabilisticCone_y
{
public:
  explicit Init_ProbabilisticCone_y(::imperial_driverless_interfaces::msg::ProbabilisticCone & msg)
  : msg_(msg)
  {}
  Init_ProbabilisticCone_x_std_dev y(::imperial_driverless_interfaces::msg::ProbabilisticCone::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_ProbabilisticCone_x_std_dev(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::ProbabilisticCone msg_;
};

class Init_ProbabilisticCone_x
{
public:
  Init_ProbabilisticCone_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ProbabilisticCone_y x(::imperial_driverless_interfaces::msg::ProbabilisticCone::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_ProbabilisticCone_y(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::ProbabilisticCone msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::imperial_driverless_interfaces::msg::ProbabilisticCone>()
{
  return imperial_driverless_interfaces::msg::builder::Init_ProbabilisticCone_x();
}

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PROBABILISTIC_CONE__BUILDER_HPP_
