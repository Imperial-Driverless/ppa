// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__STRUCT_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveFeedback __attribute__((deprecated))
#else
# define DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveFeedback __declspec(deprecated)
#endif

namespace imperial_driverless_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct VCUDriveFeedback_
{
  using Type = VCUDriveFeedback_<ContainerAllocator>;

  explicit VCUDriveFeedback_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_axle_trq = 0ul;
      this->rear_axle_trq = 0ul;
      this->angle = 0l;
      this->hyd_press_f_pct = 0ul;
      this->hyd_press_r_pct = 0ul;
      this->fl_wheel_speed = 0ul;
      this->fr_wheel_speed = 0ul;
      this->rl_wheel_speed = 0ul;
      this->rr_wheel_speed = 0ul;
    }
  }

  explicit VCUDriveFeedback_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->front_axle_trq = 0ul;
      this->rear_axle_trq = 0ul;
      this->angle = 0l;
      this->hyd_press_f_pct = 0ul;
      this->hyd_press_r_pct = 0ul;
      this->fl_wheel_speed = 0ul;
      this->fr_wheel_speed = 0ul;
      this->rl_wheel_speed = 0ul;
      this->rr_wheel_speed = 0ul;
    }
  }

  // field types and members
  using _front_axle_trq_type =
    uint32_t;
  _front_axle_trq_type front_axle_trq;
  using _rear_axle_trq_type =
    uint32_t;
  _rear_axle_trq_type rear_axle_trq;
  using _angle_type =
    int32_t;
  _angle_type angle;
  using _hyd_press_f_pct_type =
    uint32_t;
  _hyd_press_f_pct_type hyd_press_f_pct;
  using _hyd_press_r_pct_type =
    uint32_t;
  _hyd_press_r_pct_type hyd_press_r_pct;
  using _fl_wheel_speed_type =
    uint32_t;
  _fl_wheel_speed_type fl_wheel_speed;
  using _fr_wheel_speed_type =
    uint32_t;
  _fr_wheel_speed_type fr_wheel_speed;
  using _rl_wheel_speed_type =
    uint32_t;
  _rl_wheel_speed_type rl_wheel_speed;
  using _rr_wheel_speed_type =
    uint32_t;
  _rr_wheel_speed_type rr_wheel_speed;

  // setters for named parameter idiom
  Type & set__front_axle_trq(
    const uint32_t & _arg)
  {
    this->front_axle_trq = _arg;
    return *this;
  }
  Type & set__rear_axle_trq(
    const uint32_t & _arg)
  {
    this->rear_axle_trq = _arg;
    return *this;
  }
  Type & set__angle(
    const int32_t & _arg)
  {
    this->angle = _arg;
    return *this;
  }
  Type & set__hyd_press_f_pct(
    const uint32_t & _arg)
  {
    this->hyd_press_f_pct = _arg;
    return *this;
  }
  Type & set__hyd_press_r_pct(
    const uint32_t & _arg)
  {
    this->hyd_press_r_pct = _arg;
    return *this;
  }
  Type & set__fl_wheel_speed(
    const uint32_t & _arg)
  {
    this->fl_wheel_speed = _arg;
    return *this;
  }
  Type & set__fr_wheel_speed(
    const uint32_t & _arg)
  {
    this->fr_wheel_speed = _arg;
    return *this;
  }
  Type & set__rl_wheel_speed(
    const uint32_t & _arg)
  {
    this->rl_wheel_speed = _arg;
    return *this;
  }
  Type & set__rr_wheel_speed(
    const uint32_t & _arg)
  {
    this->rr_wheel_speed = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> *;
  using ConstRawPtr =
    const imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveFeedback
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveFeedback
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveFeedback_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VCUDriveFeedback_ & other) const
  {
    if (this->front_axle_trq != other.front_axle_trq) {
      return false;
    }
    if (this->rear_axle_trq != other.rear_axle_trq) {
      return false;
    }
    if (this->angle != other.angle) {
      return false;
    }
    if (this->hyd_press_f_pct != other.hyd_press_f_pct) {
      return false;
    }
    if (this->hyd_press_r_pct != other.hyd_press_r_pct) {
      return false;
    }
    if (this->fl_wheel_speed != other.fl_wheel_speed) {
      return false;
    }
    if (this->fr_wheel_speed != other.fr_wheel_speed) {
      return false;
    }
    if (this->rl_wheel_speed != other.rl_wheel_speed) {
      return false;
    }
    if (this->rr_wheel_speed != other.rr_wheel_speed) {
      return false;
    }
    return true;
  }
  bool operator!=(const VCUDriveFeedback_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VCUDriveFeedback_

// alias to use template instance with default allocator
using VCUDriveFeedback =
  imperial_driverless_interfaces::msg::VCUDriveFeedback_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__STRUCT_HPP_
