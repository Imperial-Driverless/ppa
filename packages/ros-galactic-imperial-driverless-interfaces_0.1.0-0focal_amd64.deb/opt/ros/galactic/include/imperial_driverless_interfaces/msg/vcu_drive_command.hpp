// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__VCU_DRIVE_COMMAND_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__VCU_DRIVE_COMMAND_HPP_

#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__struct.hpp"
#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__builder.hpp"
#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__traits.hpp"

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__VCU_DRIVE_COMMAND_HPP_
