// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from imperial_driverless_interfaces:msg/ConeMap.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__TRAITS_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__TRAITS_HPP_

#include "imperial_driverless_interfaces/msg/detail/cone_map__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'left_cones'
// Member 'right_cones'
// Member 'big_orange_cones'
// Member 'small_orange_cones'
#include "imperial_driverless_interfaces/msg/detail/cone__traits.hpp"

namespace rosidl_generator_traits
{

inline void to_yaml(
  const imperial_driverless_interfaces::msg::ConeMap & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_yaml(msg.header, out, indentation + 2);
  }

  // member: left_cones
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.left_cones.size() == 0) {
      out << "left_cones: []\n";
    } else {
      out << "left_cones:\n";
      for (auto item : msg.left_cones) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: right_cones
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.right_cones.size() == 0) {
      out << "right_cones: []\n";
    } else {
      out << "right_cones:\n";
      for (auto item : msg.right_cones) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: big_orange_cones
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.big_orange_cones.size() == 0) {
      out << "big_orange_cones: []\n";
    } else {
      out << "big_orange_cones:\n";
      for (auto item : msg.big_orange_cones) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: small_orange_cones
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.small_orange_cones.size() == 0) {
      out << "small_orange_cones: []\n";
    } else {
      out << "small_orange_cones:\n";
      for (auto item : msg.small_orange_cones) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const imperial_driverless_interfaces::msg::ConeMap & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<imperial_driverless_interfaces::msg::ConeMap>()
{
  return "imperial_driverless_interfaces::msg::ConeMap";
}

template<>
inline const char * name<imperial_driverless_interfaces::msg::ConeMap>()
{
  return "imperial_driverless_interfaces/msg/ConeMap";
}

template<>
struct has_fixed_size<imperial_driverless_interfaces::msg::ConeMap>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<imperial_driverless_interfaces::msg::ConeMap>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<imperial_driverless_interfaces::msg::ConeMap>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__TRAITS_HPP_
