// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__VEHICLE_COMMANDS_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__VEHICLE_COMMANDS_HPP_

#include "imperial_driverless_interfaces/msg/detail/vehicle_commands__struct.hpp"
#include "imperial_driverless_interfaces/msg/detail/vehicle_commands__builder.hpp"
#include "imperial_driverless_interfaces/msg/detail/vehicle_commands__traits.hpp"

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__VEHICLE_COMMANDS_HPP_
