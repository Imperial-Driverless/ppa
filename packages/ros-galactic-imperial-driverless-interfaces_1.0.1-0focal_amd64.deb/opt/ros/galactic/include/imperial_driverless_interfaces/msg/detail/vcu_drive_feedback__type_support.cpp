// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "imperial_driverless_interfaces/msg/detail/vcu_drive_feedback__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace imperial_driverless_interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void VCUDriveFeedback_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) imperial_driverless_interfaces::msg::VCUDriveFeedback(_init);
}

void VCUDriveFeedback_fini_function(void * message_memory)
{
  auto typed_message = static_cast<imperial_driverless_interfaces::msg::VCUDriveFeedback *>(message_memory);
  typed_message->~VCUDriveFeedback();
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember VCUDriveFeedback_message_member_array[5] = {
  {
    "steering_angle_rad",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::VCUDriveFeedback, steering_angle_rad),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "fl_wheel_speed_rpm",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::VCUDriveFeedback, fl_wheel_speed_rpm),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "fr_wheel_speed_rpm",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::VCUDriveFeedback, fr_wheel_speed_rpm),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "rl_wheel_speed_rpm",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::VCUDriveFeedback, rl_wheel_speed_rpm),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "rr_wheel_speed_rpm",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::VCUDriveFeedback, rr_wheel_speed_rpm),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers VCUDriveFeedback_message_members = {
  "imperial_driverless_interfaces::msg",  // message namespace
  "VCUDriveFeedback",  // message name
  5,  // number of fields
  sizeof(imperial_driverless_interfaces::msg::VCUDriveFeedback),
  VCUDriveFeedback_message_member_array,  // message members
  VCUDriveFeedback_init_function,  // function to initialize message memory (memory has to be allocated)
  VCUDriveFeedback_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t VCUDriveFeedback_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &VCUDriveFeedback_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace imperial_driverless_interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<imperial_driverless_interfaces::msg::VCUDriveFeedback>()
{
  return &::imperial_driverless_interfaces::msg::rosidl_typesupport_introspection_cpp::VCUDriveFeedback_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, imperial_driverless_interfaces, msg, VCUDriveFeedback)() {
  return &::imperial_driverless_interfaces::msg::rosidl_typesupport_introspection_cpp::VCUDriveFeedback_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
