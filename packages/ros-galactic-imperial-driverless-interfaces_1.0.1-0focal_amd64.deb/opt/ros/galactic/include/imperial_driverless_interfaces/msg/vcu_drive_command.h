// generated from rosidl_generator_c/resource/idl.h.em
// with input from imperial_driverless_interfaces:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__VCU_DRIVE_COMMAND_H_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__VCU_DRIVE_COMMAND_H_

#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__struct.h"
#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__functions.h"
#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__type_support.h"

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__VCU_DRIVE_COMMAND_H_
