// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from imperial_driverless_interfaces:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__STRUCT_H_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/VCUDriveFeedback in the package imperial_driverless_interfaces.
typedef struct imperial_driverless_interfaces__msg__VCUDriveFeedback
{
  double steering_angle_rad;
  uint32_t fl_wheel_speed_rpm;
  uint32_t fr_wheel_speed_rpm;
  uint32_t rl_wheel_speed_rpm;
  uint32_t rr_wheel_speed_rpm;
} imperial_driverless_interfaces__msg__VCUDriveFeedback;

// Struct for a sequence of imperial_driverless_interfaces__msg__VCUDriveFeedback.
typedef struct imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence
{
  imperial_driverless_interfaces__msg__VCUDriveFeedback * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__STRUCT_H_
