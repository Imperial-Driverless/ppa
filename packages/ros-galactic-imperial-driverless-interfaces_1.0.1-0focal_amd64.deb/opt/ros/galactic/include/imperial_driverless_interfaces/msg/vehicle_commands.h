// generated from rosidl_generator_c/resource/idl.h.em
// with input from imperial_driverless_interfaces:msg/VehicleCommands.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__VEHICLE_COMMANDS_H_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__VEHICLE_COMMANDS_H_

#include "imperial_driverless_interfaces/msg/detail/vehicle_commands__struct.h"
#include "imperial_driverless_interfaces/msg/detail/vehicle_commands__functions.h"
#include "imperial_driverless_interfaces/msg/detail/vehicle_commands__type_support.h"

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__VEHICLE_COMMANDS_H_
