// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__BUILDER_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__BUILDER_HPP_

#include "imperial_driverless_interfaces/msg/detail/vcu_drive_feedback__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace imperial_driverless_interfaces
{

namespace msg
{

namespace builder
{

class Init_VCUDriveFeedback_rr_wheel_speed_rpm
{
public:
  explicit Init_VCUDriveFeedback_rr_wheel_speed_rpm(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback rr_wheel_speed_rpm(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_rr_wheel_speed_rpm_type arg)
  {
    msg_.rr_wheel_speed_rpm = std::move(arg);
    return std::move(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_rl_wheel_speed_rpm
{
public:
  explicit Init_VCUDriveFeedback_rl_wheel_speed_rpm(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_rr_wheel_speed_rpm rl_wheel_speed_rpm(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_rl_wheel_speed_rpm_type arg)
  {
    msg_.rl_wheel_speed_rpm = std::move(arg);
    return Init_VCUDriveFeedback_rr_wheel_speed_rpm(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_fr_wheel_speed_rpm
{
public:
  explicit Init_VCUDriveFeedback_fr_wheel_speed_rpm(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_rl_wheel_speed_rpm fr_wheel_speed_rpm(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_fr_wheel_speed_rpm_type arg)
  {
    msg_.fr_wheel_speed_rpm = std::move(arg);
    return Init_VCUDriveFeedback_rl_wheel_speed_rpm(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_fl_wheel_speed_rpm
{
public:
  explicit Init_VCUDriveFeedback_fl_wheel_speed_rpm(::imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
  : msg_(msg)
  {}
  Init_VCUDriveFeedback_fr_wheel_speed_rpm fl_wheel_speed_rpm(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_fl_wheel_speed_rpm_type arg)
  {
    msg_.fl_wheel_speed_rpm = std::move(arg);
    return Init_VCUDriveFeedback_fr_wheel_speed_rpm(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

class Init_VCUDriveFeedback_steering_angle_rad
{
public:
  Init_VCUDriveFeedback_steering_angle_rad()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VCUDriveFeedback_fl_wheel_speed_rpm steering_angle_rad(::imperial_driverless_interfaces::msg::VCUDriveFeedback::_steering_angle_rad_type arg)
  {
    msg_.steering_angle_rad = std::move(arg);
    return Init_VCUDriveFeedback_fl_wheel_speed_rpm(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveFeedback msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::imperial_driverless_interfaces::msg::VCUDriveFeedback>()
{
  return imperial_driverless_interfaces::msg::builder::Init_VCUDriveFeedback_steering_angle_rad();
}

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__BUILDER_HPP_
