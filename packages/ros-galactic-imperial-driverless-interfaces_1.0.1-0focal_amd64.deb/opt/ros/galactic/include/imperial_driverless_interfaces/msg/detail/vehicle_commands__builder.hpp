// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from imperial_driverless_interfaces:msg/VehicleCommands.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VEHICLE_COMMANDS__BUILDER_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VEHICLE_COMMANDS__BUILDER_HPP_

#include "imperial_driverless_interfaces/msg/detail/vehicle_commands__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace imperial_driverless_interfaces
{

namespace msg
{

namespace builder
{

class Init_VehicleCommands_rpm
{
public:
  explicit Init_VehicleCommands_rpm(::imperial_driverless_interfaces::msg::VehicleCommands & msg)
  : msg_(msg)
  {}
  ::imperial_driverless_interfaces::msg::VehicleCommands rpm(::imperial_driverless_interfaces::msg::VehicleCommands::_rpm_type arg)
  {
    msg_.rpm = std::move(arg);
    return std::move(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VehicleCommands msg_;
};

class Init_VehicleCommands_steering
{
public:
  explicit Init_VehicleCommands_steering(::imperial_driverless_interfaces::msg::VehicleCommands & msg)
  : msg_(msg)
  {}
  Init_VehicleCommands_rpm steering(::imperial_driverless_interfaces::msg::VehicleCommands::_steering_type arg)
  {
    msg_.steering = std::move(arg);
    return Init_VehicleCommands_rpm(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VehicleCommands msg_;
};

class Init_VehicleCommands_torque
{
public:
  explicit Init_VehicleCommands_torque(::imperial_driverless_interfaces::msg::VehicleCommands & msg)
  : msg_(msg)
  {}
  Init_VehicleCommands_steering torque(::imperial_driverless_interfaces::msg::VehicleCommands::_torque_type arg)
  {
    msg_.torque = std::move(arg);
    return Init_VehicleCommands_steering(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VehicleCommands msg_;
};

class Init_VehicleCommands_braking
{
public:
  explicit Init_VehicleCommands_braking(::imperial_driverless_interfaces::msg::VehicleCommands & msg)
  : msg_(msg)
  {}
  Init_VehicleCommands_torque braking(::imperial_driverless_interfaces::msg::VehicleCommands::_braking_type arg)
  {
    msg_.braking = std::move(arg);
    return Init_VehicleCommands_torque(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VehicleCommands msg_;
};

class Init_VehicleCommands_mission_status
{
public:
  explicit Init_VehicleCommands_mission_status(::imperial_driverless_interfaces::msg::VehicleCommands & msg)
  : msg_(msg)
  {}
  Init_VehicleCommands_braking mission_status(::imperial_driverless_interfaces::msg::VehicleCommands::_mission_status_type arg)
  {
    msg_.mission_status = std::move(arg);
    return Init_VehicleCommands_braking(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VehicleCommands msg_;
};

class Init_VehicleCommands_direction
{
public:
  explicit Init_VehicleCommands_direction(::imperial_driverless_interfaces::msg::VehicleCommands & msg)
  : msg_(msg)
  {}
  Init_VehicleCommands_mission_status direction(::imperial_driverless_interfaces::msg::VehicleCommands::_direction_type arg)
  {
    msg_.direction = std::move(arg);
    return Init_VehicleCommands_mission_status(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VehicleCommands msg_;
};

class Init_VehicleCommands_ebs
{
public:
  explicit Init_VehicleCommands_ebs(::imperial_driverless_interfaces::msg::VehicleCommands & msg)
  : msg_(msg)
  {}
  Init_VehicleCommands_direction ebs(::imperial_driverless_interfaces::msg::VehicleCommands::_ebs_type arg)
  {
    msg_.ebs = std::move(arg);
    return Init_VehicleCommands_direction(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VehicleCommands msg_;
};

class Init_VehicleCommands_handshake
{
public:
  Init_VehicleCommands_handshake()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VehicleCommands_ebs handshake(::imperial_driverless_interfaces::msg::VehicleCommands::_handshake_type arg)
  {
    msg_.handshake = std::move(arg);
    return Init_VehicleCommands_ebs(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VehicleCommands msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::imperial_driverless_interfaces::msg::VehicleCommands>()
{
  return imperial_driverless_interfaces::msg::builder::Init_VehicleCommands_handshake();
}

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VEHICLE_COMMANDS__BUILDER_HPP_
