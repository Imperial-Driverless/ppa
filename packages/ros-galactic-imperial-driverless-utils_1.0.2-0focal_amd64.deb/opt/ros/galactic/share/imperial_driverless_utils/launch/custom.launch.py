from pathlib import Path
from typing import List, Tuple
from launch import LaunchDescription
from launch.substitutions import PathJoinSubstitution
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.launch_description_sources.python_launch_description_source import PythonLaunchDescriptionSource

from ament_index_python.packages import get_package_share_path
import click
from launch.launch_description_entity import LaunchDescriptionEntity


def green(x: str, /): return click.style(x, fg='green')


def choose_vehicle() -> Tuple[List[LaunchDescriptionEntity], Path]:
    vehicle_descriptions_share = get_package_share_path('vehicle_descriptions')
    vehicle_name = 'ads_dv'
    config_yaml_path = vehicle_descriptions_share / 'vehicles' / vehicle_name / 'config.yaml'
    click.echo('Using vehicle ' + green(vehicle_name) + '.\n')

    include_vehicle_ld = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            str(vehicle_descriptions_share / 'launch' / 'simple.launch.py')
        ),
        launch_arguments=[
            ('vehicle_name', vehicle_name)
        ]
    )

    return [include_vehicle_ld], config_yaml_path


def generate_launch_description():
    this_launch_file_dir = str(get_package_share_path('imperial_driverless_utils') / 'launch')

    vehicle_ld, vehicle_config_file = choose_vehicle()

    simulation_environment = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                this_launch_file_dir,
                'setup_simulation_environment.launch.py',
            ])
        ),
        launch_arguments=[
            ('vehicle_config_file', str(vehicle_config_file))
        ]
    )

    software_stack = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                this_launch_file_dir,
                'software_stack.launch.py',
            ]),
        ),
        launch_arguments=[
            ('vehicle_config_file', str(vehicle_config_file))
        ]
    )

    return LaunchDescription([
        *vehicle_ld,
        simulation_environment,
        software_stack,
    ])
