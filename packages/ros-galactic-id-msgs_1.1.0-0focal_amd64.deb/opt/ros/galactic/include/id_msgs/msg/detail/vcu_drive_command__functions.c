// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from id_msgs:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice
#include "id_msgs/msg/detail/vcu_drive_command__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
id_msgs__msg__VCUDriveCommand__init(id_msgs__msg__VCUDriveCommand * msg)
{
  if (!msg) {
    return false;
  }
  // motor_torque_nm
  // steering_angle_rad
  // brake_pct
  // rpm_limit
  return true;
}

void
id_msgs__msg__VCUDriveCommand__fini(id_msgs__msg__VCUDriveCommand * msg)
{
  if (!msg) {
    return;
  }
  // motor_torque_nm
  // steering_angle_rad
  // brake_pct
  // rpm_limit
}

bool
id_msgs__msg__VCUDriveCommand__are_equal(const id_msgs__msg__VCUDriveCommand * lhs, const id_msgs__msg__VCUDriveCommand * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // motor_torque_nm
  if (lhs->motor_torque_nm != rhs->motor_torque_nm) {
    return false;
  }
  // steering_angle_rad
  if (lhs->steering_angle_rad != rhs->steering_angle_rad) {
    return false;
  }
  // brake_pct
  if (lhs->brake_pct != rhs->brake_pct) {
    return false;
  }
  // rpm_limit
  if (lhs->rpm_limit != rhs->rpm_limit) {
    return false;
  }
  return true;
}

bool
id_msgs__msg__VCUDriveCommand__copy(
  const id_msgs__msg__VCUDriveCommand * input,
  id_msgs__msg__VCUDriveCommand * output)
{
  if (!input || !output) {
    return false;
  }
  // motor_torque_nm
  output->motor_torque_nm = input->motor_torque_nm;
  // steering_angle_rad
  output->steering_angle_rad = input->steering_angle_rad;
  // brake_pct
  output->brake_pct = input->brake_pct;
  // rpm_limit
  output->rpm_limit = input->rpm_limit;
  return true;
}

id_msgs__msg__VCUDriveCommand *
id_msgs__msg__VCUDriveCommand__create()
{
  id_msgs__msg__VCUDriveCommand * msg = (id_msgs__msg__VCUDriveCommand *)malloc(sizeof(id_msgs__msg__VCUDriveCommand));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(id_msgs__msg__VCUDriveCommand));
  bool success = id_msgs__msg__VCUDriveCommand__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
id_msgs__msg__VCUDriveCommand__destroy(id_msgs__msg__VCUDriveCommand * msg)
{
  if (msg) {
    id_msgs__msg__VCUDriveCommand__fini(msg);
  }
  free(msg);
}


bool
id_msgs__msg__VCUDriveCommand__Sequence__init(id_msgs__msg__VCUDriveCommand__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  id_msgs__msg__VCUDriveCommand * data = NULL;
  if (size) {
    data = (id_msgs__msg__VCUDriveCommand *)calloc(size, sizeof(id_msgs__msg__VCUDriveCommand));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = id_msgs__msg__VCUDriveCommand__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        id_msgs__msg__VCUDriveCommand__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
id_msgs__msg__VCUDriveCommand__Sequence__fini(id_msgs__msg__VCUDriveCommand__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      id_msgs__msg__VCUDriveCommand__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

id_msgs__msg__VCUDriveCommand__Sequence *
id_msgs__msg__VCUDriveCommand__Sequence__create(size_t size)
{
  id_msgs__msg__VCUDriveCommand__Sequence * array = (id_msgs__msg__VCUDriveCommand__Sequence *)malloc(sizeof(id_msgs__msg__VCUDriveCommand__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = id_msgs__msg__VCUDriveCommand__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
id_msgs__msg__VCUDriveCommand__Sequence__destroy(id_msgs__msg__VCUDriveCommand__Sequence * array)
{
  if (array) {
    id_msgs__msg__VCUDriveCommand__Sequence__fini(array);
  }
  free(array);
}

bool
id_msgs__msg__VCUDriveCommand__Sequence__are_equal(const id_msgs__msg__VCUDriveCommand__Sequence * lhs, const id_msgs__msg__VCUDriveCommand__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!id_msgs__msg__VCUDriveCommand__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
id_msgs__msg__VCUDriveCommand__Sequence__copy(
  const id_msgs__msg__VCUDriveCommand__Sequence * input,
  id_msgs__msg__VCUDriveCommand__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(id_msgs__msg__VCUDriveCommand);
    id_msgs__msg__VCUDriveCommand * data =
      (id_msgs__msg__VCUDriveCommand *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!id_msgs__msg__VCUDriveCommand__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          id_msgs__msg__VCUDriveCommand__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!id_msgs__msg__VCUDriveCommand__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
