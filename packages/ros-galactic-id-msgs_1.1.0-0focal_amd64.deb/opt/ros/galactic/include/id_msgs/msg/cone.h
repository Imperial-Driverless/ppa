// generated from rosidl_generator_c/resource/idl.h.em
// with input from id_msgs:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__CONE_H_
#define ID_MSGS__MSG__CONE_H_

#include "id_msgs/msg/detail/cone__struct.h"
#include "id_msgs/msg/detail/cone__functions.h"
#include "id_msgs/msg/detail/cone__type_support.h"

#endif  // ID_MSGS__MSG__CONE_H_
