// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from id_msgs:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__DETAIL__VCU_DRIVE_COMMAND__BUILDER_HPP_
#define ID_MSGS__MSG__DETAIL__VCU_DRIVE_COMMAND__BUILDER_HPP_

#include "id_msgs/msg/detail/vcu_drive_command__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace id_msgs
{

namespace msg
{

namespace builder
{

class Init_VCUDriveCommand_rpm_limit
{
public:
  explicit Init_VCUDriveCommand_rpm_limit(::id_msgs::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  ::id_msgs::msg::VCUDriveCommand rpm_limit(::id_msgs::msg::VCUDriveCommand::_rpm_limit_type arg)
  {
    msg_.rpm_limit = std::move(arg);
    return std::move(msg_);
  }

private:
  ::id_msgs::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_brake_pct
{
public:
  explicit Init_VCUDriveCommand_brake_pct(::id_msgs::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  Init_VCUDriveCommand_rpm_limit brake_pct(::id_msgs::msg::VCUDriveCommand::_brake_pct_type arg)
  {
    msg_.brake_pct = std::move(arg);
    return Init_VCUDriveCommand_rpm_limit(msg_);
  }

private:
  ::id_msgs::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_steering_angle_rad
{
public:
  explicit Init_VCUDriveCommand_steering_angle_rad(::id_msgs::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  Init_VCUDriveCommand_brake_pct steering_angle_rad(::id_msgs::msg::VCUDriveCommand::_steering_angle_rad_type arg)
  {
    msg_.steering_angle_rad = std::move(arg);
    return Init_VCUDriveCommand_brake_pct(msg_);
  }

private:
  ::id_msgs::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_motor_torque_nm
{
public:
  Init_VCUDriveCommand_motor_torque_nm()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VCUDriveCommand_steering_angle_rad motor_torque_nm(::id_msgs::msg::VCUDriveCommand::_motor_torque_nm_type arg)
  {
    msg_.motor_torque_nm = std::move(arg);
    return Init_VCUDriveCommand_steering_angle_rad(msg_);
  }

private:
  ::id_msgs::msg::VCUDriveCommand msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::id_msgs::msg::VCUDriveCommand>()
{
  return id_msgs::msg::builder::Init_VCUDriveCommand_motor_torque_nm();
}

}  // namespace id_msgs

#endif  // ID_MSGS__MSG__DETAIL__VCU_DRIVE_COMMAND__BUILDER_HPP_
