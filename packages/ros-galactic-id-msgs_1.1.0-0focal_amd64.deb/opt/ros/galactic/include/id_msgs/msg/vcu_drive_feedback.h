// generated from rosidl_generator_c/resource/idl.h.em
// with input from id_msgs:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__VCU_DRIVE_FEEDBACK_H_
#define ID_MSGS__MSG__VCU_DRIVE_FEEDBACK_H_

#include "id_msgs/msg/detail/vcu_drive_feedback__struct.h"
#include "id_msgs/msg/detail/vcu_drive_feedback__functions.h"
#include "id_msgs/msg/detail/vcu_drive_feedback__type_support.h"

#endif  // ID_MSGS__MSG__VCU_DRIVE_FEEDBACK_H_
