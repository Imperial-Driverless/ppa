// generated from rosidl_generator_c/resource/idl.h.em
// with input from id_msgs:msg/CanState.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__CAN_STATE_H_
#define ID_MSGS__MSG__CAN_STATE_H_

#include "id_msgs/msg/detail/can_state__struct.h"
#include "id_msgs/msg/detail/can_state__functions.h"
#include "id_msgs/msg/detail/can_state__type_support.h"

#endif  // ID_MSGS__MSG__CAN_STATE_H_
