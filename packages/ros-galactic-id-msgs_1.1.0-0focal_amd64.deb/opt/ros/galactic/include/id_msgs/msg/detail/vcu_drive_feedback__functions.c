// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from id_msgs:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice
#include "id_msgs/msg/detail/vcu_drive_feedback__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
id_msgs__msg__VCUDriveFeedback__init(id_msgs__msg__VCUDriveFeedback * msg)
{
  if (!msg) {
    return false;
  }
  // steering_angle_rad
  // fl_wheel_speed_rpm
  // fr_wheel_speed_rpm
  // rl_wheel_speed_rpm
  // rr_wheel_speed_rpm
  return true;
}

void
id_msgs__msg__VCUDriveFeedback__fini(id_msgs__msg__VCUDriveFeedback * msg)
{
  if (!msg) {
    return;
  }
  // steering_angle_rad
  // fl_wheel_speed_rpm
  // fr_wheel_speed_rpm
  // rl_wheel_speed_rpm
  // rr_wheel_speed_rpm
}

bool
id_msgs__msg__VCUDriveFeedback__are_equal(const id_msgs__msg__VCUDriveFeedback * lhs, const id_msgs__msg__VCUDriveFeedback * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // steering_angle_rad
  if (lhs->steering_angle_rad != rhs->steering_angle_rad) {
    return false;
  }
  // fl_wheel_speed_rpm
  if (lhs->fl_wheel_speed_rpm != rhs->fl_wheel_speed_rpm) {
    return false;
  }
  // fr_wheel_speed_rpm
  if (lhs->fr_wheel_speed_rpm != rhs->fr_wheel_speed_rpm) {
    return false;
  }
  // rl_wheel_speed_rpm
  if (lhs->rl_wheel_speed_rpm != rhs->rl_wheel_speed_rpm) {
    return false;
  }
  // rr_wheel_speed_rpm
  if (lhs->rr_wheel_speed_rpm != rhs->rr_wheel_speed_rpm) {
    return false;
  }
  return true;
}

bool
id_msgs__msg__VCUDriveFeedback__copy(
  const id_msgs__msg__VCUDriveFeedback * input,
  id_msgs__msg__VCUDriveFeedback * output)
{
  if (!input || !output) {
    return false;
  }
  // steering_angle_rad
  output->steering_angle_rad = input->steering_angle_rad;
  // fl_wheel_speed_rpm
  output->fl_wheel_speed_rpm = input->fl_wheel_speed_rpm;
  // fr_wheel_speed_rpm
  output->fr_wheel_speed_rpm = input->fr_wheel_speed_rpm;
  // rl_wheel_speed_rpm
  output->rl_wheel_speed_rpm = input->rl_wheel_speed_rpm;
  // rr_wheel_speed_rpm
  output->rr_wheel_speed_rpm = input->rr_wheel_speed_rpm;
  return true;
}

id_msgs__msg__VCUDriveFeedback *
id_msgs__msg__VCUDriveFeedback__create()
{
  id_msgs__msg__VCUDriveFeedback * msg = (id_msgs__msg__VCUDriveFeedback *)malloc(sizeof(id_msgs__msg__VCUDriveFeedback));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(id_msgs__msg__VCUDriveFeedback));
  bool success = id_msgs__msg__VCUDriveFeedback__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
id_msgs__msg__VCUDriveFeedback__destroy(id_msgs__msg__VCUDriveFeedback * msg)
{
  if (msg) {
    id_msgs__msg__VCUDriveFeedback__fini(msg);
  }
  free(msg);
}


bool
id_msgs__msg__VCUDriveFeedback__Sequence__init(id_msgs__msg__VCUDriveFeedback__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  id_msgs__msg__VCUDriveFeedback * data = NULL;
  if (size) {
    data = (id_msgs__msg__VCUDriveFeedback *)calloc(size, sizeof(id_msgs__msg__VCUDriveFeedback));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = id_msgs__msg__VCUDriveFeedback__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        id_msgs__msg__VCUDriveFeedback__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
id_msgs__msg__VCUDriveFeedback__Sequence__fini(id_msgs__msg__VCUDriveFeedback__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      id_msgs__msg__VCUDriveFeedback__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

id_msgs__msg__VCUDriveFeedback__Sequence *
id_msgs__msg__VCUDriveFeedback__Sequence__create(size_t size)
{
  id_msgs__msg__VCUDriveFeedback__Sequence * array = (id_msgs__msg__VCUDriveFeedback__Sequence *)malloc(sizeof(id_msgs__msg__VCUDriveFeedback__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = id_msgs__msg__VCUDriveFeedback__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
id_msgs__msg__VCUDriveFeedback__Sequence__destroy(id_msgs__msg__VCUDriveFeedback__Sequence * array)
{
  if (array) {
    id_msgs__msg__VCUDriveFeedback__Sequence__fini(array);
  }
  free(array);
}

bool
id_msgs__msg__VCUDriveFeedback__Sequence__are_equal(const id_msgs__msg__VCUDriveFeedback__Sequence * lhs, const id_msgs__msg__VCUDriveFeedback__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!id_msgs__msg__VCUDriveFeedback__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
id_msgs__msg__VCUDriveFeedback__Sequence__copy(
  const id_msgs__msg__VCUDriveFeedback__Sequence * input,
  id_msgs__msg__VCUDriveFeedback__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(id_msgs__msg__VCUDriveFeedback);
    id_msgs__msg__VCUDriveFeedback * data =
      (id_msgs__msg__VCUDriveFeedback *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!id_msgs__msg__VCUDriveFeedback__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          id_msgs__msg__VCUDriveFeedback__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!id_msgs__msg__VCUDriveFeedback__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
