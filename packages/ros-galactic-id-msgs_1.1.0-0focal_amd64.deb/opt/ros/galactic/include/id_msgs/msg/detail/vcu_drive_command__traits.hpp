// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from id_msgs:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__DETAIL__VCU_DRIVE_COMMAND__TRAITS_HPP_
#define ID_MSGS__MSG__DETAIL__VCU_DRIVE_COMMAND__TRAITS_HPP_

#include "id_msgs/msg/detail/vcu_drive_command__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace rosidl_generator_traits
{

inline void to_yaml(
  const id_msgs::msg::VCUDriveCommand & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: motor_torque_nm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motor_torque_nm: ";
    value_to_yaml(msg.motor_torque_nm, out);
    out << "\n";
  }

  // member: steering_angle_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_angle_rad: ";
    value_to_yaml(msg.steering_angle_rad, out);
    out << "\n";
  }

  // member: brake_pct
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "brake_pct: ";
    value_to_yaml(msg.brake_pct, out);
    out << "\n";
  }

  // member: rpm_limit
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rpm_limit: ";
    value_to_yaml(msg.rpm_limit, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const id_msgs::msg::VCUDriveCommand & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<id_msgs::msg::VCUDriveCommand>()
{
  return "id_msgs::msg::VCUDriveCommand";
}

template<>
inline const char * name<id_msgs::msg::VCUDriveCommand>()
{
  return "id_msgs/msg/VCUDriveCommand";
}

template<>
struct has_fixed_size<id_msgs::msg::VCUDriveCommand>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<id_msgs::msg::VCUDriveCommand>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<id_msgs::msg::VCUDriveCommand>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ID_MSGS__MSG__DETAIL__VCU_DRIVE_COMMAND__TRAITS_HPP_
