// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from id_msgs:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef ID_MSGS__MSG__DETAIL__CONE__BUILDER_HPP_
#define ID_MSGS__MSG__DETAIL__CONE__BUILDER_HPP_

#include "id_msgs/msg/detail/cone__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace id_msgs
{

namespace msg
{

namespace builder
{

class Init_Cone_position
{
public:
  Init_Cone_position()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::id_msgs::msg::Cone position(::id_msgs::msg::Cone::_position_type arg)
  {
    msg_.position = std::move(arg);
    return std::move(msg_);
  }

private:
  ::id_msgs::msg::Cone msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::id_msgs::msg::Cone>()
{
  return id_msgs::msg::builder::Init_Cone_position();
}

}  // namespace id_msgs

#endif  // ID_MSGS__MSG__DETAIL__CONE__BUILDER_HPP_
