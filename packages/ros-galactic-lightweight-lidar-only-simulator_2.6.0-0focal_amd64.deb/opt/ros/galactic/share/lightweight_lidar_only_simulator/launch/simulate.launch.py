"""
This will launch the simulator and the Nav2 map server. 
This will NOT launch: the GUI, the vehicle model nor any teleoperation script.
Please use the custom.launch.py launchfile from imperial_driverless_utils to
launch everything at once.
"""

from datetime import timedelta
from pathlib import Path
from tempfile import mkdtemp

import lifecycle_msgs.msg
from ament_index_python.packages import get_package_share_directory
from id_track_utils import Track
from launch_ros.actions import LifecycleNode, Node
from launch_ros.event_handlers import OnStateTransition
from launch_ros.events.lifecycle import ChangeState

import launch
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, EmitEvent, ExecuteProcess,
                            OpaqueFunction, RegisterEventHandler)
from launch.substitutions import LaunchConfiguration

import yaml

def delayed(e: EmitEvent, by: timedelta) -> ExecuteProcess:
    return ExecuteProcess(
        cmd=['sleep', str(by.total_seconds())],
        on_exit=[
            e
        ]
    )

def launch_map_server(context, *args, **kwargs):
    track_file = LaunchConfiguration('track_file').perform(context)
    
    if not track_file:
        raise Exception(
            'No track file specified. Use `ros2 launch lighweight_lidar_only_simulator '
            'simulate.launch.py track_file:=<path to track file>` to specify one.')

    t = Track.load_from_file(track_file)
    tmp_dir = Path(mkdtemp())

    resolution = 0.03
    map_image, orig_x, orig_y = t.as_occupancy_grid(resolution=resolution, cone_radius=0.10)
    


    map_image.save(tmp_dir / 'map.png')
    map_yaml_file = tmp_dir / 'map.yaml'
    map_yaml_file.write_text(f"""
        image: map.png
        resolution: {resolution}
        origin:  [{orig_x}, {orig_y}, 0.]
        negate: 0
        occupied_thresh: 0.8
        free_thresh: 0.2
        """
    )

    # ================
    # == MAP SERVER ==
    # ================
    map_server_node = LifecycleNode(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        namespace='',
        parameters=[
            {'yaml_filename': str(map_yaml_file)},
            {'topic_name': '/ground_truth/map'}
        ])

    map_server_emit_activation_event = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=launch.events.matches_action(
                map_server_node),
            transition_id=lifecycle_msgs.msg.Transition.TRANSITION_ACTIVATE,
        ))

    map_server_emit_configure_event = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=launch.events.matches_action(
                map_server_node),
            transition_id=lifecycle_msgs.msg.Transition.TRANSITION_CONFIGURE,
        ))

    map_server_inactive_state_handler = RegisterEventHandler(
        OnStateTransition(
            target_lifecycle_node=map_server_node,
            goal_state='inactive',
            entities=[map_server_emit_activation_event],
        ))

    return [
        map_server_node, 
        map_server_inactive_state_handler, 
        delayed(map_server_emit_configure_event, timedelta(seconds=2.)), 
    ]

def launch_simulator(context, *args, **kwargs):
    vehicle_config_file = Path(LaunchConfiguration('vehicle_config_file').perform(context))

    config = yaml.safe_load(vehicle_config_file.read_text())
    lidar_config = config['sensors']['lidar']

    package_dir = get_package_share_directory('lightweight_lidar_only_simulator')
    return [
        Node(
            package='lightweight_lidar_only_simulator',
            executable='simulate',
            name='lightweight_lidar_only_simulator',
            output='screen',
            parameters=[
                {'broadcast_transform': LaunchConfiguration('broadcast_transform')},
                {'scan_beams': lidar_config['num_beams']},
                {'scan_field_of_view': float(lidar_config['fov'])},
                {'scan_std_dev': float(lidar_config['noise_std_dev'])},
                {'scan_frequency': float(lidar_config['update_rate'])},
                f'{package_dir}/config/params.yaml',
            ]
        )
    ]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument(name='broadcast_transform', default_value='true', 
            description='Whether to broadcast the map->odom->base_link transform'),

        DeclareLaunchArgument(name='track_file', default_value='', 
            description='Path to the track definition file in a format supported by id_track_utils'),

        DeclareLaunchArgument('vehicle_config_file', 
            description='Path to a vehicle config.yaml file'),
        
        OpaqueFunction(function=launch_map_server),
        OpaqueFunction(function=launch_simulator),
    ])


if __name__ == '__main__':
    generate_launch_description()
