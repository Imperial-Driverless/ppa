from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='lidar_camera_fusion',
            executable='sensor_fusion',
            name='sensor_fusion',
            output='screen',
            parameters=[
                {'use_sim_time': True}
            ],
            remappings=[
                ('/perceived_cones/camera', '/ground_truth/cone_map'),
            ]
        )
    ])
