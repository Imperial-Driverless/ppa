import os
from tempfile import mkdtemp

import click
from launch.actions.execute_process import ExecuteProcess
from launch_ros.actions import Node
from launch_ros.substitutions.find_package import FindPackageShare
from launch import LaunchDescription
from launch.actions import RegisterEventHandler, EmitEvent
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.events import Shutdown
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources.python_launch_description_source import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from ros2pkg.api import get_executable_paths, PackageNotFound

from ament_index_python.packages import get_package_share_path

import imperial_driverless_utils


collection_pkgs = {
    'lidar_only_cone_detector': 'https://github.com/Imperial-Driverless/lidar_only_cone_detector',
    'slam_implementations':     'https://github.com/Imperial-Driverless/slam_implementations',
    'path_generators':          'https://github.com/Imperial-Driverless/path_generators',
}


def generate_launch_description():
    ld = base_launch_description()


    for e in ground_truth_cone_map():
        ld.add_entity(e)


    for pkg in collection_pkgs:

        try:
            found_executables = get_executable_names(pkg)
            click.echo(f'Select an executable from package {pkg}:')
            click.echo(f"0. {click.style('do not launch any executable from this package', fg='yellow')}")
            for i, executable in enumerate(found_executables, 1):
                click.echo( f"{i}. {click.style(executable, fg='green')}")

            selection = int(click.prompt(
                "Please select:",
                type=click.Choice([str(i) for i in range(len(found_executables) + 1)]),
                default="0",
                show_choices=False,
            ))

            if selection > 0:
                selected = found_executables[selection-1]
                click.echo(f'You selected {selected} from {pkg}\n')

                ld.add_entity(Node(
                    package=pkg,
                    executable=selected,
                    name=selected,
                    output='screen',
                ))

        except PackageNotFound:
            click.echo(click.style(f'Package {pkg} not found. What to do?', fg='red'))
            click.echo(f"0. {click.style('Ignore, I will start it myself', fg='yellow')}")
            click.echo(f"1. {click.style('Clone from GitHub, build and source', fg='yellow')}")
            selection = int(click.prompt(
                "Please select:",
                type=click.Choice([str(i) for i in range(2)]),
                default="0",
                show_choices=False,
            ))

            if selection == 0:
                pass
            elif selection == 1:
                click.echo(f"This script can't currently do that for you. Here's the link: {collection_pkgs[pkg]}")

    return ld


def ground_truth_cone_map():
    cone_map_folder = get_package_share_path('imperial_driverless_utils') / 'cone_maps'

    cone_map_paths = [x for x in cone_map_folder.iterdir()]

    click.echo(f'Select a cone map:')
    for i, cone_map in enumerate(cone_map_paths):
        click.echo( f"{i}. {click.style(cone_map.name, fg='green')}")

    selection = int(click.prompt(
        "Please select:",
        type=click.Choice([str(i) for i in range(len(cone_map_paths))]),
        default="0",
        show_choices=False,
    ))

    ld = []

    ground_truth_cone_map = cone_map_paths[selection].read_text()

    ld.append(ExecuteProcess(
        cmd=['ros2', 'topic', 'pub', '/ground_truth/cone_map', 'imperial_driverless_interfaces/msg/ConeMap', ground_truth_cone_map]))

    # using the version of topic_tools from https://github.com/mateusz-lichota/topic_tools
    ld.append(Node(
        package='topic_tools',
        executable='transform',
        namespace='/ground_truth',
        name='transform',
        output='screen',
        emulate_tty=True,
        parameters=[
            {'input': '/ground_truth/cone_map'},
            {'output-topic': '/ground_truth/cone_map_rviz'},
            {'output-type': 'visualization_msgs/MarkerArray'},
            {'expression': 'idi_msgs_to_rviz_markers.conemap_to_markerarray(m)'},
            {'import': ['idi_msgs_to_rviz_markers']},
            {'wait-for-start': True},
        ])
    )

    return ld

def get_executable_names(package_name):
    return [os.path.basename(path) for path in get_executable_paths(package_name=package_name)]



def base_launch_description():

    tmp_dir = mkdtemp()
    rviz_config_file_name = tmp_dir + '/rviz_config.rviz'
    with open(rviz_config_file_name, 'w+') as f:
        f.write(imperial_driverless_utils.rviz_config)

    simulator = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('lightweight_lidar_only_simulator'),
                'launch/simulate_no_gui.launch.py'
            ])
        )
    )

    teleop = Node(
        package='ackermann_drive_teleop',
        executable='keyop',
        name='ackermann_drive_teleop',
    )

    # ============
    # ==  RVIZ  ==
    # ============
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_file_name])

    shutdown_on_rviz_exit = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=rviz_node,
            on_exit=[
                EmitEvent(event=Shutdown()),
            ],
        ))


    return LaunchDescription([
        simulator,
        teleop,
        rviz_node,
        shutdown_on_rviz_exit,
    ])

