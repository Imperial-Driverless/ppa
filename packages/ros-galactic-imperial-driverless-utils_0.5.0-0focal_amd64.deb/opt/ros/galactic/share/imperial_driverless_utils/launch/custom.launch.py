import os
from pathlib import Path
from tempfile import mkdtemp
from typing import List, Tuple, Type

import yaml

import click
from launch.actions.execute_process import ExecuteProcess
from launch.launch_description_entity import LaunchDescriptionEntity
from launch_ros.actions import Node
from launch_ros.substitutions.find_package import FindPackageShare
from launch import LaunchDescription
from launch.actions import RegisterEventHandler, EmitEvent, DeclareLaunchArgument
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.events import Shutdown
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources.python_launch_description_source import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from ros2pkg.api import get_executable_paths, PackageNotFound

from ament_index_python.packages import PackageNotFoundError, get_package_share_path

import imperial_driverless_utils

from id_track_utils.track import Track # has to be apt-installed to be detected

from dataclasses import dataclass, field

@dataclass
class Package:
    name: str
    url: str

    custom_options: List[Tuple[str, List[LaunchDescriptionEntity]]] = field(default_factory=list)
    fallback_options: List[Tuple[str, List[LaunchDescriptionEntity]]] = field(default_factory=list)
    parameters: List[Tuple[str, Type]] = field(default_factory=list)

    @property
    def executable_names(self):
        return [os.path.basename(path) for path in get_executable_paths(package_name=self.name)]

collection_pkgs = [
    Package('lidar_only_cone_detector', 'https://github.com/Imperial-Driverless/lidar_only_cone_detector'),
    Package('slam_implementations',     'https://github.com/Imperial-Driverless/slam_implementations',
        fallback_options=[
            (click.style('publish a static identity transform from map to odom', fg='cyan'), [
                Node(
                    package='tf2_ros',
                    executable='static_transform_publisher',
                    name='map_odom_static_tf_publisher',
                    arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom']
                )
            ])
        ]
    ),
    Package('path_generators',          'https://github.com/Imperial-Driverless/path_generators',
        parameters=[
            ('use_smoothing', bool),
            ('smoothing', float),
            ('num_samples', int)
        ]
    ),
    Package('path_followers',           'https://github.com/Imperial-Driverless/path_followers',
        fallback_options=[
            (click.style('launch twist from car_keyop', fg='cyan'), [
                Node(
                    package='car_keyop',
                    executable='twist',
                    name='car_keyop',
                    arguments=['8.0', '1'] # max linear and angular velocities
                )
            ])
        ]
    ),
]


def generate_launch_description():
    tmp_dir = Path(mkdtemp())

    track_file = select_racetrack_map()

    vehicle_name = choose_vehicle()

    sim_ld = simulator_ld(track_file, vehicle_name)

    package_nodes = package_nodes_ld()

    ground_truth_cone_map_ld = ground_truth_cone_map_publisher(track_file)

    return LaunchDescription([
        *ground_truth_cone_map_ld,
        *sim_ld,
        *rviz_ld(tmp_dir),
        *package_nodes,
    ])
    

    

def select_racetrack_map() -> Path:
    cone_map_folder = get_package_share_path('imperial_driverless_utils') / 'cone_maps'

    cone_map_paths = [x for x in cone_map_folder.iterdir()]

    click.echo(f'Select a cone map:')
    for i, cone_map in enumerate(cone_map_paths):
        click.echo( f"{i}. {click.style(cone_map.name, fg='green')}")


    selection = click.prompt(
        "Please select:",
        type=click.Choice([str(i) for i in range(len(cone_map_paths))]),
        default="0",
        show_choices=False,
    )

    assert isinstance(selection, str)

    return cone_map_paths[int(selection)]

def ground_truth_cone_map_publisher(track_file: Path) -> List[LaunchDescriptionEntity]:
    t = Track.load_from_file(track_file)
    
    
    message_content = yaml.safe_dump(t.as_conemap_dict())

    gt_cone_map_publihser = ExecuteProcess(
        cmd=[
            'ros2', 'topic', 'pub',                       
            '/ground_truth/cone_map',                     # topic
            'imperial_driverless_interfaces/msg/ConeMap', # type
            message_content                         # message content
        ]
    )                       

    # using the version of topic_tools from https://github.com/mateusz-lichota/topic_tools
    gt_cone_map_transform_to_rviz_markers = Node(
        package='topic_tools',
        executable='transform',
        namespace='/ground_truth',
        name='transform',
        output='screen',
        emulate_tty=True,
        parameters=[
            {'input': '/ground_truth/cone_map'},
            {'output-topic': '/ground_truth/cone_map_rviz'},
            {'output-type': 'visualization_msgs/MarkerArray'},
            {'expression': 'imperial_driverless_utils.idi_msgs_to_rviz_markers.conemap_to_markerarray(m)'},
            {'import': ['imperial_driverless_utils']},
            {'wait-for-start': True},
        ]
    )

    return [
        gt_cone_map_publihser,
        gt_cone_map_transform_to_rviz_markers,
    ]

def rviz_ld(tmp_dir: Path) -> List[LaunchDescriptionEntity]:
    rviz_config_file = tmp_dir / 'rviz_config.rviz'
    
    rviz_config_file.write_text(imperial_driverless_utils.get_rviz_config())


    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', str(rviz_config_file)])

    shutdown_on_rviz_exit = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=rviz_node,
            on_exit=[
                EmitEvent(event=Shutdown()),
            ],
        ))
    
    return [rviz_node, shutdown_on_rviz_exit]

def simulator_ld(track_file_path: Path, vehicle_name: str) -> List[LaunchDescriptionEntity]:
    supported_simulators = ['lightweight_lidar_only_simulator', 'full_gazebo_simulator']
    
    launch_options: List[Tuple[str, Path]] = []
    
    
    for sim_name in supported_simulators:
        try:
            pkg_path = get_package_share_path(sim_name)
            for launch_file in (pkg_path / 'launch').glob('*.launch*'):
                launch_options.append((click.style(f'{sim_name}/{launch_file.name}', fg='green'), launch_file))

        except PackageNotFoundError:
            pass

    if not launch_options:
        click.echo(click.style(f'No supported simulator found. Supported simulators: {supported_simulators}', fg='red'))
        return []

    click.echo(click.style(f'Select a simulator launch file:', fg='white'))
    
    for i, (text, _) in enumerate(launch_options):
        click.echo( f"{i}. {text}")

    selection = click.prompt(
        "Please select:",
        type=click.Choice([str(i) for i, _ in enumerate(launch_options)]),
        default="0",
        show_choices=False,
    )

    assert isinstance(selection, str)

    simulator = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            str(launch_options[int(selection)][1])
            
        ),
        launch_arguments=[
            ('track_file', str(track_file_path)),
            ('vehicle_name', vehicle_name)
        ]
    )

    return [simulator]

def package_nodes_ld() -> List[LaunchDescriptionEntity]:
    pkg_found_common_options = [
        (click.style('do not launch any executable from this package', fg='yellow'), [])
    ]

    pkg_not_found_common_options = [
        (click.style('Ignore, I will start it myself', fg='yellow'), []),
        # (click.style('Clone from GitHub, build and source', fg='yellow'), []),
    ]

    ld = []

    for pkg in collection_pkgs:
        
        all_options = []

        try:
            executables = pkg.executable_names

            parameters = []
            if pkg.parameters:
                click.echo(click.style(f'Set parameters for {pkg.name}', fg='white'))

                for p_name, p_type in pkg.parameters:
                    val = click.prompt(f'(optional) value for parameter {p_name}', default=p_type(), type=p_type)
                    if val:
                        parameters.append({p_name: val})

            executable_options = [(
                click.style(executable, fg='green'), [
                Node(
                    package=pkg.name,
                    executable=executable,
                    name=executable,
                    emulate_tty=True,
                    output='screen',
                    parameters=parameters,
                )
            ]) for executable in executables]
            
            all_options = [
                *pkg_found_common_options,
                *executable_options,
                *pkg.custom_options,
                *pkg.fallback_options,
            ]

            click.echo(click.style(f'Select an executable from {pkg.name}', fg='white'))


        except PackageNotFound:
            click.echo(click.style(f'Package {pkg.name} not found. What to do?', fg='red'))
            
            all_options = [
                *pkg_not_found_common_options,
                *pkg.fallback_options
            ]

            
        for i, (text, _) in enumerate(all_options):
            click.echo( f"{i}. {text}")
        
        selection = click.prompt(
            "Please select:",
            type=click.Choice([str(i) for i, _ in enumerate(all_options)]),
            default="0",
            show_choices=False,
        )

        assert isinstance(selection, str)

        _, entities = all_options[int(selection)]
        ld.extend(entities)

    return ld

def choose_vehicle() -> str:
    
    vehicle_descriptions_share = get_package_share_path('vehicle_descriptions')
    
    vehicle_names = [p.name for p in vehicle_descriptions_share.glob('vehicles/*')]

    click.echo(click.style('Select a vehicle', fg='white'))

    for i, vehicle_name in enumerate(vehicle_names):
        click.echo( f"{i}. {click.style(vehicle_name, fg='green')}")

    selection = click.prompt(
        "Please select:",
        type=click.Choice([str(i) for i, _ in enumerate(vehicle_names)]),
        default="0",
        show_choices=False,
    )

    assert isinstance(selection, str)
    return vehicle_names[int(selection)]
