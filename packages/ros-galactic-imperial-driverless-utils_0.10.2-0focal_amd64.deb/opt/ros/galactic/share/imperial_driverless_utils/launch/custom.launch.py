import os
from pathlib import Path
from tempfile import mkdtemp
from typing import Dict, Iterable, List, Literal, Optional, Tuple, Type, Union
import enum

import yaml
import time

import click
import imperial_driverless_utils
from launch.actions.execute_process import ExecuteProcess
from launch.launch_description_entity import LaunchDescriptionEntity
from launch_ros.actions import Node
from launch import LaunchDescription
from launch.actions import RegisterEventHandler, EmitEvent
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.events import Shutdown
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources.python_launch_description_source import PythonLaunchDescriptionSource
from ros2pkg.api import get_executable_paths, PackageNotFound

from ament_index_python.packages import PackageNotFoundError, get_package_share_path

from imperial_driverless_utils import get_rviz_config, marker_array_display, map_display, path_display

from id_track_utils.track import Track # has to be apt-installed to be detected

from dataclasses import dataclass, field

import rosidl_runtime_py.convert

RvizDisplay = Dict

SimulatorName = Union[
    Literal['lightweight_lidar_only_simulator'],
    Literal['full_gazebo_simulator'],
    Literal['fsds_simulator'],
]

# click colours for terminal output
red    = lambda x: click.style(x, fg='red')
blue   = lambda x: click.style(x, fg='blue')
green  = lambda x: click.style(x, fg='green')
cyan   = lambda x: click.style(x, fg='cyan')
yellow = lambda x: click.style(x, fg='yellow')

# possible sources of a package
class PackageSource(enum.Enum): 
    NOT_FOUND = 'package was not found',
    SYSTEM    = 'package was installed globaly (probably via apt)'
    LOCAL     = 'package was installed locally'


@dataclass
class Package:
    name: str
    url: str

    rviz_displays: List[RvizDisplay]
    custom_options: List[Tuple[str, List[LaunchDescriptionEntity]]] = field(default_factory=list)
    fallback_options: List[Tuple[str, List[LaunchDescriptionEntity]]] = field(default_factory=list)
    
    
    # This is a horribly coupled way of specifying the package parameters.
    # Each time the parameter names or types change in any package,
    # they have to be updated here. The proper solution would be to have all
    # the packages expose launch files, as there exists an API to get 
    # all available arguments for a launch file, so we wouldn't have to specify
    # them here. 
    parameters: List[Tuple[str, Type]] = field(default_factory=list) 

    @property
    def executable_names(self):
        return [os.path.basename(path) for path in get_executable_paths(package_name=self.name)]

    @property
    def launch_files(self) -> Iterable[Path]:
        pkg_path = get_package_share_path(self.name)
        return (pkg_path / 'launch').glob('*.launch*')

    @property
    def source(self) -> PackageSource:
        try:
            if get_package_share_path(self.name).parts[1] == 'opt':
                return PackageSource.SYSTEM
            else:
                return PackageSource.LOCAL
        except PackageNotFoundError:
            return PackageSource.NOT_FOUND



@dataclass(frozen=True)
class Simulator:
    name: SimulatorName
    rviz_displays: List[RvizDisplay] = field(default_factory=list, init=True, compare=False, hash=False)

    @property
    def launch_files(self) -> List[Path]:
        pkg_path = get_package_share_path(self.name)
        return list((pkg_path / 'launch').glob('*.launch*'))

collection_pkgs = [
    Package('lidar_only_cone_detector', 
        url='https://github.com/Imperial-Driverless/lidar_only_cone_detector',
        rviz_displays=[
            marker_array_display('/perceived_cones_rviz_markers', 'Perceived Cones'),
        ]
    ),
    Package('lidar_camera_fusion',
        url='https://github.com/Imperial-Driverless/lidar_camera_fusion',
        rviz_displays=[],
    ),
    Package('slam_implementations',
        url='https://github.com/Imperial-Driverless/slam_implementations',
        rviz_displays=[
            marker_array_display('/cone_map_rviz_markers', 'Cone Map'),
        ],
        fallback_options=[
            (cyan('publish a static identity transform from map to odom'), [
                Node(
                    package='tf2_ros',
                    executable='static_transform_publisher',
                    name='map_odom_static_tf_publisher',
                    arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom']
                )
            ])
        ]
    ),
    Package('path_generators',
        url='https://github.com/Imperial-Driverless/path_generators',
        rviz_displays=[
            path_display,
            marker_array_display('/path_generator_visualization', 'Path Generator Visualization'),
        ],
        parameters=[
            ('use_smoothing', bool),
            ('smoothing', float),
            ('sample_density', float)
        ]
    ),
    Package('path_followers',
        url='https://github.com/Imperial-Driverless/path_followers',
        rviz_displays=[],
        fallback_options=[
            (click.style('launch twist from car_keyop', fg='cyan'), [
                Node(
                    package='car_keyop',
                    executable='twist',
                    name='car_keyop',
                    arguments=['8.0', '1'], # max linear and angular velocities
                    parameters=[{'use_sim_time': True}],
                )
            ])
        ]
    ),
]

supported_simulators: List[Simulator] = [
    Simulator('lightweight_lidar_only_simulator', []), 
    Simulator('full_gazebo_simulator', []),
    Simulator('fsds_simulator', []),
]

def generate_launch_description():
    tmp_dir = Path(mkdtemp())

    rviz_displays: Dict[str, List[RvizDisplay]] = {}

    click.clear()
    try:

        vehicle_ld, vehicle_config_file = choose_vehicle()

        sim, sim_launch_file = select_simulator_and_launchfile()

        if sim.name == 'fsds_simulator':
            track_file = None
            ground_truth_cone_map_ld = []
        else:
            track_file = select_racetrack_map(tmp_dir)
            ground_truth_cone_map_ld, rviz_displays['from gt cone map'] \
            = ground_truth_cone_map_publisher(track_file)

        sim_ld, rviz_displays['from simulator'] = generate_simulator_ld(
            sim, 
            sim_launch_file, 
            vehicle_config_file,
            track_file, 
        )

        package_nodes, rviz_displays['from nodes'] = package_nodes_ld()

        # dict to list flattening
        all_rviz_displays = [d for disps in rviz_displays.values() for d in disps]
        
        clock_sync_signal_emitter = Node(
            package='imperial_driverless_utils',
            executable='clock_sync_signal_emitter',
            name='clock_sync_signal_emitter',
            parameters=[{'use_sim_time': True}],
        )

        return LaunchDescription([
            clock_sync_signal_emitter,
            *ground_truth_cone_map_ld,
            *sim_ld,
            *vehicle_ld,
            *rviz_ld(tmp_dir, all_rviz_displays),
            *package_nodes,
        ])

    except click.Abort:
        click.echo()
        click.secho('Launch aborted by the user', fg='yellow')
        exit()
      
def select_racetrack_map(tmp_dir: Path) -> Path:
    cone_map_folder = get_package_share_path('imperial_driverless_utils') / 'cone_maps'

    cone_map_paths = [x for x in cone_map_folder.iterdir()]

    click.echo(f'Select a cone map:')
    for i, cone_map in enumerate(cone_map_paths):
        click.echo( f'{i}. {green(cone_map.name)}')
    click.echo(f"R. {cyan('random track')}")

    selection = click.prompt(
        'Please select:',
        type=click.Choice([str(i) for i in range(len(cone_map_paths))] + ['R', 'r']),
        default='0',
        show_choices=False,
    )

    assert isinstance(selection, str)
    if selection in ['r', 'R']:
        default_seed = int(time.time()) % 1000
        seed = click.prompt('(optional) random seed:', default=default_seed)
        t = Track.generate_random(seed)
        selected_track_path = tmp_dir / 'track.csv'
        selected_track_path.write_text(t.as_csv())
        click.echo(f'Using a random track with seed {seed}.\n')
    else:
        selected_track_path = cone_map_paths[int(selection)]
        click.echo(f'Using track {green(selected_track_path.name)}.\n')

    return selected_track_path

def ground_truth_cone_map_publisher(
    track_file: Path
) -> Tuple[List[LaunchDescriptionEntity], List[RvizDisplay]]:

    t = Track.load_from_file(track_file)
    message_content = yaml.safe_dump(t.as_conemap_dict())

    gt_cone_map_publihser = ExecuteProcess(
        cmd=[
            'ros2', 'topic', 'pub',                       
            '/ground_truth/cone_map',                     # topic
            'imperial_driverless_interfaces/msg/ConeMap', # type
            message_content                         # message content
        ]
    )

    cone_map_message = t.as_conemap_message()
    visualization_message = imperial_driverless_utils.idi_msgs_to_rviz_markers.conemap_to_markerarray(cone_map_message)
    visualization_yaml = rosidl_runtime_py.convert.message_to_yaml(visualization_message)

    gt_cone_map_visualization_publisher = ExecuteProcess(
        cmd=[
            'ros2', 'topic', 'pub',
            '/ground_truth/cone_map_rviz',
            'visualization_msgs/MarkerArray',
            visualization_yaml
        ]
    )

    return [
        gt_cone_map_publihser,
        gt_cone_map_visualization_publisher,
    ], [marker_array_display('/ground_truth/cone_map_rviz', 'Ground Truth Cones')]

def rviz_ld(tmp_dir: Path, displays: List[RvizDisplay]) -> List[LaunchDescriptionEntity]:
    rviz_config_file = tmp_dir / 'rviz_config.rviz'
    
    rviz_config_file.write_text(get_rviz_config(displays))


    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        parameters=[{'use_sim_time': True}],
        arguments=[
            '-d', str(rviz_config_file),
            '--ros-args', '--log-level', 'error',
        ])

    shutdown_on_rviz_exit = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=rviz_node,
            on_exit=[
                EmitEvent(event=Shutdown()),
            ],
        ))
    
    return [rviz_node, shutdown_on_rviz_exit]

def select_simulator_and_launchfile() -> Tuple[Simulator, Path]:
    launch_files: Dict[Simulator, List[Path]] = {sim: [] for sim in supported_simulators}

    for sim, sim_launch_files in launch_files.items():
        try:
            sim_launch_files.extend(sim.launch_files)
        except PackageNotFoundError:
            click.echo(yellow(f'{sim.name} not found'))
            

    if not any(launch_files):
        click.echo(red(f'No supported simulator launchfiles found. Supported simulators: {supported_simulators}'))
        raise click.Abort()

    click.echo(f'Select a simulator launch file:')
    
    all_launch_files = [
        (sim_name, launch_file.stem, launch_file)
        for sim_name, sim_launch_files in launch_files.items()
        for launch_file in sim_launch_files
    ]

    for i, (sim, launch_file_stem, _) in enumerate(all_launch_files):
        click.echo(f'{i}. {blue(sim.name)} {green(launch_file_stem)}')

    selection = click.prompt(
        'Please select:',
        type=click.Choice([str(i) for i, _ in enumerate(all_launch_files)]),
        default='0',
        show_choices=False,
    )

    assert isinstance(selection, str)
    selected_sim, _, selected_launch_file = all_launch_files[int(selection)]
    
    click.echo(f'Launching {green(selected_launch_file.stem)} '
               f'from {blue(selected_sim.name)}.\n')

    return selected_sim, selected_launch_file

def generate_simulator_ld(
    sim: Simulator,
    simulator_launch_file: Path,
    vehicle_config_file: Path,
    track_file: Optional[Path],
) -> Tuple[List[LaunchDescriptionEntity], List[RvizDisplay]]:

    include_simulator_ld = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            str(simulator_launch_file)
        ),
        launch_arguments=[
            ('track_file', str(track_file) if track_file else ''),
            ('vehicle_config_file', str(vehicle_config_file)),
        ]
    )

    return [include_simulator_ld], sim.rviz_displays

def package_nodes_ld() -> Tuple[List[LaunchDescriptionEntity], List[RvizDisplay]]:
    pkg_found_common_options = [
        (yellow('do not launch any executable from this package'), [])
    ]

    pkg_not_found_common_options = [
        (yellow('ignore, I will start it myself'), []),
        # (click.style('Clone from GitHub, build and source', fg='yellow'), []),
    ]

    ld = []
    rviz_displays = []

    for pkg in collection_pkgs:
        all_options = []
        launch_file_options = []
        executable_options = []

        try:
            executable_options = [(
                green(executable), [
                Node(
                    package=pkg.name,
                    executable=executable,
                    name=executable,
                    emulate_tty=True,
                    output='screen',
                    parameters=[{'use_sim_time': True}],
                )
            ]) for executable in pkg.executable_names]

            launch_file_options = [(
                cyan(launch_file.stem), [
                IncludeLaunchDescription(
                    PythonLaunchDescriptionSource(str(launch_file)),
                )
            ]) for launch_file in pkg.launch_files]
            
            all_options = [
                *pkg.fallback_options,
                *pkg_found_common_options,
                *executable_options,
                *launch_file_options,
                *pkg.custom_options,
            ]

            click.echo(f'Select an executable from {blue(pkg.name)} [{pkg.source.name}]')


        except PackageNotFound:
            click.echo(blue(pkg.name) + red(' not found. What to do?'))
            
            all_options = [
                *pkg.fallback_options,
                *pkg_not_found_common_options,
            ]

            
        for i, (text, _) in enumerate(all_options):
            click.echo( f'{i}. {text}')
        
        selection = click.prompt(
            'Please select:',
            type=click.Choice([str(i) for i, _ in enumerate(all_options)]),
            default='0',
            show_choices=False,
        )

        assert isinstance(selection, str)
        selected_option = all_options[int(selection)]
        _, entities = selected_option


        if entities and isinstance(entities[0], Node) and pkg.parameters:
            click.echo('Set parameters for ' + blue(pkg.name))
            parameters = [{p_name: val} for p_name, p_type in pkg.parameters for val in [click.prompt(f'(optional) value for parameter {p_name}', default=p_type(), type=p_type)] if val]
            entities[0] = Node(
                package=pkg.name,
                executable=entities[0].node_executable,
                name=entities[0].node_executable,
                emulate_tty=True,
                output='screen',
                parameters=[
                    *parameters,
                    {'use_sim_time': True},
                ]
            )

        if selected_option in executable_options or selected_option in launch_file_options:
            click.echo('Launching ' + selected_option[0] + \
            f' from {blue(pkg.name)}.\n')
        else:
            click.echo()
            
        ld.extend(entities)

        # if we're launching something we might need its visualization.
        if entities:
            rviz_displays.extend(pkg.rviz_displays)

    return ld, rviz_displays

def choose_vehicle() -> Tuple[List[LaunchDescriptionEntity], Path]:
    
    vehicle_descriptions_share = get_package_share_path('vehicle_descriptions')
    
    vehicle_names = [p.name for p in vehicle_descriptions_share.glob('vehicles/*')]

    click.echo('Select a vehicle')

    for i, vehicle_name in enumerate(vehicle_names):
        click.echo( f'{i}. {green(vehicle_name)}')

    selection = click.prompt(
        'Please select:',
        type=click.Choice([str(i) for i, _ in enumerate(vehicle_names)]),
        default='0',
        show_choices=False,
    )


    assert isinstance(selection, str)
    vehicle_name = vehicle_names[int(selection)]

    click.echo('Using vehicle ' + green(vehicle_name) + '.\n')

    return [
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                str(vehicle_descriptions_share / 'launch' / 'simple.launch.py')
            ),
            launch_arguments=[
                ('vehicle_name', vehicle_name)
            ]
        )
    ], vehicle_descriptions_share / 'vehicles' / vehicle_name / 'config.yaml'
