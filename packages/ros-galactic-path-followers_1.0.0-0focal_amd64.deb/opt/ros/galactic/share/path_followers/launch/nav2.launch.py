import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    # Get the launch directory
    dir = get_package_share_directory('path_followers')
    params = os.path.join(dir, 'launch', 'params.yaml')

    return LaunchDescription([
        Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            name='lifecycle_manager_navigation',
            output='screen',
            parameters=[
                {'autostart': True},
                {'node_names': ['controller_server', 'planner_server', 'bt_navigator']}
            ]
        ),

        Node(
            package='nav2_planner',
            executable='planner_server',
            name='planner_server',
            output='screen',
            parameters=[params]),

        Node(
            package='nav2_controller',
            executable='controller_server',
            output='screen',
            parameters=[params]),

        Node(
            package='nav2_bt_navigator',
            executable='bt_navigator',
            name='bt_navigator',
            output='screen',
            parameters=[params])
    ])

