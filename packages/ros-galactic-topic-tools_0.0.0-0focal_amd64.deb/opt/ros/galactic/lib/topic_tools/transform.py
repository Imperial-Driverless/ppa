import sys
import argparse
from .transform_node import Transform, NO_DEFAULT
from rclpy.utilities import remove_ros_args
from rclpy.parameter import Parameter, ParameterType
import rclpy


def main(argv=sys.argv[1:]):
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter,
        description='Apply a Python operation to a topic.\n\n'
                    'A node is created that subscribes to a topic,\n'
                    'applies a Python expression to the topic (or topic\n'
                    'field) message \"m\", and publishes the result\n'
                    'through another topic.\n\n'
                    'Usage:\n\tros2 run topic_tools transform '
                    '<input topic> <output topic> <output type> '
                    '[<expression on m>] [--import numpy tf] [--field <topic_field>]\n\n'
                    'Example:\n\tros2 run topic_tools transform /imu --field orientation '
                    '/norm std_msgs/Float64'
                    '\"std_msgs.msg.Float64(data=sqrt(sum(array([m.x, m.y, m.z, m.w]))))\"'
                    ' --import std_msgs')

    for parameter_name, type, descr, default, _ in Transform.required_parameters + Transform.optional_parameters:
        kwargs = {}
        if default is not NO_DEFAULT:
            kwargs['default'] = default
            kwargs['nargs'] = '+' if type == ParameterType.PARAMETER_STRING_ARRAY else '?'
            parameter_name = f'--{parameter_name}'
        
        parser.add_argument(parameter_name, help=descr, **kwargs)

    argv = remove_ros_args(argv)
    print(argv)
    po = []
    if argv:
        args = parser.parse_args(argv)

        po = [Parameter(name, type_=None, value=value) 
            for name, value in vars(args).items()
            if value is not NO_DEFAULT]
    else:
        print('WARNING: no command line arguments provided. Assuming they will be provided via parameters')

    rclpy.init(args=argv)
    node = Transform('transform', parameter_overrides=po)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print('transform stopped cleanly')
    except BaseException:
        print('exception in transform:', file=sys.stderr)
        raise
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
