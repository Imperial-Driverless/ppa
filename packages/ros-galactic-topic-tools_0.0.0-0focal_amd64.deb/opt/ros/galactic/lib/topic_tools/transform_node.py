#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright 2021 Daisuke Nishimatsu
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Usage summary.

@author: enriquefernandez, Daisuke Nishimatsu
Allows to take a topic or one of it fields and output it on another topic
after performing a valid python operation.
The operations are done on the message, which is taken in the variable 'm'.
* Examples (note that numpy is imported by default):
$ ros2 run topic_tools transform /imu --field orientation.x /x_str std_msgs/String 'std_msgs.msg.String(data=str(m))' --import std_msgs # noqa: E501
$ ros2 run topic_tools transform /imu --field orientation.x /x_in_degrees std_msgs/Float64 'std_msgs.msg.Float64(data=-numpy.rad2deg(m))' --import std_msgs numpy # noqa: E501
$ ros2 run topic_tools transform /imu --field orientation /norm std_msgs/Float64 'std_msgs.msg.Float64(data=numpy.sqrt(numpy.sum(numpy.array([m.x, m.y, m.z, m.w]))))' --import std_msgs numpy # noqa: E501
$ ros2 run topic_tools transform /imu --field orientation /norm std_msgs/Float64 'std_msgs.msg.Float64(data=numpy.linalg.norm([m.x, m.y, m.z, m.w]))' --import std_msgs numpy # noqa: E501
"""

import importlib
import sys
from typing import List, Optional

import rclpy
import rclpy.qos
import rclpy.exceptions
from rcl_interfaces.msg import ParameterDescriptor, SetParametersResult
from rclpy.parameter import Parameter, ParameterType
from rclpy.node import Node
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy
from rclpy.qos import QoSProfile
from rclpy.qos import QoSPresetProfiles
from rclpy.qos import QoSReliabilityPolicy
from ros2topic.api import get_msg_class
from ros2topic.api import qos_profile_from_short_keys
from rosidl_runtime_py.utilities import get_message

from collections import namedtuple

from dataclasses import dataclass

NTDDC = namedtuple(
    'NT', ['name', 'type', 'description', 'default', 'callback'])

NO_DEFAULT = object()

@dataclass
class QoSSettings:
    preset: Optional[str] = None
    depth: Optional[int] = None 
    history: Optional[str] = None
    reliability: Optional[str] = None
    durability: Optional[str] = None

class Transform(Node):

    def __init__(self, name: str, **kwargs):
        super().__init__(name, **kwargs)

        self.add_on_set_parameters_callback(self.on_set_parameters)
        self._parameter_set_callbacks = {}
        self.modules = {}

        self.wait_for_start = False

        self.use_custom_qos = False
        self.qos_settings = QoSSettings()


        for name, type, descr, default, callback in Transform.required_parameters + Transform.optional_parameters:
            self._parameter_set_callbacks[name] = callback
            if default is NO_DEFAULT:
                default = None
            self.declare_parameter(name, default, ParameterDescriptor(name=name, type=type, description=descr))

    def recreate_publisher(self):
        try:
            self.pub = self.create_publisher(
                self._output_class, 
                self._output_topic,
                self.choose_qos(self._output_topic)
            )
        except AttributeError:
            pass # we don't yet know the output class or output topic


    # SETTERS

    def set_input(self, input_topic_in_ns: Optional[str]):
        if input_topic_in_ns is None:
            return

        if not input_topic_in_ns.startswith('/'):
            input_topic_in_ns = self.get_namespace() + input_topic_in_ns

        input_class = get_msg_class(
            self, 
            input_topic_in_ns, 
            blocking=self.wait_for_start, 
            include_hidden_topics=True
        )
        
        if input_class is None:
            raise RuntimeError(f'ERROR: Wrong input topic: {input_topic_in_ns}')

        self.sub = self.create_subscription(
            input_class, 
            input_topic_in_ns, 
            self.transform_and_republish, 
            self.choose_qos(input_topic_in_ns)
        )

    def set_output_topic(self, val: str):
        if val is None:
            return

        self._output_topic = val
        
        self.recreate_publisher()

    def set_output_type(self, output_type: str):
        if output_type is None:
            return

        try:
            self._output_class = get_message(output_type)
        except ValueError:
            raise RuntimeError('Invalid output topic type')
        
        self.recreate_publisher()

    def set_qos_preset(self, val: str):
        self.use_custom_qos = True
        self.qos_preset = val

    def set_qos_depth(self, val: int):
        self.use_custom_qos = True
        self.qos_depth = val

    def set_qos_history(self, short_key: str):
        self.use_custom_qos = True
        self.qos_settings.history = short_key
    
    def set_qos_reliability(self, short_key: str):
        self.use_custom_qos = True
        self.qos_settings.reliability = short_key

    def set_qos_durability(self, short_key: str):
        self.use_custom_qos = True
        self.qos_settings.durability = short_key

    def set_field(self, field_raw: str):
        if field_raw:
            self.field = list(filter(None, field_raw.split('.')))
            if not self.field:
                raise RuntimeError(f"Invalid field value '{field_raw}'")
        else:
            self.field = None
    
    def set_expression(self, val: str):
        self.expression = val

    def set_wait_for_start(self, wait_for_start: bool):
        self.wait_for_start = wait_for_start

    def import_modules(self, modules: List[str]):
        for module in modules:
            if module in self.modules: # skip already imported modules
                continue

            try:
                mod = importlib.import_module(module)
            except ImportError:
                print(f'Failed to import module: {module}', file=sys.stderr)
            else:
                self.modules[module] = mod
    

    

    def on_set_parameters(self, parameters: List[Parameter]) -> SetParametersResult:
        for p in parameters:
            try:
                self._parameter_set_callbacks[p.name](self, p.value)
            except KeyError:
                print(f'no callback associated with parameter {p.name}')
                pass

        return SetParametersResult(successful=True, reason='')

    def choose_qos(self, topic_name):
        if self.use_custom_qos:
            return qos_profile_from_short_keys(
                preset_profile=self.qos_settings.preset if self.qos_settings.preset else 'sensor_data',
                depth=self.qos_settings.depth if self.qos_settings.depth is not None else -1,
                history=self.qos_settings.history,
                reliability=self.qos_settings.reliability,
                durability=self.qos_settings.durability
            )

        qos_profile = QoSPresetProfiles.get_from_short_key('sensor_data')
        reliability_reliable_endpoints_count = 0
        durability_transient_local_endpoints_count = 0

        pubs_info = self.get_publishers_info_by_topic(topic_name)
        publishers_count = len(pubs_info)
        if publishers_count == 0:
            return qos_profile

        for info in pubs_info:
            if (info.qos_profile.reliability == QoSReliabilityPolicy.RELIABLE):
                reliability_reliable_endpoints_count += 1
            if (info.qos_profile.durability == QoSDurabilityPolicy.TRANSIENT_LOCAL):
                durability_transient_local_endpoints_count += 1

        # If all endpoints are reliable, ask for reliable
        if reliability_reliable_endpoints_count == publishers_count:
            qos_profile.reliability = QoSReliabilityPolicy.RELIABLE
        else:
            if reliability_reliable_endpoints_count > 0:
                print(
                    'Some, but not all, publishers are offering '
                    'QoSReliabilityPolicy.RELIABLE. Falling back to '
                    'QoSReliabilityPolicy.BEST_EFFORT as it will connect '
                    'to all publishers'
                )
            qos_profile.reliability = QoSReliabilityPolicy.BEST_EFFORT

        # If all endpoints are transient_local, ask for transient_local
        if durability_transient_local_endpoints_count == publishers_count:
            qos_profile.durability = QoSDurabilityPolicy.TRANSIENT_LOCAL
        else:
            if durability_transient_local_endpoints_count > 0:
                print(
                    'Some, but not all, publishers are offering '
                    'QoSDurabilityPolicy.TRANSIENT_LOCAL. Falling back to '
                    'QoSDurabilityPolicy.VOLATILE as it will connect '
                    'to all publishers'
                )
            qos_profile.durability = QoSDurabilityPolicy.VOLATILE

        return qos_profile

    def transform_and_republish(self, m):
        if self.field is not None:
            for field in self.field:
                try:
                    m = getattr(m, field)
                except AttributeError as ex:
                    raise RuntimeError(
                        f"Invalid field '{'.'.join(self.field)}': {ex}")
        try:
            res = eval(f'{self.expression}', self.modules, {'m': m})
        except NameError as e:
            print(
                f"Expression using variables other than 'm': {str(e)}", file=sys.stderr)
        except UnboundLocalError as e:
            print(f'Wrong expression: {str(e)}', file=sys.stderr)
        except Exception:
            raise
        else:
            if not isinstance(res, (list, tuple)):
                res = [res]
            self.pub.publish(*res)

    _default_profile: QoSProfile = rclpy.qos.QoSPresetProfiles.get_from_short_key('sensor_data')

    required_parameters = [
        NTDDC('input', ParameterType.PARAMETER_STRING,
            description='Input topic or topic field.',
            default=NO_DEFAULT,
            callback=set_input,
        ),
        NTDDC('output-topic', ParameterType.PARAMETER_STRING,
            description='Output topic.',
            default=NO_DEFAULT,
            callback=set_output_topic
        ),
        NTDDC('output-type', ParameterType.PARAMETER_STRING,
            description='Output topic type.',
            default=NO_DEFAULT,
            callback = set_output_type
        ),
        NTDDC('expression', ParameterType.PARAMETER_STRING,
            description='Python expression to apply on the input message \"m\".',
            default=NO_DEFAULT,
            callback = set_expression
        ),
    ]

    optional_parameters = [
        NTDDC('import', ParameterType.PARAMETER_STRING_ARRAY,
            description='List of Python modules to import.',
            default=['numpy'],
            callback=import_modules
        ),
        NTDDC('wait-for-start', ParameterType.PARAMETER_BOOL,
            description='Wait for input messages.',
            default=False,
            callback=set_wait_for_start
            # action='store_true',
        ),
        NTDDC('qos-profile', ParameterType.PARAMETER_STRING,
            description='Quality of service preset profile to subscribe with (default: sensor_data)',
            default='sensor_data',
            callback=set_qos_preset
            # choices=rclpy.qos.QoSPresetProfiles.short_keys(),
        ),
        NTDDC('qos-depth', ParameterType.PARAMETER_INTEGER,
            description='Queue size setting to subscribe with '
            '(overrides depth value of --qos-profile option)',
            default=_default_profile.depth,
            callback=set_qos_depth
        ),
        NTDDC('qos-history', ParameterType.PARAMETER_STRING,
            description=f'History of samples setting to subscribe with '
             '(overrides history value of --qos-profile option, default: {_default_profile.history.short_key})',
            default=_default_profile.history.short_key,
            callback=set_qos_history
        ),
        NTDDC('qos-reliability', ParameterType.PARAMETER_STRING,
            description='Quality of service reliability setting to subscribe with '
             '(overrides reliability value of --qos-profile option, default: '
             'Automatically match existing publishers )',
            default=_default_profile.reliability.short_key,
            callback=set_qos_reliability
        ),
        NTDDC('qos-durability', ParameterType.PARAMETER_STRING,
            description='Quality of service durability setting to subscribe with '
             '(overrides durability value of --qos-profile option, default: '
             'Automatically match existing publishers )',
            default=_default_profile.durability.short_key,
            callback=set_qos_durability
        ),
        NTDDC('field', ParameterType.PARAMETER_STRING,
            description='Transform a selected field of a message. '
             "Use '.' to select sub-fields. "
             'For example, to transform the orientation x field of a sensor_msgs/msg/Imu message: '
             "'ros2 run topic_tools transform /imu --field orientatin.x'",
            default='',
            callback=set_field
        ),
    ]


def main(argv=sys.argv[1:]):
    rclpy.init(args=argv)
    node = Transform(f'transform')
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print('transform stopped cleanly')
    except BaseException:
        print('exception in transform:', file=sys.stderr)
        raise
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
