from pathlib import Path

import xacro

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch_ros.actions import Node
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration

from ament_index_python.packages import get_package_share_directory

import xml.dom.minidom

def create_vehicle(context, *args, **kwargs):
    pkg_share = Path(get_package_share_directory('vehicle_descriptions'))

    xacro_path = pkg_share / 'urdf' / 'main.urdf.xacro'

    urdf_include = LaunchConfiguration('urdf_include').perform(context)

    doc: xml.dom.minidom.Document = xacro.parse(inp=None, filename=str(xacro_path)) # type: ignore

    if urdf_include and doc.firstChild is not None:
        e = xml.dom.minidom.Element('xacro:include')
        e.setAttributeNode(doc.createAttribute('filename'))
        e.setAttribute('filename', urdf_include)
        doc.firstChild.appendChild(e)
    
    
    xacro.process_doc(
        doc, 
        mappings={
            'vehicle_name': LaunchConfiguration('vehicle_name').perform(context),
        }
    )

    robot_description = doc.toprettyxml() # type: ignore

    return [
        Node(
            name='robot_state_publisher',
            package='robot_state_publisher',
            executable='robot_state_publisher',
            output='screen',
            parameters=[{
                'robot_description': robot_description,
                'rate': 200,
                'ignore_timestamp': True,
            }],
            arguments=['--ros-args', '--log-level', 'warn']
        ),

        Node(
            name='joint_state_publisher',
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            output='screen',
            parameters=[{
                'robot_description': robot_description,
                'rate': 200,
            }],
            condition=IfCondition(LaunchConfiguration('launch_jsp').perform(context)),
        ),
    ]

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('vehicle_name', default_value='ads_dv'),
        DeclareLaunchArgument('urdf_include', default_value=''),
        DeclareLaunchArgument('launch_jsp', default_value='false'),
        DeclareLaunchArgument('x', default_value='0.0',
                              description='Vehicle initial x position'),
        DeclareLaunchArgument('y', default_value='0.0',
                              description='Vehicle initial y position'),
        DeclareLaunchArgument('z', default_value='0.0',
                              description='Vehicle initial z position'),

        OpaqueFunction(function=create_vehicle)
    ])
