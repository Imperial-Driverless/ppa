import os
from pathlib import Path
from tempfile import mkdtemp
from typing import Dict, List, Tuple

import cv2
import yaml

import click
from launch.actions.execute_process import ExecuteProcess
from launch.launch_description_entity import LaunchDescriptionEntity
from launch_ros.actions import Node
from launch_ros.substitutions.find_package import FindPackageShare
from launch import LaunchDescription
from launch.actions import RegisterEventHandler, EmitEvent, DeclareLaunchArgument
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.events import Shutdown
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources.python_launch_description_source import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from ros2pkg.api import get_executable_paths, PackageNotFound

from ament_index_python.packages import get_package_share_path

import imperial_driverless_utils

from dataclasses import dataclass, field

@dataclass
class Package:
    name: str
    url: str

    custom_options: List[Tuple[str, List[LaunchDescriptionEntity]]] = field(default_factory=list)
    fallback_options: List[Tuple[str, List[LaunchDescriptionEntity]]] = field(default_factory=list)

    @property
    def executable_names(self):
        return [os.path.basename(path) for path in get_executable_paths(package_name=self.name)]

collection_pkgs = [
    Package('lidar_only_cone_detector', 'https://github.com/Imperial-Driverless/lidar_only_cone_detector'),
    Package('slam_implementations',     'https://github.com/Imperial-Driverless/slam_implementations'),
    Package('path_generators',          'https://github.com/Imperial-Driverless/path_generators'),
    Package('path_followers',           'https://github.com/Imperial-Driverless/path_followers',
        fallback_options=[
            (click.style('launch twist from car_keyop', fg='cyan'), [
                Node(
                    package='car_keyop',
                    executable='twist',
                    name='car_keyop',
                )
            ])
        ]
    ),
]


def generate_launch_description():
    tmp_dir = Path(mkdtemp())

    cone_map = select_racetrack_map()

    vehicle_launch, vehicle_config_file = choose_vehicle()

    package_nodes = package_nodes_ld()

    return LaunchDescription([
        DeclareLaunchArgument('vehicle_config_file', default_value=vehicle_config_file),
        *ground_truth_cone_map(tmp_dir, cone_map),
        *simulator_ld(),
        *rviz_ld(tmp_dir),
        *package_nodes,
        *vehicle_launch,
    ])
    

    

def select_racetrack_map() -> Path:
    cone_map_folder = get_package_share_path('imperial_driverless_utils') / 'cone_maps'

    cone_map_paths = [x for x in cone_map_folder.iterdir()]

    click.echo(f'Select a cone map:')
    for i, cone_map in enumerate(cone_map_paths):
        click.echo( f"{i}. {click.style(cone_map.name, fg='green')}")

    selection = int(click.prompt(
        "Please select:",
        type=click.Choice([str(i) for i in range(len(cone_map_paths))]),
        default="0",
        show_choices=False,
    ))

    return cone_map_paths[selection]

def ground_truth_cone_map(tmp_dir: Path, cone_map: Path) -> List[LaunchDescriptionEntity]:
    ground_truth_cone_map = cone_map.read_text()
    cone_map_dict = yaml.safe_load(ground_truth_cone_map)
    map_image, (orig_x, orig_y) = imperial_driverless_utils.create_map(cone_map_dict)

    cv2.imwrite(str(tmp_dir / 'map.png'), map_image)
    map_yaml_file = tmp_dir / 'map.yaml'
    map_yaml_file.write_text(f"""
        image: map.png
        resolution: 0.02
        origin:  [{orig_x}, {orig_y}, 0.]
        negate: 0
        occupied_thresh: 0.8
        free_thresh: 0.2
        """
    )

    map_launch_arg = DeclareLaunchArgument(
        name='map',
        default_value=str(map_yaml_file)
    )

    gt_cone_map_publihser = ExecuteProcess(
        cmd=[
            'ros2', 'topic', 'pub',                       
            '/ground_truth/cone_map',                     # topic
            'imperial_driverless_interfaces/msg/ConeMap', # type
            ground_truth_cone_map                         # message content
        ]
    )                       

    # using the version of topic_tools from https://github.com/mateusz-lichota/topic_tools
    gt_cone_map_transform_to_rviz_markers = Node(
        package='topic_tools',
        executable='transform',
        namespace='/ground_truth',
        name='transform',
        output='screen',
        emulate_tty=True,
        parameters=[
            {'input': '/ground_truth/cone_map'},
            {'output-topic': '/ground_truth/cone_map_rviz'},
            {'output-type': 'visualization_msgs/MarkerArray'},
            {'expression': 'idi_msgs_to_rviz_markers.conemap_to_markerarray(m)'},
            {'import': ['idi_msgs_to_rviz_markers']},
            {'wait-for-start': True},
        ]
    )

    return [
        map_launch_arg,
        gt_cone_map_publihser,
        gt_cone_map_transform_to_rviz_markers,
    ]

def rviz_ld(tmp_dir: Path) -> List[LaunchDescriptionEntity]:
    rviz_config_file = tmp_dir / 'rviz_config.rviz'
    
    rviz_config_file.write_text(imperial_driverless_utils.rviz_config)


    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', str(rviz_config_file)])

    shutdown_on_rviz_exit = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=rviz_node,
            on_exit=[
                EmitEvent(event=Shutdown()),
            ],
        ))
    
    return [rviz_node, shutdown_on_rviz_exit]

def simulator_ld() -> List[LaunchDescriptionEntity]:
    simulator = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('lightweight_lidar_only_simulator'),
                'launch/simulate.launch.py'
            ])
        )
    )


    return [simulator]

def package_nodes_ld() -> List[LaunchDescriptionEntity]:
    pkg_found_common_options = [
        (click.style('do not launch any executable from this package', fg='yellow'), [])
    ]

    pkg_not_found_common_options = [
        (click.style('Ignore, I will start it myself', fg='yellow'), []),
        # (click.style('Clone from GitHub, build and source', fg='yellow'), []),
    ]

    ld = []

    for pkg in collection_pkgs:
        
        all_options = []

        try:
            executable_options = [(
                click.style(executable, fg='green'), [
                Node(
                    package=pkg.name,
                    executable=executable,
                    name=executable,
                    emulate_tty=True,
                    output='screen',
                )
            ]) for executable in pkg.executable_names]
            
            all_options = [
                *pkg_found_common_options,
                *executable_options,
                *pkg.custom_options,
                *pkg.fallback_options,
            ]

            click.echo(click.style(f'Select an executable from {pkg.name}', fg='white'))


        except PackageNotFound:
            click.echo(click.style(f'Package {pkg.name} not found. What to do?', fg='red'))
            
            all_options = [
                *pkg_not_found_common_options,
                *pkg.fallback_options
            ]

            
        for i, (text, _) in enumerate(all_options):
            click.echo( f"{i}. {text}")
        
        selection = int(click.prompt(
            "Please select:",
            type=click.Choice([str(i) for i, _ in enumerate(all_options)]),
            default="0",
            show_choices=False,
        ))

        _, entities = all_options[selection]
        ld.extend(entities)

    return ld

def choose_vehicle() -> Tuple[List[LaunchDescriptionEntity], str]:
    
    racecar_description_share = get_package_share_path('racecar_description')
    
    vehicle_names = [p.name for p in racecar_description_share.glob('vehicles/*')]

    click.echo(click.style('Select a vehicle', fg='white'))

    for i, vehicle_name in enumerate(vehicle_names):
        click.echo( f"{i}. {click.style(vehicle_name, fg='green')}")

    selection = int(click.prompt(
        "Please select:",
        type=click.Choice([str(i) for i, _ in enumerate(vehicle_names)]),
        default="0",
        show_choices=False,
    ))

    vehicle_config = str(racecar_description_share / 'vehicles' / vehicle_names[selection] / 'config.yaml')

    return [
        DeclareLaunchArgument('vehicle_name', default_value=vehicle_names[selection]),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                PathJoinSubstitution([
                    str(racecar_description_share),
                    'launch',
                    'simple.launch.py'
                ])
            )
        )
    ], vehicle_config
