# Launches software targeted at the real car.
# This consists of both the ROS_CAN node as well as the Orchestrator node.

# The Orchestrator node then launches the other nodes.

from launch import LaunchDescription
from launch_ros.actions import Node

from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration


def generate_launch_description():

    return LaunchDescription([
        DeclareLaunchArgument('vehicle_config_file'),

        # Launch ROS_Can node
        Node(
            package="ros_can",
            executable="ros_can_node",
            name="ros_can",
            parameters=[
                {"use_sim_time": False}
            ],
            # arguments=['--ros-args', '--log-level', 'debug'],
        ),

        # Launch Orchestrator node
        Node(
            package="orchestrator",
            executable="orchestrator",
            name="orchestrator",
            parameters=[{
                "vehicle_config_file": LaunchConfiguration('vehicle_config_file'),
            }]
        )
    ])
