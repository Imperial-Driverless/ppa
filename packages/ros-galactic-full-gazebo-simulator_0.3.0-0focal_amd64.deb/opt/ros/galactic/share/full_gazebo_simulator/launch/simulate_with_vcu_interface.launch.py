from launch_ros.actions import Node

from launch import LaunchDescription
from launch.actions import   IncludeLaunchDescription, OpaqueFunction, DeclareLaunchArgument, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import  PathJoinSubstitution, LaunchConfiguration
from launch_ros.substitutions import FindPackageShare

from id_track_utils import Track
import xml.etree.ElementTree

from ament_index_python.packages import get_package_share_path

from tempfile import mkdtemp
from pathlib import Path

def generate_gazebo_world(context, tmp_dir, *args, **kwargs):
    track_file = LaunchConfiguration('track_file').perform(context)

    empty_world = get_package_share_path('full_gazebo_simulator') / 'worlds' / 'empty.world'
    doc = xml.etree.ElementTree.parse(empty_world)

    if track_file:
        track: Track = Track.load_from_file(track_file)

        
        world = doc.getroot().find('world')
        assert world is not None
        
        for e in track.as_gazebo_sdf('some_name').iter('include'):
            world.append(e)
    else:
        print('WARNING: No track file specified, using empty world')

    doc.write(Path(tmp_dir, 'world.world'), encoding='utf-8', xml_declaration=False)


def generate_launch_description():
    tmp_dir = mkdtemp()

    full_gazebo_simulator_pkg_share = get_package_share_path('full_gazebo_simulator')

    launch_gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch/gazebo.launch.py'
            ])
        ),
        launch_arguments=[
            ('world', PathJoinSubstitution([tmp_dir, 'world.world'])),
        ]
    )

    set_gazebo_model_path = SetEnvironmentVariable(
        'GAZEBO_MODEL_PATH',
        str(full_gazebo_simulator_pkg_share / 'models')
    )

    set_gazebo_resource_path = SetEnvironmentVariable(
        'GAZEBO_RESOURCE_PATH',
        ':'.join([
            str(full_gazebo_simulator_pkg_share / 'meshes'),
            '/usr/share/gazebo-11'
        ])
    )

    add_gazebo_extensions_to_urdf = Node(
        name='rewrite_urdf',
        package='full_gazebo_simulator',
        executable='rewrite_urdf.py',
        parameters=[
            {'urdf_include': '$(find full_gazebo_simulator)/urdf_extensions/gazebo_extension.xacro'},
            {'input_topic': 'robot_description'},
            {'output_topic': 'robot_description_with_gazebo_extensions'},
            {'vehicle_config_path': LaunchConfiguration('vehicle_config_file')},
        ]
    )

    spawn_vehicle_in_gazebo = Node(
        name='racecar_spawner',
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-entity', 'racecar', 
                   '-topic', 'robot_description_with_gazebo_extensions', 
                   '-z', '0.05',
                   '--ros-args', '--log-level', 'warn'],
        output='screen')
        

    return LaunchDescription([
        DeclareLaunchArgument('track_file', default_value='', description='Path to a track definition file'),
        DeclareLaunchArgument('vehicle_config_file', description='Path to a vehicle config.yaml file'),
        set_gazebo_model_path,
        set_gazebo_resource_path,
        OpaqueFunction(function=generate_gazebo_world, args=[tmp_dir]),
        launch_gazebo,
        add_gazebo_extensions_to_urdf,
        spawn_vehicle_in_gazebo,
    ])
