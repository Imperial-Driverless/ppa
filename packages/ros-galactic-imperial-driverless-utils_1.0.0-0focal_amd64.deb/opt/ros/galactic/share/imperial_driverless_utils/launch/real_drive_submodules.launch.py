# This should be launched by the Orchestrator node, which chooses the nodes to launch
# based on the launch configuration.

from pathlib import Path
from click import launch
import yaml

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import OpaqueFunction, DeclareLaunchArgument
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration, TextSubstitution
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.launch_description_sources.python_launch_description_source import PythonLaunchDescriptionSource

from ament_index_python.packages import get_package_share_path

def generate_launch_description():
    vehicle_description_share = get_package_share_path('vehicle_descriptions')
    
    return LaunchDescription([
        # Define Launch Configurations
        DeclareLaunchArgument('vehicle_config_file', 
            default_value=vehicle_description_share / 'vehicles' / 'ads_dv' / 'config.yaml',
            description='Path to a vehicle config.yaml file'),

        DeclareLaunchArgument('mission_path_generator', 
            description="The mission task to perform, based on the AMI_State variable."),

        # Vehicle Description: ADS_DV
        IncludeLaunchDescription(PythonLaunchDescriptionSource(
            str(vehicle_description_share / 'launch' / 'simple.launch.py')
            ),
            launch_arguments=[
                ('vehicle_name', 'ads_dv'),
                ('use_sim_time', 'false')
            ]
        ),

        # TODO node that talks to lidar

        OpaqueFunction(function=launch_robot_localization),

        # TODO Control command converter (VCUDriveCommand -> AckermannDriveStamped?

        
        # lidar_only_cone_detector
        Node(
            package="lidar_only_cone_detector",
            executable="circle_approximation_detector",
            name="circle_approximation_detector",
            parameters=[{'use_sim_time': False}]
        ),

        # camera
        Node(
            package="camera",
            executable="perception_camera",
            name="perception_camera",
            parameters=[{'use_sim_time': False}]
        ),

        # lidar_camera_fusion
        Node(
            package="lidar_camera_fusion",
            executable="sensor_fusion",
            name="sensor_fusion",
            parameters=[{'use_sim_time': False}]
        ),

        # slam_implementations
        Node(
            package="slam_implementations",
            executable="short_local_buffer",
            name="short_local_buffer",
            parameters=[{'use_sim_time': False}]
        ),

        # path_generators
        # This is dependent on the mission
        Node(
            package="path_generators",
            executable = TextSubstitution(text=LaunchConfiguration('mission_path_generator')),
            name = TextSubstitution(text=LaunchConfiguration('mission_path_generator')),
            parameters=[{'use_sim_time': False}]
        ),

        # path_followers
        Node(
            package="path_followers",
            executable="nav2_regulated_pure_pursuit",
            name="nav2_regulated_pure_pursuit",
            parameters=[{'use_sim_time': False}]
        ),

        # vehicle_controllers
        Node(
            package="vehicle_controllers",
            executable="basic_pid",
            name="basic_pid",
            parameters=[{'use_sim_time': False}]
        ),

    ])


def launch_robot_localization(context, *args, **kwargs):
    '''
    Launches the EKF node, Pointcloud_to_laserscan, and static TF transform nodes.
    '''
    
    vehicle_config_file = Path(LaunchConfiguration('vehicle_config_file').perform(context))
    config = yaml.safe_load(vehicle_config_file.read_text())

    lidar_config = config['sensors']['lidar']

    return [
        Node(
            package="robot_localization",
            executable="ekf_node",
            name="ekf_node",
            output="screen",
            parameters=[
                {
                    "two_d_mode": True,
                    "use_sim_time": True,
                    "smooth_lagged_data": True,
                    "history_length": 1.0,
                    "reset_on_time_jump": True,
                    "publish_tf": True,
                    "map_frame": "map",
                    "odom_frame": "odom",
                    "base_link_frame": "base_link",
                    "world_frame": "odom",
                    "imu0": "/ros_can/imu", # contains orientation, angular velocity and linear acceleration
                    "imu0_relative": True,
                    "imu0_differential": False,
                    "print_diagnostics": True,
                    "imu0_config": [
                        False, False, False, # X, Y, Z
                        False, False, True,  # roll, pitch, yaw
                        False, False, False, # vx, vy, vz
                        False,  False,  True, # roll', pitch', yaw'
                        True,  True,  False, # ax, ay, az
                    ],
                    "twist0": "/ros_can/twist",
                    "twist0_relative": True,
                    "twist0_differential": False,
                    "twist0_config": [
                        False, False, False, # X, Y, Z
                        False, False, False,  # roll, pitch, yaw
                        True, True, False, # vx, vy, vz
                        False,  False,  False, # roll', pitch', yaw'
                        False,  False,  False, # ax, ay, az
                    ],
                    # This should not be needed in reality (no diff from sim)
                    # "initial_state":[       # Robot center is base_link, but FSDS simulator starts it where the 'com' link is 
                    #     -(config['kinematics']['com']['x']),
                    #     -(config['kinematics']['com']['y']),
                    #     -(config['kinematics']['com']['z']),
                    #     0.0, 0.0, 0.0,
                    #     0.0, 0.0, 0.0,
                    #     0.0, 0.0, 0.0,
                    #     0.0, 0.0, 0.0
                    # ],
                }
            ],remappings=[
                ('/odometry/filtered', '/odom')
            ]
        ),

        # Pointcloud to Laserscan
        Node(
            package='pointcloud_to_laserscan',
            executable='pointcloud_to_laserscan_node',
            name='pointcloud_to_laserscan',
            output='screen',
            parameters=[
                {'min_height': -lidar_config['position_relative_to_base_link']['z'] + 0.05}, # to remove ground
                {'angle_min': -lidar_config['fov'] / 2.0},
                {'angle_max':  lidar_config['fov'] / 2.0},
                {'angle_increment': lidar_config['fov'] / lidar_config['num_beams']},
                {'range_min': 0.5},
                {'range_max': 20.0},
                {'use_sim_time': False},
            ],
            remappings=[
                ('cloud_in', '/lidar/Lidar1'),
            ]
        ),

        # These may not be needed on the actual car
        # this node assumes that we're using perfect odometry
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='static_transform_odom_to_fsds_map',
            output='screen',
            parameters=[{'use_sim_time': False}],
            arguments=['0', '0', '0', '0', '0', '0', 'odom', 'fsds/map'],
        ),
        # this node asserts that gt_map is the same as fsds/map
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='static_transform_fsds_map_to_gt_map',
            output='screen',
            parameters=[{'use_sim_time': False}],
            arguments=['0', '0', '0', '0', '0', '0', 'fsds/map', 'gt_map']
        ),
        # this node asserts that fsds/FSCar frame is the same as base_link
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='static_transform_fsds_FSCar_to_base_link',
            output='screen',
            arguments=['0.6', '0', '0', '0', '0', '0', 'base_link', 'fsds/FSCar'],
            parameters=[{'use_sim_time': True}],
        ),
        # this node asserts that fsds/Lidar1 frame is the same as laser
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='static_transform_fsds_Lidar1_to_laser',
            output='screen',
            arguments=['0', '0', '0', '0', '0', '0', 'fsds/Lidar1', 'laser'],
            parameters=[{'use_sim_time': True}],
        ),

    ]