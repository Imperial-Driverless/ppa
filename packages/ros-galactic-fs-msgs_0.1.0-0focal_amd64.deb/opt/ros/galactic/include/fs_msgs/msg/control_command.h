// generated from rosidl_generator_c/resource/idl.h.em
// with input from fs_msgs:msg/ControlCommand.idl
// generated code does not contain a copyright notice

#ifndef FS_MSGS__MSG__CONTROL_COMMAND_H_
#define FS_MSGS__MSG__CONTROL_COMMAND_H_

#include "fs_msgs/msg/detail/control_command__struct.h"
#include "fs_msgs/msg/detail/control_command__functions.h"
#include "fs_msgs/msg/detail/control_command__type_support.h"

#endif  // FS_MSGS__MSG__CONTROL_COMMAND_H_
