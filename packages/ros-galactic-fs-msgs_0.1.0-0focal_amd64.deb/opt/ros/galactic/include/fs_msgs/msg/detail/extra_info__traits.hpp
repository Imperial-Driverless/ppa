// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from fs_msgs:msg/ExtraInfo.idl
// generated code does not contain a copyright notice

#ifndef FS_MSGS__MSG__DETAIL__EXTRA_INFO__TRAITS_HPP_
#define FS_MSGS__MSG__DETAIL__EXTRA_INFO__TRAITS_HPP_

#include "fs_msgs/msg/detail/extra_info__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace rosidl_generator_traits
{

inline void to_yaml(
  const fs_msgs::msg::ExtraInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: doo_counter
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "doo_counter: ";
    value_to_yaml(msg.doo_counter, out);
    out << "\n";
  }

  // member: laps
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.laps.size() == 0) {
      out << "laps: []\n";
    } else {
      out << "laps:\n";
      for (auto item : msg.laps) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const fs_msgs::msg::ExtraInfo & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<fs_msgs::msg::ExtraInfo>()
{
  return "fs_msgs::msg::ExtraInfo";
}

template<>
inline const char * name<fs_msgs::msg::ExtraInfo>()
{
  return "fs_msgs/msg/ExtraInfo";
}

template<>
struct has_fixed_size<fs_msgs::msg::ExtraInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<fs_msgs::msg::ExtraInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<fs_msgs::msg::ExtraInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FS_MSGS__MSG__DETAIL__EXTRA_INFO__TRAITS_HPP_
