// generated from rosidl_generator_c/resource/idl.h.em
// with input from fs_msgs:msg/GoSignal.idl
// generated code does not contain a copyright notice

#ifndef FS_MSGS__MSG__GO_SIGNAL_H_
#define FS_MSGS__MSG__GO_SIGNAL_H_

#include "fs_msgs/msg/detail/go_signal__struct.h"
#include "fs_msgs/msg/detail/go_signal__functions.h"
#include "fs_msgs/msg/detail/go_signal__type_support.h"

#endif  // FS_MSGS__MSG__GO_SIGNAL_H_
