// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from fs_msgs:msg/ControlCommand.idl
// generated code does not contain a copyright notice

#ifndef FS_MSGS__MSG__DETAIL__CONTROL_COMMAND__FUNCTIONS_H_
#define FS_MSGS__MSG__DETAIL__CONTROL_COMMAND__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "fs_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "fs_msgs/msg/detail/control_command__struct.h"

/// Initialize msg/ControlCommand message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * fs_msgs__msg__ControlCommand
 * )) before or use
 * fs_msgs__msg__ControlCommand__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_fs_msgs
bool
fs_msgs__msg__ControlCommand__init(fs_msgs__msg__ControlCommand * msg);

/// Finalize msg/ControlCommand message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_fs_msgs
void
fs_msgs__msg__ControlCommand__fini(fs_msgs__msg__ControlCommand * msg);

/// Create msg/ControlCommand message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * fs_msgs__msg__ControlCommand__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_fs_msgs
fs_msgs__msg__ControlCommand *
fs_msgs__msg__ControlCommand__create();

/// Destroy msg/ControlCommand message.
/**
 * It calls
 * fs_msgs__msg__ControlCommand__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_fs_msgs
void
fs_msgs__msg__ControlCommand__destroy(fs_msgs__msg__ControlCommand * msg);


/// Initialize array of msg/ControlCommand messages.
/**
 * It allocates the memory for the number of elements and calls
 * fs_msgs__msg__ControlCommand__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_fs_msgs
bool
fs_msgs__msg__ControlCommand__Sequence__init(fs_msgs__msg__ControlCommand__Sequence * array, size_t size);

/// Finalize array of msg/ControlCommand messages.
/**
 * It calls
 * fs_msgs__msg__ControlCommand__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_fs_msgs
void
fs_msgs__msg__ControlCommand__Sequence__fini(fs_msgs__msg__ControlCommand__Sequence * array);

/// Create array of msg/ControlCommand messages.
/**
 * It allocates the memory for the array and calls
 * fs_msgs__msg__ControlCommand__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_fs_msgs
fs_msgs__msg__ControlCommand__Sequence *
fs_msgs__msg__ControlCommand__Sequence__create(size_t size);

/// Destroy array of msg/ControlCommand messages.
/**
 * It calls
 * fs_msgs__msg__ControlCommand__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_fs_msgs
void
fs_msgs__msg__ControlCommand__Sequence__destroy(fs_msgs__msg__ControlCommand__Sequence * array);

#ifdef __cplusplus
}
#endif

#endif  // FS_MSGS__MSG__DETAIL__CONTROL_COMMAND__FUNCTIONS_H_
