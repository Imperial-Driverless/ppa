// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from fs_msgs:msg/Track.idl
// generated code does not contain a copyright notice
#include "fs_msgs/msg/detail/track__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `track`
#include "fs_msgs/msg/detail/cone__functions.h"

bool
fs_msgs__msg__Track__init(fs_msgs__msg__Track * msg)
{
  if (!msg) {
    return false;
  }
  // track
  if (!fs_msgs__msg__Cone__Sequence__init(&msg->track, 0)) {
    fs_msgs__msg__Track__fini(msg);
    return false;
  }
  return true;
}

void
fs_msgs__msg__Track__fini(fs_msgs__msg__Track * msg)
{
  if (!msg) {
    return;
  }
  // track
  fs_msgs__msg__Cone__Sequence__fini(&msg->track);
}

fs_msgs__msg__Track *
fs_msgs__msg__Track__create()
{
  fs_msgs__msg__Track * msg = (fs_msgs__msg__Track *)malloc(sizeof(fs_msgs__msg__Track));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(fs_msgs__msg__Track));
  bool success = fs_msgs__msg__Track__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
fs_msgs__msg__Track__destroy(fs_msgs__msg__Track * msg)
{
  if (msg) {
    fs_msgs__msg__Track__fini(msg);
  }
  free(msg);
}


bool
fs_msgs__msg__Track__Sequence__init(fs_msgs__msg__Track__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  fs_msgs__msg__Track * data = NULL;
  if (size) {
    data = (fs_msgs__msg__Track *)calloc(size, sizeof(fs_msgs__msg__Track));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = fs_msgs__msg__Track__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        fs_msgs__msg__Track__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
fs_msgs__msg__Track__Sequence__fini(fs_msgs__msg__Track__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      fs_msgs__msg__Track__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

fs_msgs__msg__Track__Sequence *
fs_msgs__msg__Track__Sequence__create(size_t size)
{
  fs_msgs__msg__Track__Sequence * array = (fs_msgs__msg__Track__Sequence *)malloc(sizeof(fs_msgs__msg__Track__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = fs_msgs__msg__Track__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
fs_msgs__msg__Track__Sequence__destroy(fs_msgs__msg__Track__Sequence * array)
{
  if (array) {
    fs_msgs__msg__Track__Sequence__fini(array);
  }
  free(array);
}
