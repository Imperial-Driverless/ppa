// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FS_MSGS__MSG__EXTRA_INFO_HPP_
#define FS_MSGS__MSG__EXTRA_INFO_HPP_

#include "fs_msgs/msg/detail/extra_info__struct.hpp"
#include "fs_msgs/msg/detail/extra_info__builder.hpp"
#include "fs_msgs/msg/detail/extra_info__traits.hpp"

#endif  // FS_MSGS__MSG__EXTRA_INFO_HPP_
