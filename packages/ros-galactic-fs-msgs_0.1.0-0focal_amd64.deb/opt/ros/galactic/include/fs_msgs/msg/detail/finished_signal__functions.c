// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from fs_msgs:msg/FinishedSignal.idl
// generated code does not contain a copyright notice
#include "fs_msgs/msg/detail/finished_signal__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
fs_msgs__msg__FinishedSignal__init(fs_msgs__msg__FinishedSignal * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    fs_msgs__msg__FinishedSignal__fini(msg);
    return false;
  }
  // placeholder
  return true;
}

void
fs_msgs__msg__FinishedSignal__fini(fs_msgs__msg__FinishedSignal * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // placeholder
}

fs_msgs__msg__FinishedSignal *
fs_msgs__msg__FinishedSignal__create()
{
  fs_msgs__msg__FinishedSignal * msg = (fs_msgs__msg__FinishedSignal *)malloc(sizeof(fs_msgs__msg__FinishedSignal));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(fs_msgs__msg__FinishedSignal));
  bool success = fs_msgs__msg__FinishedSignal__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
fs_msgs__msg__FinishedSignal__destroy(fs_msgs__msg__FinishedSignal * msg)
{
  if (msg) {
    fs_msgs__msg__FinishedSignal__fini(msg);
  }
  free(msg);
}


bool
fs_msgs__msg__FinishedSignal__Sequence__init(fs_msgs__msg__FinishedSignal__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  fs_msgs__msg__FinishedSignal * data = NULL;
  if (size) {
    data = (fs_msgs__msg__FinishedSignal *)calloc(size, sizeof(fs_msgs__msg__FinishedSignal));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = fs_msgs__msg__FinishedSignal__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        fs_msgs__msg__FinishedSignal__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
fs_msgs__msg__FinishedSignal__Sequence__fini(fs_msgs__msg__FinishedSignal__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      fs_msgs__msg__FinishedSignal__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

fs_msgs__msg__FinishedSignal__Sequence *
fs_msgs__msg__FinishedSignal__Sequence__create(size_t size)
{
  fs_msgs__msg__FinishedSignal__Sequence * array = (fs_msgs__msg__FinishedSignal__Sequence *)malloc(sizeof(fs_msgs__msg__FinishedSignal__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = fs_msgs__msg__FinishedSignal__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
fs_msgs__msg__FinishedSignal__Sequence__destroy(fs_msgs__msg__FinishedSignal__Sequence * array)
{
  if (array) {
    fs_msgs__msg__FinishedSignal__Sequence__fini(array);
  }
  free(array);
}
