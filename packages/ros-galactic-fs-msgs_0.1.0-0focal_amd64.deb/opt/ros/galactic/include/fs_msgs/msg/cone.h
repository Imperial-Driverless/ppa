// generated from rosidl_generator_c/resource/idl.h.em
// with input from fs_msgs:msg/Cone.idl
// generated code does not contain a copyright notice

#ifndef FS_MSGS__MSG__CONE_H_
#define FS_MSGS__MSG__CONE_H_

#include "fs_msgs/msg/detail/cone__struct.h"
#include "fs_msgs/msg/detail/cone__functions.h"
#include "fs_msgs/msg/detail/cone__type_support.h"

#endif  // FS_MSGS__MSG__CONE_H_
