// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from fs_msgs:msg/Track.idl
// generated code does not contain a copyright notice

#ifndef FS_MSGS__MSG__DETAIL__TRACK__TRAITS_HPP_
#define FS_MSGS__MSG__DETAIL__TRACK__TRAITS_HPP_

#include "fs_msgs/msg/detail/track__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'track'
#include "fs_msgs/msg/detail/cone__traits.hpp"

namespace rosidl_generator_traits
{

inline void to_yaml(
  const fs_msgs::msg::Track & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: track
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.track.size() == 0) {
      out << "track: []\n";
    } else {
      out << "track:\n";
      for (auto item : msg.track) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const fs_msgs::msg::Track & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<fs_msgs::msg::Track>()
{
  return "fs_msgs::msg::Track";
}

template<>
inline const char * name<fs_msgs::msg::Track>()
{
  return "fs_msgs/msg/Track";
}

template<>
struct has_fixed_size<fs_msgs::msg::Track>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<fs_msgs::msg::Track>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<fs_msgs::msg::Track>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FS_MSGS__MSG__DETAIL__TRACK__TRAITS_HPP_
