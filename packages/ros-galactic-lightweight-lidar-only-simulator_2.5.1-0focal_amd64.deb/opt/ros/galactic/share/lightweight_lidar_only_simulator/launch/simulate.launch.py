"""
This will launch the simulator and the Nav2 map server. 
This will NOT launch: the GUI, the vehicle model nor any teleoperation script.
Please use the custom.launch.py launchfile from imperial_driverless_utils to
launch everything at once.

Choose the map by setting the 'map' launch argument.
"""

from datetime import timedelta
from pathlib import Path
from tempfile import mkdtemp

import lifecycle_msgs.msg
from ament_index_python.packages import get_package_share_directory
from id_track_utils import Track
from launch_ros.actions import LifecycleNode, Node
from launch_ros.event_handlers import OnStateTransition
from launch_ros.events.lifecycle import ChangeState
from launch_ros.substitutions import FindPackageShare

import launch
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, EmitEvent, ExecuteProcess,
                            IncludeLaunchDescription, OpaqueFunction,
                            RegisterEventHandler)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution


def delayed(e: EmitEvent, by: timedelta) -> ExecuteProcess:
    return ExecuteProcess(
        cmd=['sleep', str(by.total_seconds())],
        on_exit=[
            e
        ]
    )

def launch_map_server(context, *args, **kwargs):
    track_file = LaunchConfiguration('track_file').perform(context)
    
    if not track_file:
        raise Exception(
            'No track file specified. Use `ros2 launch lighweight_lidar_only_simulator '
            'simulate.launch.py track_file:=<path to track file>` to specify one.')

    t = Track.load_from_file(track_file)
    tmp_dir = Path(mkdtemp())

    resolution = 0.03
    map_image, orig_x, orig_y = t.as_occupancy_grid(resolution=resolution, cone_radius=0.10)
    


    map_image.save(tmp_dir / 'map.png')
    map_yaml_file = tmp_dir / 'map.yaml'
    map_yaml_file.write_text(f"""
        image: map.png
        resolution: {resolution}
        origin:  [{orig_x}, {orig_y}, 0.]
        negate: 0
        occupied_thresh: 0.8
        free_thresh: 0.2
        """
    )

    # ================
    # == MAP SERVER ==
    # ================
    map_server_node = LifecycleNode(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        namespace='',
        parameters=[
            {'yaml_filename': str(map_yaml_file)},
            {'topic_name': '/ground_truth/map'}
        ])

    map_server_emit_activation_event = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=launch.events.matches_action(
                map_server_node),
            transition_id=lifecycle_msgs.msg.Transition.TRANSITION_ACTIVATE,
        ))

    map_server_emit_configure_event = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=launch.events.matches_action(
                map_server_node),
            transition_id=lifecycle_msgs.msg.Transition.TRANSITION_CONFIGURE,
        ))

    map_server_inactive_state_handler = RegisterEventHandler(
        OnStateTransition(
            target_lifecycle_node=map_server_node,
            goal_state='inactive',
            entities=[map_server_emit_activation_event],
        ))

    return [
        map_server_node, 
        map_server_inactive_state_handler, 
        delayed(map_server_emit_configure_event, timedelta(seconds=2.)), 
        map_server_emit_activation_event
    ]

def generate_launch_description():
    package_dir = get_package_share_directory(
        'lightweight_lidar_only_simulator')

    simulator_node = Node(
        package='lightweight_lidar_only_simulator',
        executable='simulate',
        name='lightweight_lidar_only_simulator',
        output='screen',
        parameters=[
            {'broadcast_transform': LaunchConfiguration('broadcast_transform')},
            f'{package_dir}/config/params.yaml',
        ]
    )

    return LaunchDescription([
        DeclareLaunchArgument(name='broadcast_transform', default_value='true'),
        DeclareLaunchArgument(name='track_file', default_value=''),
        OpaqueFunction(function=launch_map_server),
        simulator_node,
    ])


if __name__ == '__main__':
    generate_launch_description()
