import os
from pathlib import Path
from tempfile import mkdtemp
from typing import Dict, List, Tuple, Type

import yaml

import click
import imperial_driverless_utils
from launch.actions.execute_process import ExecuteProcess
from launch.launch_description_entity import LaunchDescriptionEntity
from launch_ros.actions import Node
from launch import LaunchDescription
from launch.actions import RegisterEventHandler, EmitEvent
from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.events import Shutdown
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources.python_launch_description_source import PythonLaunchDescriptionSource
from ros2pkg.api import get_executable_paths, PackageNotFound

from ament_index_python.packages import PackageNotFoundError, get_package_share_path

from imperial_driverless_utils import get_rviz_config, marker_array_display, map_display, path_display

from id_track_utils.track import Track # has to be apt-installed to be detected

from dataclasses import dataclass, field

import rosidl_runtime_py.convert

RvizDisplay = Dict

@dataclass
class Package:
    name: str
    url: str

    rviz_displays: List[RvizDisplay]
    custom_options: List[Tuple[str, List[LaunchDescriptionEntity]]] = field(default_factory=list)
    fallback_options: List[Tuple[str, List[LaunchDescriptionEntity]]] = field(default_factory=list)
    
    
    # This is a horribly coupled way of specifying the package parameters.
    # Each time the parameter names or types change in any package,
    # they have to be updated here. The proper solution would be to have all
    # the packages expose launch files, as there exists an API to get 
    # all available arguments for a launch file, so we wouldn't have to specify
    # them here. 
    parameters: List[Tuple[str, Type]] = field(default_factory=list) 

    @property
    def executable_names(self):
        return [os.path.basename(path) for path in get_executable_paths(package_name=self.name)]

collection_pkgs = [
    Package('lidar_only_cone_detector', 
        url='https://github.com/Imperial-Driverless/lidar_only_cone_detector',
        rviz_displays=[
            marker_array_display('/perceived_cones_rviz_markers', 'Perceived Cones'),
        ]
    ),
    Package('slam_implementations',
        url='https://github.com/Imperial-Driverless/slam_implementations',
        rviz_displays=[
            marker_array_display('/cone_map_rviz_markers', 'Cone Map'),
        ],
        fallback_options=[
            (click.style('publish a static identity transform from map to odom', fg='cyan'), [
                Node(
                    package='tf2_ros',
                    executable='static_transform_publisher',
                    name='map_odom_static_tf_publisher',
                    arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom']
                )
            ])
        ]
    ),
    Package('path_generators',
        url='https://github.com/Imperial-Driverless/path_generators',
        rviz_displays=[
            path_display,
            marker_array_display('/path_generator_visualization', 'Path Generator Visualization'),
        ],
        parameters=[
            ('use_smoothing', bool),
            ('smoothing', float),
            ('sample_density', float)
        ]
    ),
    Package('path_followers',
        url='https://github.com/Imperial-Driverless/path_followers',
        rviz_displays=[],
        fallback_options=[
            (click.style('launch twist from car_keyop', fg='cyan'), [
                Node(
                    package='car_keyop',
                    executable='twist',
                    name='car_keyop',
                    arguments=['8.0', '1'] # max linear and angular velocities
                )
            ])
        ]
    ),
]


def generate_launch_description():
    tmp_dir = Path(mkdtemp())

    rviz_displays: Dict[str, List[RvizDisplay]] = {}

    track_file = select_racetrack_map()

    vehicle_ld, vehicle_config_file = choose_vehicle()

    sim_ld, rviz_displays['from simulator'] = simulator_ld(track_file, vehicle_config_file)

    package_nodes, rviz_displays['from nodes'] = package_nodes_ld()

    ground_truth_cone_map_ld, rviz_displays['from gt cone map'] = ground_truth_cone_map_publisher(track_file)

    # dict to list flattening
    all_rviz_displays = [d for disps in rviz_displays.values() for d in disps]

    return LaunchDescription([
        *ground_truth_cone_map_ld,
        *sim_ld,
        *vehicle_ld,
        *rviz_ld(tmp_dir, all_rviz_displays),
        *package_nodes,
    ])
    

    

def select_racetrack_map() -> Path:
    cone_map_folder = get_package_share_path('imperial_driverless_utils') / 'cone_maps'

    cone_map_paths = [x for x in cone_map_folder.iterdir()]

    click.echo(f'Select a cone map:')
    for i, cone_map in enumerate(cone_map_paths):
        click.echo( f"{i}. {click.style(cone_map.name, fg='green')}")


    selection = click.prompt(
        "Please select:",
        type=click.Choice([str(i) for i in range(len(cone_map_paths))]),
        default="0",
        show_choices=False,
    )

    assert isinstance(selection, str)

    return cone_map_paths[int(selection)]

def ground_truth_cone_map_publisher(
    track_file: Path
) -> Tuple[List[LaunchDescriptionEntity], List[RvizDisplay]]:

    t = Track.load_from_file(track_file)
    message_content = yaml.safe_dump(t.as_conemap_dict())

    gt_cone_map_publihser = ExecuteProcess(
        cmd=[
            'ros2', 'topic', 'pub',                       
            '/ground_truth/cone_map',                     # topic
            'imperial_driverless_interfaces/msg/ConeMap', # type
            message_content                         # message content
        ]
    )

    cone_map_message = t.as_conemap_message()
    visualization_message = imperial_driverless_utils.idi_msgs_to_rviz_markers.conemap_to_markerarray(cone_map_message)
    visualization_yaml = rosidl_runtime_py.convert.message_to_yaml(visualization_message)

    gt_cone_map_visualization_publisher = ExecuteProcess(
        cmd=[
            'ros2', 'topic', 'pub', '--once',
            '/ground_truth/cone_map_rviz',
            'visualization_msgs/MarkerArray',
            visualization_yaml
        ]
    )

    return [
        gt_cone_map_publihser,
        gt_cone_map_visualization_publisher,
    ], [marker_array_display('/ground_truth/cone_map_rviz', 'Ground Truth Cones')]

def rviz_ld(tmp_dir: Path, displays: List[RvizDisplay]) -> List[LaunchDescriptionEntity]:
    rviz_config_file = tmp_dir / 'rviz_config.rviz'
    
    rviz_config_file.write_text(get_rviz_config(displays))


    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=[
            '-d', str(rviz_config_file),
            '--ros-args', '--log-level', 'error',
        ])

    shutdown_on_rviz_exit = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=rviz_node,
            on_exit=[
                EmitEvent(event=Shutdown()),
            ],
        ))
    
    return [rviz_node, shutdown_on_rviz_exit]

def simulator_ld(
    track_file: Path,
    vehicle_config_file: Path,
) -> Tuple[List[LaunchDescriptionEntity], List[RvizDisplay]]:
    
    supported_simulators = ['lightweight_lidar_only_simulator', 'full_gazebo_simulator']
    launch_options: List[Tuple[str, Path]] = []
    
    for sim_name in supported_simulators:
        try:
            pkg_path = get_package_share_path(sim_name)
            for launch_file in (pkg_path / 'launch').glob('*.launch*'):
                launch_options.append((click.style(f'{sim_name}/{launch_file.name}', fg='green'), launch_file))

        except PackageNotFoundError:
            pass

    if not launch_options:
        click.echo(click.style(f'No supported simulator found. Supported simulators: {supported_simulators}', fg='red'))
        return [], []

    click.echo(click.style(f'Select a simulator launch file:', fg='white'))
    
    for i, (text, _) in enumerate(launch_options):
        click.echo( f"{i}. {text}")

    selection = click.prompt(
        "Please select:",
        type=click.Choice([str(i) for i, _ in enumerate(launch_options)]),
        default="0",
        show_choices=False,
    )

    assert isinstance(selection, str)
    selected_option = launch_options[int(selection)]

    simulator = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            str(selected_option[1])
            
        ),
        launch_arguments=[
            ('track_file', str(track_file)),
            ('vehicle_config_file', str(vehicle_config_file)),
        ]
    )
    
    rviz_displays = [map_display] if 'lightweight_lidar_only_simulator' in selected_option[0] else []

    return [simulator], rviz_displays

def package_nodes_ld() -> Tuple[List[LaunchDescriptionEntity], List[RvizDisplay]]:
    pkg_found_common_options = [
        (click.style('do not launch any executable from this package', fg='yellow'), [])
    ]

    pkg_not_found_common_options = [
        (click.style('Ignore, I will start it myself', fg='yellow'), []),
        # (click.style('Clone from GitHub, build and source', fg='yellow'), []),
    ]

    ld = []
    rviz_displays = []

    for pkg in collection_pkgs:
        all_options = []
        try:
            executables = pkg.executable_names
                
            executable_options = [(
                click.style(executable, fg='green'), [
                Node(
                    package=pkg.name,
                    executable=executable,
                    name=executable,
                    emulate_tty=True,
                    output='screen',
                )
            ]) for executable in executables]
            
            all_options = [
                *pkg_found_common_options,
                *executable_options,
                *pkg.custom_options,
                *pkg.fallback_options,
            ]

            click.echo(click.style(f'Select an executable from {pkg.name}', fg='white'))


        except PackageNotFound:
            click.echo(click.style(f'Package {pkg.name} not found. What to do?', fg='red'))
            
            all_options = [
                *pkg_not_found_common_options,
                *pkg.fallback_options
            ]

            
        for i, (text, _) in enumerate(all_options):
            click.echo( f"{i}. {text}")
        
        selection = click.prompt(
            "Please select:",
            type=click.Choice([str(i) for i, _ in enumerate(all_options)]),
            default="0",
            show_choices=False,
        )

        assert isinstance(selection, str)
        selected_option = all_options[int(selection)]
        _, entities = selected_option

        if entities and isinstance(entities[0], Node) and pkg.parameters:
            click.echo(click.style(f'Set parameters for {pkg.name}', fg='white'))
            parameters = [{p_name: val} for p_name, p_type in pkg.parameters for val in [click.prompt(f'(optional) value for parameter {p_name}', default=p_type(), type=p_type)] if val]
            entities[0] = Node(
                package=pkg.name,
                executable=entities[0].node_executable,
                name=entities[0].node_executable,
                emulate_tty=True,
                output='screen',
                parameters=parameters,
            )
            
        ld.extend(entities)

        # if we're launching something we might need its visualization.
        if entities:
            rviz_displays.extend(pkg.rviz_displays)

    return ld, rviz_displays

def choose_vehicle() -> Tuple[List[LaunchDescriptionEntity], Path]:
    
    vehicle_descriptions_share = get_package_share_path('vehicle_descriptions')
    
    vehicle_names = [p.name for p in vehicle_descriptions_share.glob('vehicles/*')]

    click.echo(click.style('Select a vehicle', fg='white'))

    for i, vehicle_name in enumerate(vehicle_names):
        click.echo( f"{i}. {click.style(vehicle_name, fg='green')}")

    selection = click.prompt(
        "Please select:",
        type=click.Choice([str(i) for i, _ in enumerate(vehicle_names)]),
        default="0",
        show_choices=False,
    )

    assert isinstance(selection, str)
    vehicle_name = vehicle_names[int(selection)]

    return [
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                str(vehicle_descriptions_share / 'launch' / 'simple.launch.py')
            ),
            launch_arguments=[
                ('vehicle_name', vehicle_name)
            ]
        )
    ], vehicle_descriptions_share / 'vehicles' / vehicle_name / 'config.yaml'
