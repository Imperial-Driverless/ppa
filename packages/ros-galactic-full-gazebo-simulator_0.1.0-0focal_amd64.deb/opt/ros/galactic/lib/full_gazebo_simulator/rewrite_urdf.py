#!/usr/bin/env python3

from pathlib import Path
import sys

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSDurabilityPolicy
import std_msgs.msg

import xacro
import xml.dom.minidom

class URDFRewriter(Node):
    def __init__(self):
        super().__init__('urdf_rewriter')

        self.declare_parameter('urdf_include', '')
        self.declare_parameter('input_topic', '/robot_description')
        self.declare_parameter('output_topic', '/robot_description_with_gazebo_extensions')
        self.declare_parameter('vehicle_config_path', '')

        self.vehicle_config_path = self.get_parameter('vehicle_config_path').value
        if not self.vehicle_config_path:
            raise ValueError('vehicle_config_path parameter must be set')

        latching_qos = QoSProfile(depth=1,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL)


        self.urdf_sub = self.create_subscription(
            std_msgs.msg.String,
            self.get_parameter('input_topic').value,
            self.rewrite_and_republish,
            latching_qos)
        
        self.urdf_pub = self.create_publisher(
            std_msgs.msg.String, 
            self.get_parameter('output_topic').value,
            latching_qos
        )

    def rewrite_and_republish(self, msg: std_msgs.msg.String):
        urdf_include = self.get_parameter('urdf_include').value
        
        doc: xml.dom.minidom.Document = xacro.parse(inp=msg.data) # type: ignore

        if urdf_include and doc.firstChild is not None:
            e = xml.dom.minidom.Element('xacro:include')
            e.setAttributeNode(doc.createAttribute('filename'))
            e.setAttribute('filename', urdf_include)
            doc.firstChild.appendChild(e)
        
        xacro.process_doc(doc, mappings={'config_file_path': self.vehicle_config_path})

        self.urdf_pub.publish(std_msgs.msg.String(data=doc.toprettyxml()))

def main():
    rclpy.init(args=sys.argv[1:])
    rclpy.spin(URDFRewriter())
    rclpy.shutdown()

if __name__ == '__main__':
    main()
