// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__STRUCT_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveCommand __attribute__((deprecated))
#else
# define DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveCommand __declspec(deprecated)
#endif

namespace imperial_driverless_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct VCUDriveCommand_
{
  using Type = VCUDriveCommand_<ContainerAllocator>;

  explicit VCUDriveCommand_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->motor_torque_nm = 0.0;
      this->steering_angle_rad = 0.0;
      this->brake_pct = 0.0;
    }
  }

  explicit VCUDriveCommand_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->motor_torque_nm = 0.0;
      this->steering_angle_rad = 0.0;
      this->brake_pct = 0.0;
    }
  }

  // field types and members
  using _motor_torque_nm_type =
    double;
  _motor_torque_nm_type motor_torque_nm;
  using _steering_angle_rad_type =
    double;
  _steering_angle_rad_type steering_angle_rad;
  using _brake_pct_type =
    double;
  _brake_pct_type brake_pct;

  // setters for named parameter idiom
  Type & set__motor_torque_nm(
    const double & _arg)
  {
    this->motor_torque_nm = _arg;
    return *this;
  }
  Type & set__steering_angle_rad(
    const double & _arg)
  {
    this->steering_angle_rad = _arg;
    return *this;
  }
  Type & set__brake_pct(
    const double & _arg)
  {
    this->brake_pct = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> *;
  using ConstRawPtr =
    const imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveCommand
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__imperial_driverless_interfaces__msg__VCUDriveCommand
    std::shared_ptr<imperial_driverless_interfaces::msg::VCUDriveCommand_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const VCUDriveCommand_ & other) const
  {
    if (this->motor_torque_nm != other.motor_torque_nm) {
      return false;
    }
    if (this->steering_angle_rad != other.steering_angle_rad) {
      return false;
    }
    if (this->brake_pct != other.brake_pct) {
      return false;
    }
    return true;
  }
  bool operator!=(const VCUDriveCommand_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct VCUDriveCommand_

// alias to use template instance with default allocator
using VCUDriveCommand =
  imperial_driverless_interfaces::msg::VCUDriveCommand_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__STRUCT_HPP_
