// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__BUILDER_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__BUILDER_HPP_

#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace imperial_driverless_interfaces
{

namespace msg
{

namespace builder
{

class Init_VCUDriveCommand_brake_pct
{
public:
  explicit Init_VCUDriveCommand_brake_pct(::imperial_driverless_interfaces::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  ::imperial_driverless_interfaces::msg::VCUDriveCommand brake_pct(::imperial_driverless_interfaces::msg::VCUDriveCommand::_brake_pct_type arg)
  {
    msg_.brake_pct = std::move(arg);
    return std::move(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_steering_angle_rad
{
public:
  explicit Init_VCUDriveCommand_steering_angle_rad(::imperial_driverless_interfaces::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  Init_VCUDriveCommand_brake_pct steering_angle_rad(::imperial_driverless_interfaces::msg::VCUDriveCommand::_steering_angle_rad_type arg)
  {
    msg_.steering_angle_rad = std::move(arg);
    return Init_VCUDriveCommand_brake_pct(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_motor_torque_nm
{
public:
  Init_VCUDriveCommand_motor_torque_nm()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VCUDriveCommand_steering_angle_rad motor_torque_nm(::imperial_driverless_interfaces::msg::VCUDriveCommand::_motor_torque_nm_type arg)
  {
    msg_.motor_torque_nm = std::move(arg);
    return Init_VCUDriveCommand_steering_angle_rad(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::imperial_driverless_interfaces::msg::VCUDriveCommand>()
{
  return imperial_driverless_interfaces::msg::builder::Init_VCUDriveCommand_motor_torque_nm();
}

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__BUILDER_HPP_
