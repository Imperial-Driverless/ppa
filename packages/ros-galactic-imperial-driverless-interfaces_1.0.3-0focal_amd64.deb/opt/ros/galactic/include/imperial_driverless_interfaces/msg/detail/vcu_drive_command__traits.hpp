// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__TRAITS_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__TRAITS_HPP_

#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace rosidl_generator_traits
{

inline void to_yaml(
  const imperial_driverless_interfaces::msg::VCUDriveCommand & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: motor_torque_nm
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motor_torque_nm: ";
    value_to_yaml(msg.motor_torque_nm, out);
    out << "\n";
  }

  // member: steering_angle_rad
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "steering_angle_rad: ";
    value_to_yaml(msg.steering_angle_rad, out);
    out << "\n";
  }

  // member: brake_pct
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "brake_pct: ";
    value_to_yaml(msg.brake_pct, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const imperial_driverless_interfaces::msg::VCUDriveCommand & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<imperial_driverless_interfaces::msg::VCUDriveCommand>()
{
  return "imperial_driverless_interfaces::msg::VCUDriveCommand";
}

template<>
inline const char * name<imperial_driverless_interfaces::msg::VCUDriveCommand>()
{
  return "imperial_driverless_interfaces/msg/VCUDriveCommand";
}

template<>
struct has_fixed_size<imperial_driverless_interfaces::msg::VCUDriveCommand>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<imperial_driverless_interfaces::msg::VCUDriveCommand>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<imperial_driverless_interfaces::msg::VCUDriveCommand>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__TRAITS_HPP_
