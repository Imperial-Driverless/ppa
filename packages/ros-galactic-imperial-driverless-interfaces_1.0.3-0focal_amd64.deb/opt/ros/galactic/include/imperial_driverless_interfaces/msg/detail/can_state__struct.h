// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from imperial_driverless_interfaces:msg/CanState.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CAN_STATE__STRUCT_H_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CAN_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'AS_OFF'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AS_OFF = 0
};

/// Constant 'AS_READY'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AS_READY = 1
};

/// Constant 'AS_DRIVING'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AS_DRIVING = 2
};

/// Constant 'AS_EMERGENCY_BRAKE'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AS_EMERGENCY_BRAKE = 3
};

/// Constant 'AS_FINISHED'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AS_FINISHED = 4
};

/// Constant 'AMI_NOT_SELECTED'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_NOT_SELECTED = 10
};

/// Constant 'AMI_ACCELERATION'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_ACCELERATION = 11
};

/// Constant 'AMI_SKIDPAD'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_SKIDPAD = 12
};

/// Constant 'AMI_AUTOCROSS'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_AUTOCROSS = 13
};

/// Constant 'AMI_TRACK_DRIVE'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_TRACK_DRIVE = 14
};

/// Constant 'AMI_AUTONOMOUS_DEMO'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_AUTONOMOUS_DEMO = 15
};

/// Constant 'AMI_ADS_INSPECTION'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_ADS_INSPECTION = 16
};

/// Constant 'AMI_ADS_EBS'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_ADS_EBS = 17
};

/// Constant 'AMI_DDT_INSPECTION_A'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_DDT_INSPECTION_A = 18
};

/// Constant 'AMI_DDT_INSPECTION_B'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_DDT_INSPECTION_B = 19
};

/// Constant 'AMI_JOYSTICK'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_JOYSTICK = 20
};

/// Constant 'AMI_MANUAL'.
enum
{
  imperial_driverless_interfaces__msg__CanState__AMI_MANUAL = 21
};

// Struct defined in msg/CanState in the package imperial_driverless_interfaces.
typedef struct imperial_driverless_interfaces__msg__CanState
{
  uint16_t as_state;
  uint16_t ami_state;
} imperial_driverless_interfaces__msg__CanState;

// Struct for a sequence of imperial_driverless_interfaces__msg__CanState.
typedef struct imperial_driverless_interfaces__msg__CanState__Sequence
{
  imperial_driverless_interfaces__msg__CanState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} imperial_driverless_interfaces__msg__CanState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CAN_STATE__STRUCT_H_
