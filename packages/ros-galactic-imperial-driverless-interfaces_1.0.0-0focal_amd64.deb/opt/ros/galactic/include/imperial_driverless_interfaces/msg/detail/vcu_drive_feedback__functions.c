// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from imperial_driverless_interfaces:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice
#include "imperial_driverless_interfaces/msg/detail/vcu_drive_feedback__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
imperial_driverless_interfaces__msg__VCUDriveFeedback__init(imperial_driverless_interfaces__msg__VCUDriveFeedback * msg)
{
  if (!msg) {
    return false;
  }
  // front_axle_trq
  // rear_axle_trq
  // angle
  // hyd_press_f_pct
  // hyd_press_r_pct
  // fl_wheel_speed
  // fr_wheel_speed
  // rl_wheel_speed
  // rr_wheel_speed
  return true;
}

void
imperial_driverless_interfaces__msg__VCUDriveFeedback__fini(imperial_driverless_interfaces__msg__VCUDriveFeedback * msg)
{
  if (!msg) {
    return;
  }
  // front_axle_trq
  // rear_axle_trq
  // angle
  // hyd_press_f_pct
  // hyd_press_r_pct
  // fl_wheel_speed
  // fr_wheel_speed
  // rl_wheel_speed
  // rr_wheel_speed
}

imperial_driverless_interfaces__msg__VCUDriveFeedback *
imperial_driverless_interfaces__msg__VCUDriveFeedback__create()
{
  imperial_driverless_interfaces__msg__VCUDriveFeedback * msg = (imperial_driverless_interfaces__msg__VCUDriveFeedback *)malloc(sizeof(imperial_driverless_interfaces__msg__VCUDriveFeedback));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(imperial_driverless_interfaces__msg__VCUDriveFeedback));
  bool success = imperial_driverless_interfaces__msg__VCUDriveFeedback__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
imperial_driverless_interfaces__msg__VCUDriveFeedback__destroy(imperial_driverless_interfaces__msg__VCUDriveFeedback * msg)
{
  if (msg) {
    imperial_driverless_interfaces__msg__VCUDriveFeedback__fini(msg);
  }
  free(msg);
}


bool
imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence__init(imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  imperial_driverless_interfaces__msg__VCUDriveFeedback * data = NULL;
  if (size) {
    data = (imperial_driverless_interfaces__msg__VCUDriveFeedback *)calloc(size, sizeof(imperial_driverless_interfaces__msg__VCUDriveFeedback));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = imperial_driverless_interfaces__msg__VCUDriveFeedback__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        imperial_driverless_interfaces__msg__VCUDriveFeedback__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence__fini(imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      imperial_driverless_interfaces__msg__VCUDriveFeedback__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence *
imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence__create(size_t size)
{
  imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence * array = (imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence *)malloc(sizeof(imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence__destroy(imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence * array)
{
  if (array) {
    imperial_driverless_interfaces__msg__VCUDriveFeedback__Sequence__fini(array);
  }
  free(array);
}
