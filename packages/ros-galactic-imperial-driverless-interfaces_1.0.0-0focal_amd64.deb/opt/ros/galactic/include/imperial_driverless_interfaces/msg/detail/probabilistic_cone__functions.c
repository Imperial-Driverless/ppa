// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from imperial_driverless_interfaces:msg/ProbabilisticCone.idl
// generated code does not contain a copyright notice
#include "imperial_driverless_interfaces/msg/detail/probabilistic_cone__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
imperial_driverless_interfaces__msg__ProbabilisticCone__init(imperial_driverless_interfaces__msg__ProbabilisticCone * msg)
{
  if (!msg) {
    return false;
  }
  // x
  // y
  // x_std_dev
  // y_std_dev
  return true;
}

void
imperial_driverless_interfaces__msg__ProbabilisticCone__fini(imperial_driverless_interfaces__msg__ProbabilisticCone * msg)
{
  if (!msg) {
    return;
  }
  // x
  // y
  // x_std_dev
  // y_std_dev
}

imperial_driverless_interfaces__msg__ProbabilisticCone *
imperial_driverless_interfaces__msg__ProbabilisticCone__create()
{
  imperial_driverless_interfaces__msg__ProbabilisticCone * msg = (imperial_driverless_interfaces__msg__ProbabilisticCone *)malloc(sizeof(imperial_driverless_interfaces__msg__ProbabilisticCone));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(imperial_driverless_interfaces__msg__ProbabilisticCone));
  bool success = imperial_driverless_interfaces__msg__ProbabilisticCone__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
imperial_driverless_interfaces__msg__ProbabilisticCone__destroy(imperial_driverless_interfaces__msg__ProbabilisticCone * msg)
{
  if (msg) {
    imperial_driverless_interfaces__msg__ProbabilisticCone__fini(msg);
  }
  free(msg);
}


bool
imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence__init(imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  imperial_driverless_interfaces__msg__ProbabilisticCone * data = NULL;
  if (size) {
    data = (imperial_driverless_interfaces__msg__ProbabilisticCone *)calloc(size, sizeof(imperial_driverless_interfaces__msg__ProbabilisticCone));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = imperial_driverless_interfaces__msg__ProbabilisticCone__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        imperial_driverless_interfaces__msg__ProbabilisticCone__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence__fini(imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      imperial_driverless_interfaces__msg__ProbabilisticCone__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence *
imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence__create(size_t size)
{
  imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence * array = (imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence *)malloc(sizeof(imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence__destroy(imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence * array)
{
  if (array) {
    imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence__fini(array);
  }
  free(array);
}
