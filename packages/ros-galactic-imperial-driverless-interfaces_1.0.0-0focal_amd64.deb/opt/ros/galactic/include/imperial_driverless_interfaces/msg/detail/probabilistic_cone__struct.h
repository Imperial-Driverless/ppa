// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from imperial_driverless_interfaces:msg/ProbabilisticCone.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PROBABILISTIC_CONE__STRUCT_H_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PROBABILISTIC_CONE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/ProbabilisticCone in the package imperial_driverless_interfaces.
typedef struct imperial_driverless_interfaces__msg__ProbabilisticCone
{
  double x;
  double y;
  double x_std_dev;
  double y_std_dev;
} imperial_driverless_interfaces__msg__ProbabilisticCone;

// Struct for a sequence of imperial_driverless_interfaces__msg__ProbabilisticCone.
typedef struct imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence
{
  imperial_driverless_interfaces__msg__ProbabilisticCone * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PROBABILISTIC_CONE__STRUCT_H_
