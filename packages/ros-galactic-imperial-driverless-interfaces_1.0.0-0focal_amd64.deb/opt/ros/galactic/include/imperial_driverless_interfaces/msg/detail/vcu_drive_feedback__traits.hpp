// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveFeedback.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__TRAITS_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__TRAITS_HPP_

#include "imperial_driverless_interfaces/msg/detail/vcu_drive_feedback__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace rosidl_generator_traits
{

inline void to_yaml(
  const imperial_driverless_interfaces::msg::VCUDriveFeedback & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: front_axle_trq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "front_axle_trq: ";
    value_to_yaml(msg.front_axle_trq, out);
    out << "\n";
  }

  // member: rear_axle_trq
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rear_axle_trq: ";
    value_to_yaml(msg.rear_axle_trq, out);
    out << "\n";
  }

  // member: angle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "angle: ";
    value_to_yaml(msg.angle, out);
    out << "\n";
  }

  // member: hyd_press_f_pct
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "hyd_press_f_pct: ";
    value_to_yaml(msg.hyd_press_f_pct, out);
    out << "\n";
  }

  // member: hyd_press_r_pct
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "hyd_press_r_pct: ";
    value_to_yaml(msg.hyd_press_r_pct, out);
    out << "\n";
  }

  // member: fl_wheel_speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fl_wheel_speed: ";
    value_to_yaml(msg.fl_wheel_speed, out);
    out << "\n";
  }

  // member: fr_wheel_speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fr_wheel_speed: ";
    value_to_yaml(msg.fr_wheel_speed, out);
    out << "\n";
  }

  // member: rl_wheel_speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rl_wheel_speed: ";
    value_to_yaml(msg.rl_wheel_speed, out);
    out << "\n";
  }

  // member: rr_wheel_speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rr_wheel_speed: ";
    value_to_yaml(msg.rr_wheel_speed, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const imperial_driverless_interfaces::msg::VCUDriveFeedback & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<imperial_driverless_interfaces::msg::VCUDriveFeedback>()
{
  return "imperial_driverless_interfaces::msg::VCUDriveFeedback";
}

template<>
inline const char * name<imperial_driverless_interfaces::msg::VCUDriveFeedback>()
{
  return "imperial_driverless_interfaces/msg/VCUDriveFeedback";
}

template<>
struct has_fixed_size<imperial_driverless_interfaces::msg::VCUDriveFeedback>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<imperial_driverless_interfaces::msg::VCUDriveFeedback>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<imperial_driverless_interfaces::msg::VCUDriveFeedback>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_FEEDBACK__TRAITS_HPP_
