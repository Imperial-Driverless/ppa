// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from imperial_driverless_interfaces:msg/Cone.idl
// generated code does not contain a copyright notice
#include "imperial_driverless_interfaces/msg/detail/cone__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `position`
#include "geometry_msgs/msg/detail/point__functions.h"

bool
imperial_driverless_interfaces__msg__Cone__init(imperial_driverless_interfaces__msg__Cone * msg)
{
  if (!msg) {
    return false;
  }
  // position
  if (!geometry_msgs__msg__Point__init(&msg->position)) {
    imperial_driverless_interfaces__msg__Cone__fini(msg);
    return false;
  }
  return true;
}

void
imperial_driverless_interfaces__msg__Cone__fini(imperial_driverless_interfaces__msg__Cone * msg)
{
  if (!msg) {
    return;
  }
  // position
  geometry_msgs__msg__Point__fini(&msg->position);
}

imperial_driverless_interfaces__msg__Cone *
imperial_driverless_interfaces__msg__Cone__create()
{
  imperial_driverless_interfaces__msg__Cone * msg = (imperial_driverless_interfaces__msg__Cone *)malloc(sizeof(imperial_driverless_interfaces__msg__Cone));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(imperial_driverless_interfaces__msg__Cone));
  bool success = imperial_driverless_interfaces__msg__Cone__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
imperial_driverless_interfaces__msg__Cone__destroy(imperial_driverless_interfaces__msg__Cone * msg)
{
  if (msg) {
    imperial_driverless_interfaces__msg__Cone__fini(msg);
  }
  free(msg);
}


bool
imperial_driverless_interfaces__msg__Cone__Sequence__init(imperial_driverless_interfaces__msg__Cone__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  imperial_driverless_interfaces__msg__Cone * data = NULL;
  if (size) {
    data = (imperial_driverless_interfaces__msg__Cone *)calloc(size, sizeof(imperial_driverless_interfaces__msg__Cone));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = imperial_driverless_interfaces__msg__Cone__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        imperial_driverless_interfaces__msg__Cone__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
imperial_driverless_interfaces__msg__Cone__Sequence__fini(imperial_driverless_interfaces__msg__Cone__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      imperial_driverless_interfaces__msg__Cone__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

imperial_driverless_interfaces__msg__Cone__Sequence *
imperial_driverless_interfaces__msg__Cone__Sequence__create(size_t size)
{
  imperial_driverless_interfaces__msg__Cone__Sequence * array = (imperial_driverless_interfaces__msg__Cone__Sequence *)malloc(sizeof(imperial_driverless_interfaces__msg__Cone__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = imperial_driverless_interfaces__msg__Cone__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
imperial_driverless_interfaces__msg__Cone__Sequence__destroy(imperial_driverless_interfaces__msg__Cone__Sequence * array)
{
  if (array) {
    imperial_driverless_interfaces__msg__Cone__Sequence__fini(array);
  }
  free(array);
}
