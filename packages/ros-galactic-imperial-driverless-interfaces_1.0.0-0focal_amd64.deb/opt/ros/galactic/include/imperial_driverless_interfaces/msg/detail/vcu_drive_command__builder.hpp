// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from imperial_driverless_interfaces:msg/VCUDriveCommand.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__BUILDER_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__BUILDER_HPP_

#include "imperial_driverless_interfaces/msg/detail/vcu_drive_command__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace imperial_driverless_interfaces
{

namespace msg
{

namespace builder
{

class Init_VCUDriveCommand_hyd_press_r_req_pct
{
public:
  explicit Init_VCUDriveCommand_hyd_press_r_req_pct(::imperial_driverless_interfaces::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  ::imperial_driverless_interfaces::msg::VCUDriveCommand hyd_press_r_req_pct(::imperial_driverless_interfaces::msg::VCUDriveCommand::_hyd_press_r_req_pct_type arg)
  {
    msg_.hyd_press_r_req_pct = std::move(arg);
    return std::move(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_hyd_press_f_req_pct
{
public:
  explicit Init_VCUDriveCommand_hyd_press_f_req_pct(::imperial_driverless_interfaces::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  Init_VCUDriveCommand_hyd_press_r_req_pct hyd_press_f_req_pct(::imperial_driverless_interfaces::msg::VCUDriveCommand::_hyd_press_f_req_pct_type arg)
  {
    msg_.hyd_press_f_req_pct = std::move(arg);
    return Init_VCUDriveCommand_hyd_press_r_req_pct(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_steer_request_deg
{
public:
  explicit Init_VCUDriveCommand_steer_request_deg(::imperial_driverless_interfaces::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  Init_VCUDriveCommand_hyd_press_f_req_pct steer_request_deg(::imperial_driverless_interfaces::msg::VCUDriveCommand::_steer_request_deg_type arg)
  {
    msg_.steer_request_deg = std::move(arg);
    return Init_VCUDriveCommand_hyd_press_f_req_pct(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_rear_motor_speed_max
{
public:
  explicit Init_VCUDriveCommand_rear_motor_speed_max(::imperial_driverless_interfaces::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  Init_VCUDriveCommand_steer_request_deg rear_motor_speed_max(::imperial_driverless_interfaces::msg::VCUDriveCommand::_rear_motor_speed_max_type arg)
  {
    msg_.rear_motor_speed_max = std::move(arg);
    return Init_VCUDriveCommand_steer_request_deg(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_rear_axle_trq_request
{
public:
  explicit Init_VCUDriveCommand_rear_axle_trq_request(::imperial_driverless_interfaces::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  Init_VCUDriveCommand_rear_motor_speed_max rear_axle_trq_request(::imperial_driverless_interfaces::msg::VCUDriveCommand::_rear_axle_trq_request_type arg)
  {
    msg_.rear_axle_trq_request = std::move(arg);
    return Init_VCUDriveCommand_rear_motor_speed_max(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_front_motor_speed_max
{
public:
  explicit Init_VCUDriveCommand_front_motor_speed_max(::imperial_driverless_interfaces::msg::VCUDriveCommand & msg)
  : msg_(msg)
  {}
  Init_VCUDriveCommand_rear_axle_trq_request front_motor_speed_max(::imperial_driverless_interfaces::msg::VCUDriveCommand::_front_motor_speed_max_type arg)
  {
    msg_.front_motor_speed_max = std::move(arg);
    return Init_VCUDriveCommand_rear_axle_trq_request(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

class Init_VCUDriveCommand_front_axle_trq_request
{
public:
  Init_VCUDriveCommand_front_axle_trq_request()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_VCUDriveCommand_front_motor_speed_max front_axle_trq_request(::imperial_driverless_interfaces::msg::VCUDriveCommand::_front_axle_trq_request_type arg)
  {
    msg_.front_axle_trq_request = std::move(arg);
    return Init_VCUDriveCommand_front_motor_speed_max(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::VCUDriveCommand msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::imperial_driverless_interfaces::msg::VCUDriveCommand>()
{
  return imperial_driverless_interfaces::msg::builder::Init_VCUDriveCommand_front_axle_trq_request();
}

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__VCU_DRIVE_COMMAND__BUILDER_HPP_
