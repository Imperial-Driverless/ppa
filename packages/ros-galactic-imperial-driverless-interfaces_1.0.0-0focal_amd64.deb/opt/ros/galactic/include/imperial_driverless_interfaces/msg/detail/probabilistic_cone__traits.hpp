// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from imperial_driverless_interfaces:msg/ProbabilisticCone.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PROBABILISTIC_CONE__TRAITS_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PROBABILISTIC_CONE__TRAITS_HPP_

#include "imperial_driverless_interfaces/msg/detail/probabilistic_cone__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace rosidl_generator_traits
{

inline void to_yaml(
  const imperial_driverless_interfaces::msg::ProbabilisticCone & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x: ";
    value_to_yaml(msg.x, out);
    out << "\n";
  }

  // member: y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y: ";
    value_to_yaml(msg.y, out);
    out << "\n";
  }

  // member: x_std_dev
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x_std_dev: ";
    value_to_yaml(msg.x_std_dev, out);
    out << "\n";
  }

  // member: y_std_dev
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y_std_dev: ";
    value_to_yaml(msg.y_std_dev, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const imperial_driverless_interfaces::msg::ProbabilisticCone & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<imperial_driverless_interfaces::msg::ProbabilisticCone>()
{
  return "imperial_driverless_interfaces::msg::ProbabilisticCone";
}

template<>
inline const char * name<imperial_driverless_interfaces::msg::ProbabilisticCone>()
{
  return "imperial_driverless_interfaces/msg/ProbabilisticCone";
}

template<>
struct has_fixed_size<imperial_driverless_interfaces::msg::ProbabilisticCone>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<imperial_driverless_interfaces::msg::ProbabilisticCone>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<imperial_driverless_interfaces::msg::ProbabilisticCone>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PROBABILISTIC_CONE__TRAITS_HPP_
