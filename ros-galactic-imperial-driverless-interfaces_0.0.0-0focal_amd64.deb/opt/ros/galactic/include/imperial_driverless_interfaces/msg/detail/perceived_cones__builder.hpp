// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from imperial_driverless_interfaces:msg/PerceivedCones.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PERCEIVED_CONES__BUILDER_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PERCEIVED_CONES__BUILDER_HPP_

#include "imperial_driverless_interfaces/msg/detail/perceived_cones__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace imperial_driverless_interfaces
{

namespace msg
{

namespace builder
{

class Init_PerceivedCones_right_cones
{
public:
  explicit Init_PerceivedCones_right_cones(::imperial_driverless_interfaces::msg::PerceivedCones & msg)
  : msg_(msg)
  {}
  ::imperial_driverless_interfaces::msg::PerceivedCones right_cones(::imperial_driverless_interfaces::msg::PerceivedCones::_right_cones_type arg)
  {
    msg_.right_cones = std::move(arg);
    return std::move(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::PerceivedCones msg_;
};

class Init_PerceivedCones_left_cones
{
public:
  explicit Init_PerceivedCones_left_cones(::imperial_driverless_interfaces::msg::PerceivedCones & msg)
  : msg_(msg)
  {}
  Init_PerceivedCones_right_cones left_cones(::imperial_driverless_interfaces::msg::PerceivedCones::_left_cones_type arg)
  {
    msg_.left_cones = std::move(arg);
    return Init_PerceivedCones_right_cones(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::PerceivedCones msg_;
};

class Init_PerceivedCones_header
{
public:
  Init_PerceivedCones_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PerceivedCones_left_cones header(::imperial_driverless_interfaces::msg::PerceivedCones::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_PerceivedCones_left_cones(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::PerceivedCones msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::imperial_driverless_interfaces::msg::PerceivedCones>()
{
  return imperial_driverless_interfaces::msg::builder::Init_PerceivedCones_header();
}

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__PERCEIVED_CONES__BUILDER_HPP_
