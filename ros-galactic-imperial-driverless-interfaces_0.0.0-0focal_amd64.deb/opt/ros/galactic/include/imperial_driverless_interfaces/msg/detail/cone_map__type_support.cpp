// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from imperial_driverless_interfaces:msg/ConeMap.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "imperial_driverless_interfaces/msg/detail/cone_map__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace imperial_driverless_interfaces
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void ConeMap_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) imperial_driverless_interfaces::msg::ConeMap(_init);
}

void ConeMap_fini_function(void * message_memory)
{
  auto typed_message = static_cast<imperial_driverless_interfaces::msg::ConeMap *>(message_memory);
  typed_message->~ConeMap();
}

size_t size_function__ConeMap__left_cones(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ConeMap__left_cones(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone> *>(untyped_member);
  return &member[index];
}

void * get_function__ConeMap__left_cones(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone> *>(untyped_member);
  return &member[index];
}

void resize_function__ConeMap__left_cones(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone> *>(untyped_member);
  member->resize(size);
}

size_t size_function__ConeMap__right_cones(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone> *>(untyped_member);
  return member->size();
}

const void * get_const_function__ConeMap__right_cones(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone> *>(untyped_member);
  return &member[index];
}

void * get_function__ConeMap__right_cones(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone> *>(untyped_member);
  return &member[index];
}

void resize_function__ConeMap__right_cones(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember ConeMap_message_member_array[5] = {
  {
    "header",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<std_msgs::msg::Header>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::ConeMap, header),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "left_cones",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<imperial_driverless_interfaces::msg::ProbabilisticCone>(),  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::ConeMap, left_cones),  // bytes offset in struct
    nullptr,  // default value
    size_function__ConeMap__left_cones,  // size() function pointer
    get_const_function__ConeMap__left_cones,  // get_const(index) function pointer
    get_function__ConeMap__left_cones,  // get(index) function pointer
    resize_function__ConeMap__left_cones  // resize(index) function pointer
  },
  {
    "right_cones",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<imperial_driverless_interfaces::msg::ProbabilisticCone>(),  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::ConeMap, right_cones),  // bytes offset in struct
    nullptr,  // default value
    size_function__ConeMap__right_cones,  // size() function pointer
    get_const_function__ConeMap__right_cones,  // get_const(index) function pointer
    get_function__ConeMap__right_cones,  // get(index) function pointer
    resize_function__ConeMap__right_cones  // resize(index) function pointer
  },
  {
    "left_loop_closed",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::ConeMap, left_loop_closed),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "right_loop_closed",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(imperial_driverless_interfaces::msg::ConeMap, right_loop_closed),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers ConeMap_message_members = {
  "imperial_driverless_interfaces::msg",  // message namespace
  "ConeMap",  // message name
  5,  // number of fields
  sizeof(imperial_driverless_interfaces::msg::ConeMap),
  ConeMap_message_member_array,  // message members
  ConeMap_init_function,  // function to initialize message memory (memory has to be allocated)
  ConeMap_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t ConeMap_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &ConeMap_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace imperial_driverless_interfaces


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<imperial_driverless_interfaces::msg::ConeMap>()
{
  return &::imperial_driverless_interfaces::msg::rosidl_typesupport_introspection_cpp::ConeMap_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, imperial_driverless_interfaces, msg, ConeMap)() {
  return &::imperial_driverless_interfaces::msg::rosidl_typesupport_introspection_cpp::ConeMap_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
