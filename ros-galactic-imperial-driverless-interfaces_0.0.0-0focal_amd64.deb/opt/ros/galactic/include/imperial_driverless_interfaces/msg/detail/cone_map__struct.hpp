// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from imperial_driverless_interfaces:msg/ConeMap.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__STRUCT_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'left_cones'
// Member 'right_cones'
#include "imperial_driverless_interfaces/msg/detail/probabilistic_cone__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__imperial_driverless_interfaces__msg__ConeMap __attribute__((deprecated))
#else
# define DEPRECATED__imperial_driverless_interfaces__msg__ConeMap __declspec(deprecated)
#endif

namespace imperial_driverless_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ConeMap_
{
  using Type = ConeMap_<ContainerAllocator>;

  explicit ConeMap_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->left_loop_closed = false;
      this->right_loop_closed = false;
    }
  }

  explicit ConeMap_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->left_loop_closed = false;
      this->right_loop_closed = false;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _left_cones_type =
    std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<imperial_driverless_interfaces::msg::ProbabilisticCone_<ContainerAllocator>>>;
  _left_cones_type left_cones;
  using _right_cones_type =
    std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<imperial_driverless_interfaces::msg::ProbabilisticCone_<ContainerAllocator>>>;
  _right_cones_type right_cones;
  using _left_loop_closed_type =
    bool;
  _left_loop_closed_type left_loop_closed;
  using _right_loop_closed_type =
    bool;
  _right_loop_closed_type right_loop_closed;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__left_cones(
    const std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<imperial_driverless_interfaces::msg::ProbabilisticCone_<ContainerAllocator>>> & _arg)
  {
    this->left_cones = _arg;
    return *this;
  }
  Type & set__right_cones(
    const std::vector<imperial_driverless_interfaces::msg::ProbabilisticCone_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<imperial_driverless_interfaces::msg::ProbabilisticCone_<ContainerAllocator>>> & _arg)
  {
    this->right_cones = _arg;
    return *this;
  }
  Type & set__left_loop_closed(
    const bool & _arg)
  {
    this->left_loop_closed = _arg;
    return *this;
  }
  Type & set__right_loop_closed(
    const bool & _arg)
  {
    this->right_loop_closed = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator> *;
  using ConstRawPtr =
    const imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__imperial_driverless_interfaces__msg__ConeMap
    std::shared_ptr<imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__imperial_driverless_interfaces__msg__ConeMap
    std::shared_ptr<imperial_driverless_interfaces::msg::ConeMap_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ConeMap_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->left_cones != other.left_cones) {
      return false;
    }
    if (this->right_cones != other.right_cones) {
      return false;
    }
    if (this->left_loop_closed != other.left_loop_closed) {
      return false;
    }
    if (this->right_loop_closed != other.right_loop_closed) {
      return false;
    }
    return true;
  }
  bool operator!=(const ConeMap_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ConeMap_

// alias to use template instance with default allocator
using ConeMap =
  imperial_driverless_interfaces::msg::ConeMap_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__STRUCT_HPP_
