// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from imperial_driverless_interfaces:msg/ConeMap.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__STRUCT_H_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'left_cones'
// Member 'right_cones'
#include "imperial_driverless_interfaces/msg/detail/probabilistic_cone__struct.h"

// Struct defined in msg/ConeMap in the package imperial_driverless_interfaces.
typedef struct imperial_driverless_interfaces__msg__ConeMap
{
  std_msgs__msg__Header header;
  imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence left_cones;
  imperial_driverless_interfaces__msg__ProbabilisticCone__Sequence right_cones;
  bool left_loop_closed;
  bool right_loop_closed;
} imperial_driverless_interfaces__msg__ConeMap;

// Struct for a sequence of imperial_driverless_interfaces__msg__ConeMap.
typedef struct imperial_driverless_interfaces__msg__ConeMap__Sequence
{
  imperial_driverless_interfaces__msg__ConeMap * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} imperial_driverless_interfaces__msg__ConeMap__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__STRUCT_H_
