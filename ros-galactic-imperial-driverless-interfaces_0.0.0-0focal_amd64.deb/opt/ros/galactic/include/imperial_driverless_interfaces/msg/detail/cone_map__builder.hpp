// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from imperial_driverless_interfaces:msg/ConeMap.idl
// generated code does not contain a copyright notice

#ifndef IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__BUILDER_HPP_
#define IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__BUILDER_HPP_

#include "imperial_driverless_interfaces/msg/detail/cone_map__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace imperial_driverless_interfaces
{

namespace msg
{

namespace builder
{

class Init_ConeMap_right_loop_closed
{
public:
  explicit Init_ConeMap_right_loop_closed(::imperial_driverless_interfaces::msg::ConeMap & msg)
  : msg_(msg)
  {}
  ::imperial_driverless_interfaces::msg::ConeMap right_loop_closed(::imperial_driverless_interfaces::msg::ConeMap::_right_loop_closed_type arg)
  {
    msg_.right_loop_closed = std::move(arg);
    return std::move(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::ConeMap msg_;
};

class Init_ConeMap_left_loop_closed
{
public:
  explicit Init_ConeMap_left_loop_closed(::imperial_driverless_interfaces::msg::ConeMap & msg)
  : msg_(msg)
  {}
  Init_ConeMap_right_loop_closed left_loop_closed(::imperial_driverless_interfaces::msg::ConeMap::_left_loop_closed_type arg)
  {
    msg_.left_loop_closed = std::move(arg);
    return Init_ConeMap_right_loop_closed(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::ConeMap msg_;
};

class Init_ConeMap_right_cones
{
public:
  explicit Init_ConeMap_right_cones(::imperial_driverless_interfaces::msg::ConeMap & msg)
  : msg_(msg)
  {}
  Init_ConeMap_left_loop_closed right_cones(::imperial_driverless_interfaces::msg::ConeMap::_right_cones_type arg)
  {
    msg_.right_cones = std::move(arg);
    return Init_ConeMap_left_loop_closed(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::ConeMap msg_;
};

class Init_ConeMap_left_cones
{
public:
  explicit Init_ConeMap_left_cones(::imperial_driverless_interfaces::msg::ConeMap & msg)
  : msg_(msg)
  {}
  Init_ConeMap_right_cones left_cones(::imperial_driverless_interfaces::msg::ConeMap::_left_cones_type arg)
  {
    msg_.left_cones = std::move(arg);
    return Init_ConeMap_right_cones(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::ConeMap msg_;
};

class Init_ConeMap_header
{
public:
  Init_ConeMap_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ConeMap_left_cones header(::imperial_driverless_interfaces::msg::ConeMap::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ConeMap_left_cones(msg_);
  }

private:
  ::imperial_driverless_interfaces::msg::ConeMap msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::imperial_driverless_interfaces::msg::ConeMap>()
{
  return imperial_driverless_interfaces::msg::builder::Init_ConeMap_header();
}

}  // namespace imperial_driverless_interfaces

#endif  // IMPERIAL_DRIVERLESS_INTERFACES__MSG__DETAIL__CONE_MAP__BUILDER_HPP_
